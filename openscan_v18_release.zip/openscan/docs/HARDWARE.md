# Hardware notes: Veepeak vs. TOPDON ONE

## USB cable ELM327 adapters

A wired USB ELM327 dongle needs no separate code path - the USB-serial
chip inside it (CH340, FTDI, CP2102, etc.) makes Windows/Linux assign
it a COM port / `/dev/ttyUSB*` device exactly like a paired Bluetooth
adapter does, so it goes through the same `SerialTransport` as
everything else. In the connection dialog, pick "USB / Serial / COM
port" and either:

- Use **Quick Connect** - it tries every detected serial port with an
  `ATI` handshake and connects automatically to the first one that
  answers like an ELM327, so you don't need to know which COM port it
  landed on; or
- Use **Scan** and pick the port manually - each one now shows its
  driver description (e.g. "USB-SERIAL CH340") alongside the port
  name, which is usually enough to tell it apart from other COM ports
  on the machine.

If Quick Connect can't find it: check Windows Device Manager for a new
COM port appearing when you plug the cable in (a missing driver is the
usual culprit), and confirm nothing else (another instance of OpenScan,
a different scan tool) already has the port open.

## Veepeak (OBDCheck BLE / VP11, ELM327-based)

- Chipset: ELM327 clone (v1.4/1.5 command set), Bluetooth Classic (Android/
  Windows) or BLE (iOS), interprets standard OBD-II AT commands.
- What it can do: everything in SAE J1979 — Mode 01 live PIDs, Mode 02
  freeze frame, Mode 03/07 DTCs (stored/pending), Mode 04 clear, Mode 05/06
  O2 & monitor tests, Mode 09 VIN. This is the generic, standardized layer
  every scan tool supports, and it's 100% of what OpenScan's core OBD-II
  engine needs.
- Multi-ECU topology: works. A broadcast request to 0x7DF gets answered by
  every ECU on the bus at its own address (0x7E8, 0x7E9, 0x7EA...). OpenScan
  uses this to build a basic topology map even on a plain ELM327.
- Limitations: ELM327's AT command interpreter adds latency and doesn't
  give you raw, low-level CAN control — extended/manufacturer UDS services
  (routine control, IO control, security access) are unreliable or
  unsupported on genuine ELM327 chips, and outright broken on many cheap
  clones. Treat the Veepeak as your **generic OBD-II and topology-discovery
  adapter**.

## TOPDON ONE Bidirectional (10.1" tablet + ONE VCI, J2534 pass-thru)

- The tablet runs TOPDON's own Android-based app (TopScan) and is not
  something OpenScan runs on directly — OpenScan is a separate PC app.
- The "ONE VCI" is the actual interface box. TOPDON advertises it as
  J2534 pass-thru capable across a list of supported brands. **J2534 is an
  open, published API standard (SAE J2534-1/2)** for exactly this kind of
  device, so in principle a PC app can talk to it directly via its
  vendor-supplied PassThru DLL (Windows-only — J2534 is a Windows API).
- What that gets you, if TOPDON exposes a standard-conformant DLL: raw
  ISO 15765 (CAN) and ISO 14230 (KWP) framing, which is what OpenScan's UDS
  layer needs for real per-module diagnostics, bidirectional actuator
  tests, and coding — without ELM327's AT-command bottleneck.
- What it does **not** get you automatically: the actual OEM security-access
  seed/key algorithms, routine IDs, and coding procedures TOPDON licenses
  from vehicle manufacturers. Those live in TOPDON's app/cloud, are not
  published, and can't legally be reverse-engineered and redistributed here.
  This is the same wall every independent tool hits — it's why Autel/
  Snap-on/Bosch charge annual subscriptions per make.
- Practical verdict: use the TOPDON VCI as OpenScan's **J2534 transport**
  for raw CAN/UDS access (best-effort — confirm your VCI installs a
  registered PassThru DLL under
  `HKLM\SOFTWARE\PassThruSupport.04.04` on Windows before relying on it),
  and keep using TOPDON's own TopScan app for anything that needs their
  licensed OEM bidirectional routines. OpenScan's plugin system lets you
  (or the community) add specific, legally-sourced routine/security data
  over time.

### Bitness gotcha

Almost every vendor J2534 DLL is 32-bit only, and installers register it
under the `WOW6432Node` registry view on 64-bit Windows. A 64-bit Python
process can enumerate that registry entry fine but **cannot load the DLL**
— `ctypes.WinDLL(...)` will raise `OSError: [WinError 193] %1 is not a
valid Win32 application`. OpenScan's connection dialog checks both
registry views and flags a bitness mismatch before you try to connect. If
your TOPDON driver turns out to be 32-bit (likely), you'll need a 32-bit
Python interpreter installed specifically for the J2534 path — the
generic OBD-II / Bluetooth path works fine under 64-bit Python either way.

## Recommendation

Use both: Veepeak over Bluetooth for everyday generic diagnostics and
topology snapshots, TOPDON's ONE VCI over its J2534 DLL (USB, on Windows)
when you need deeper per-module UDS access. OpenScan's transport layer
supports both under one `Transport` interface, auto-detected at connect
time.

# Architecture

```
openscan/
  core/
    transport/        # byte-level links to the vehicle
      base.py          # Transport ABC: connect/send/recv/close
      bluetooth_rfcomm.py   # Bluetooth Classic SPP (Veepeak, generic ELM327)
      serial_link.py        # USB/COM serial (Windows COM ports, /dev/ttyUSBx)
      j2534.py               # Windows J2534 PassThru DLL ctypes wrapper (TOPDON VCI, Tactrix, etc.)
    elm327.py          # AT-command driver built on any Transport (except j2534)
    obd2/
      pids.py          # Mode 01/02 PID table + decoders
      dtc.py           # DTC bit-decoding (P/C/B/U + description lookup)
      service.py       # OBD2Service: high-level Mode 01/02/03/04/05/06/07/09 API
    uds/
      uds.py           # ISO 14229 request/response framing + core SIDs
      isotp.py         # ISO-TP (ISO 15765-2) segmentation/reassembly over CAN
      topology.py      # ECU discovery + network graph builder
    vehicle.py         # Session/state: connected transport, protocol, discovered ECUs
    plugin_api.py      # Plugin base classes (PidPlugin, DtcPlugin, SecurityAlgoPlugin, RoutinePlugin)
  plugins/
    loader.py          # Discovers/loads plugins from openscan/plugins/*
    examples/          # Example plugin(s)
  data/
    dtc_generic.json    # SAE-generic DTC descriptions (P0xxx/P2xxx/P3xxx generic set)
    pids_generic.json   # SAE-generic Mode 01 PID table
  gui/
    app.py              # QApplication bootstrap
    main_window.py       # Main window, tab container
    connection_dialog.py # Adapter discovery/selection (BT scan, COM port, J2534 DLL picker)
    dashboard.py          # Live data tiles + pyqtgraph strip charts
    dtc_panel.py           # DTC list, freeze frame, clear button
    topology_view.py       # QGraphicsScene node/edge drawing of discovered ECUs
    vin_panel.py            # VIN decode + vehicle info
tests/                # unit tests for PID/DTC decoding, ISO-TP framing, topology graph
```

## Data flow

```
Transport (bytes)  ->  ELM327 driver / J2534 driver  ->  ISO-TP framing (uds/isotp.py)
                                                       ->  UDS or raw OBD2 request/response
OBD2Service / UDS layer  ->  decoded PIDs, DTCs, ECU responses
                          ->  Vehicle (session state, discovered ECU map)
                          ->  GUI (dashboard, DTC panel, topology view)
```

Two parallel "diagnostic engines" share the same Transport abstraction:

- **OBD2Service** — generic, works on any ELM327 adapter, no plugins needed.
- **UDS layer** — richer, needs either raw CAN passthrough (J2534) or an
  ELM327 in a compatible protocol mode with `AT CAF0`/header control. OEM
  security access and routine execution are delegated to plugins.

## Plugin interface (`core/plugin_api.py`)

```python
class PidPlugin:
    def pids(self) -> dict[int, PidDefinition]: ...

class DtcPlugin:
    def descriptions(self) -> dict[str, str]: ...

class SecurityAlgoPlugin:
    make: str
    def compute_key(self, seed: bytes, level: int) -> bytes: ...

class RoutinePlugin:
    make: str
    def routines(self) -> dict[str, RoutineDefinition]: ...
```

Plugins are plain Python modules dropped in `openscan/plugins/`, each
exposing a `register(registry)` function. This keeps OEM-specific (and
potentially legally sensitive) data out of the core project entirely —
users assemble their own plugin set from data they're licensed to use.

## Why PySide6 / Python

- Bluetooth (via `pybluez2`/`bleak`), serial (`pyserial`), and CAN/UDS
  (`python-can`, patterns from `udsoncan`) all have mature, cross-platform
  Python libraries.
- PySide6 (Qt) ships one codebase that runs unmodified on Linux and
  Windows, with `pyqtgraph` for the real-time strip charts and
  `QGraphicsScene` for the topology map — no need for platform-specific UI
  code.
- LGPL/permissive licensing throughout the stack keeps the whole project
  freely redistributable under MIT.

# Roadmap

## Implemented in this scaffold

- [x] Transport abstraction + Bluetooth RFCOMM + serial backends
- [x] ELM327 AT-command driver with auto protocol detection
- [x] Generic OBD-II: live PIDs, freeze frame, DTC read/clear, VIN decode
- [x] Multi-ECU discovery via functional addressing (basic topology, works
      on any ELM327 adapter)
- [x] ISO-TP framing + core UDS request/response layer
- [x] Plugin API + loader + one example plugin
- [x] Desktop GUI: connection dialog, live dashboard w/ graphing, DTC
      panel, topology map view

## Needs real hardware to finish/validate

- [ ] J2534 PassThru ctypes bindings (`core/transport/j2534.py`) — struct
      and calls are implemented against the standard J2534 v04.04 API, but
      untested against the TOPDON ONE VCI's actual driver. First things to
      check on real hardware: does `J2534Transport.discover()` find it at
      all (confirms the driver registers under
      `HKLM\SOFTWARE\PassThruSupport.04.04`), does `PassThruConnect`
      succeed for protocol ID 5 (raw CAN) at your vehicle's bus speed, and
      does `recv_frame()` after a `send_frame()` see anything at all
- [ ] Confirm which UDS services (routine control, IO control by
      identifier, security access) your specific adapters pass through
      cleanly vs. silently drop
- [ ] Tune ISO-TP timing/flow-control parameters against real bus traffic

## Requires community/plugin contributions (by design — see README)

- [ ] Per-OEM security-access seed/key algorithms
- [ ] Per-OEM/per-model bidirectional routine tables (actuator tests,
      relearns, injector coding, etc.)
- [ ] Expanded manufacturer-specific DTC description sets
- [ ] Reflashing/ECU programming (out of scope for OpenScan itself; this
      needs OEM-signed firmware images OpenScan will never distribute —
      use OEM pass-thru software like Ford IDS/FDRS, GM SPS2, etc. through
      the same J2534 VCI)

## Nice-to-have

- [ ] CSV/SQLite logging of live data sessions + session replay
- [ ] Freeze-frame-to-DTC correlation view
- [ ] Multi-adapter simultaneous sessions (e.g. gateway + subnet VCI)
- [ ] Mobile companion view (read-only dashboard mirror)

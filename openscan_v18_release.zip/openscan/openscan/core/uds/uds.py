"""ISO 14229 (UDS) core service layer.

Two ways to reach an ECU with these services, both supported:

1. Through an ELM327 adapter already in a CAN protocol mode — pass an
   `ELM327` instance; requests go out via `request_raw()` as hex strings
   and the adapter's own ISO-TP handling takes care of segmentation. Works
   for services the adapter's firmware passes through cleanly (varies by
   clone quality — see docs/HARDWARE.md).
2. Through a raw frame backend (e.g. `transport/j2534.py`) wrapped in an
   `IsoTpLink` — full control, needed for reliable bidirectional routines.

`UDSClient` accepts either and exposes the same high-level methods.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Union

from ..elm327 import ELM327
from .isotp import IsoTpLink

# -- Service IDs (SID) --------------------------------------------------
class SID:
    DIAGNOSTIC_SESSION_CONTROL = 0x10
    ECU_RESET = 0x11
    CLEAR_DIAGNOSTIC_INFORMATION = 0x14
    READ_DTC_INFORMATION = 0x19
    READ_DATA_BY_IDENTIFIER = 0x22
    SECURITY_ACCESS = 0x27
    COMMUNICATION_CONTROL = 0x28
    WRITE_DATA_BY_IDENTIFIER = 0x2E
    IO_CONTROL_BY_IDENTIFIER = 0x2F
    ROUTINE_CONTROL = 0x31
    TESTER_PRESENT = 0x3E

NEGATIVE_RESPONSE_SID = 0x7F

NRC_DESCRIPTIONS = {
    0x10: "General reject",
    0x11: "Service not supported",
    0x12: "Sub-function not supported",
    0x13: "Incorrect message length or invalid format",
    0x22: "Conditions not correct",
    0x24: "Request sequence error",
    0x31: "Request out of range",
    0x33: "Security access denied",
    0x35: "Invalid key",
    0x36: "Exceeded number of attempts",
    0x37: "Required time delay not expired",
    0x78: "Request correctly received, response pending",
}

# Diagnostic session types
SESSION_DEFAULT = 0x01
SESSION_PROGRAMMING = 0x02
SESSION_EXTENDED = 0x03

# Routine control sub-functions
ROUTINE_START = 0x01
ROUTINE_STOP = 0x02
ROUTINE_REQUEST_RESULTS = 0x03


class UDSNegativeResponse(Exception):
    def __init__(self, service: int, nrc: int):
        self.service = service
        self.nrc = nrc
        desc = NRC_DESCRIPTIONS.get(nrc, f"Unknown NRC {nrc:#x}")
        super().__init__(f"Negative response to service {service:#x}: {desc}")


@dataclass
class RoutineDefinition:
    """A named bidirectional routine, normally supplied by a RoutinePlugin
    with OEM-specific routine_id/params for a given make/model/ECU."""
    name: str
    routine_id: int
    ecu_id: int
    params: bytes = b""


class UDSClient:
    """High-level UDS request/response wrapper over either ELM327 or an
    IsoTpLink-based raw frame backend."""

    def __init__(self, backend: Union[ELM327, IsoTpLink],
                 security_algo=None):
        self.backend = backend
        #: Optional SecurityAlgoPlugin instance supplying compute_key()
        self.security_algo = security_algo

    # -- transport-agnostic request/response --------------------------------
    def _request(self, payload: bytes) -> bytes:
        if isinstance(self.backend, ELM327):
            responses = self.backend.request_raw(payload.hex())
            if not responses:
                raise UDSNegativeResponse(payload[0], 0x00)
            data = bytes([responses[0].mode]) + (
                bytes([responses[0].pid]) if responses[0].pid is not None else b""
            ) + responses[0].data
        else:
            self.backend.send(payload)
            data = self.backend.recv()

        if data and data[0] == NEGATIVE_RESPONSE_SID:
            raise UDSNegativeResponse(data[1], data[2] if len(data) > 2 else 0)
        return data

    # -- services -------------------------------------------------------------
    def diagnostic_session_control(self, session: int = SESSION_EXTENDED) -> bytes:
        return self._request(bytes([SID.DIAGNOSTIC_SESSION_CONTROL, session]))

    def tester_present(self) -> bytes:
        return self._request(bytes([SID.TESTER_PRESENT, 0x00]))

    def ecu_reset(self, reset_type: int = 0x01) -> bytes:
        return self._request(bytes([SID.ECU_RESET, reset_type]))

    def read_data_by_identifier(self, did: int) -> bytes:
        resp = self._request(bytes([SID.READ_DATA_BY_IDENTIFIER, did >> 8, did & 0xFF]))
        return resp[3:]  # strip SID+DID echo

    def clear_diagnostic_information(self, group: int = 0xFFFFFF) -> bytes:
        return self._request(bytes([
            SID.CLEAR_DIAGNOSTIC_INFORMATION,
            (group >> 16) & 0xFF, (group >> 8) & 0xFF, group & 0xFF,
        ]))

    def read_dtc_by_status_mask(self, status_mask: int = 0xFF) -> bytes:
        return self._request(bytes([SID.READ_DTC_INFORMATION, 0x02, status_mask]))

    def security_access(self, level: int = 0x01) -> bool:
        """Standard seed/key handshake. Requires a SecurityAlgoPlugin for
        this ECU's make — OpenScan has no built-in algorithms (see
        docs/HARDWARE.md); without one this will always fail at the
        'compute key' step, which is expected and intentional."""
        if self.security_algo is None:
            raise UDSNegativeResponse(SID.SECURITY_ACCESS, 0x33)
        seed_resp = self._request(bytes([SID.SECURITY_ACCESS, level]))
        seed = seed_resp[2:]
        if all(b == 0 for b in seed):
            return True  # already unlocked
        key = self.security_algo.compute_key(seed, level)
        key_resp = self._request(bytes([SID.SECURITY_ACCESS, level + 1]) + key)
        return len(key_resp) >= 2

    def io_control_by_identifier(self, did: int, control_option: bytes,
                                  control_state: bytes = b"") -> bytes:
        """Bidirectional actuator control (e.g. force a solenoid/relay on).
        `control_option` and `control_state` are ECU/DID-specific — supply
        them from a RoutinePlugin, not hand-rolled, unless you've verified
        them against factory service data."""
        payload = bytes([SID.IO_CONTROL_BY_IDENTIFIER, did >> 8, did & 0xFF]) \
            + control_option + control_state
        return self._request(payload)

    def routine_control(self, routine: RoutineDefinition,
                         action: int = ROUTINE_START) -> bytes:
        payload = bytes([
            SID.ROUTINE_CONTROL, action,
            routine.routine_id >> 8, routine.routine_id & 0xFF,
        ]) + routine.params
        return self._request(payload)

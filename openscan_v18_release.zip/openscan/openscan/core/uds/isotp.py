"""Minimal ISO-TP (ISO 15765-2) segmentation/reassembly.

Used on top of a raw CAN frame backend (currently `transport/j2534.py`)
for per-ECU (physically-addressed) UDS requests longer than 7 bytes.
When talking through an ELM327 in CAN protocol modes, the adapter itself
handles ISO-TP framing, so this module is bypassed in that path — see
`uds.py` for which backend each call goes through.
"""

from __future__ import annotations

import time
from typing import Protocol


class FrameBackend(Protocol):
    def send_frame(self, can_id: int, data: bytes) -> None: ...
    def recv_frame(self, timeout_ms: int = 100) -> tuple[int, bytes] | None: ...


SINGLE_FRAME = 0x0
FIRST_FRAME = 0x1
CONSECUTIVE_FRAME = 0x2
FLOW_CONTROL_FRAME = 0x3


class IsoTpError(Exception):
    pass


class IsoTpLink:
    """One physically-addressed ISO-TP conversation (tx_id -> rx_id)."""

    def __init__(self, backend: FrameBackend, tx_id: int, rx_id: int):
        self.backend = backend
        self.tx_id = tx_id
        self.rx_id = rx_id

    def send(self, payload: bytes) -> None:
        if len(payload) <= 7:
            frame = bytes([SINGLE_FRAME << 4 | len(payload)]) + payload
            frame = frame.ljust(8, b"\x00")
            self.backend.send_frame(self.tx_id, frame)
            return

        total_len = len(payload)
        first = bytes([
            FIRST_FRAME << 4 | ((total_len >> 8) & 0xF),
            total_len & 0xFF,
        ]) + payload[:6]
        self.backend.send_frame(self.tx_id, first)

        self._await_flow_control()

        remaining = payload[6:]
        seq = 1
        for i in range(0, len(remaining), 7):
            chunk = remaining[i:i + 7]
            frame = bytes([CONSECUTIVE_FRAME << 4 | (seq & 0xF)]) + chunk
            frame = frame.ljust(8, b"\x00")
            self.backend.send_frame(self.tx_id, frame)
            seq += 1
            time.sleep(0.002)  # small inter-frame gap; tune against real bus

    def _await_flow_control(self, timeout_ms: int = 200) -> None:
        result = self.backend.recv_frame(timeout_ms=timeout_ms)
        if result is None:
            raise IsoTpError("No flow control frame received")
        _, data = result
        pci = data[0] >> 4
        if pci != FLOW_CONTROL_FRAME:
            raise IsoTpError(f"Expected flow control frame, got PCI {pci:#x}")

    def recv(self, timeout_ms: int = 1000) -> bytes:
        result = self.backend.recv_frame(timeout_ms=timeout_ms)
        if result is None:
            raise IsoTpError("Timed out waiting for response")
        can_id, data = result
        pci_type = data[0] >> 4

        if pci_type == SINGLE_FRAME:
            length = data[0] & 0xF
            return data[1:1 + length]

        if pci_type == FIRST_FRAME:
            total_len = ((data[0] & 0xF) << 8) | data[1]
            buf = bytearray(data[2:8])
            # send flow control: continue-to-send, block size 0, no separation
            self.backend.send_frame(self.rx_id, bytes([FLOW_CONTROL_FRAME << 4, 0, 0] + [0] * 5))
            expected_seq = 1
            while len(buf) < total_len:
                nxt = self.backend.recv_frame(timeout_ms=timeout_ms)
                if nxt is None:
                    raise IsoTpError("Timed out mid multi-frame response")
                _, ndata = nxt
                if (ndata[0] >> 4) != CONSECUTIVE_FRAME:
                    raise IsoTpError("Expected consecutive frame")
                seq = ndata[0] & 0xF
                if seq != (expected_seq & 0xF):
                    raise IsoTpError("Consecutive frame out of sequence")
                buf.extend(ndata[1:8])
                expected_seq += 1
            return bytes(buf[:total_len])

        raise IsoTpError(f"Unexpected PCI type {pci_type:#x} in response")

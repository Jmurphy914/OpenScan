"""ECU network topology discovery.

The headline "topology map" feature of expensive scan tools is, at its
core, just: broadcast a request every ECU answers, note who responds,
and label the responders with human-readable module names. The
discovery mechanism itself needs no special hardware or OEM licensing —
it works over a plain ELM327 adapter (like the Veepeak). What
higher-end tools add on top is a much bigger, licensed lookup table
mapping response IDs to exact module names per make/model, which is
exactly the kind of thing a PidPlugin/DtcPlugin-style plugin can supply
here (see docs/ARCHITECTURE.md).
"""

from __future__ import annotations

from dataclasses import dataclass, field

from ..elm327 import ELM327

# Heuristic, best-effort address -> likely-module table for 11-bit
# ISO 15765-4 addressing. 0x7E8 (ECM) is the only address SAE actually
# standardizes; the rest are common conventions, not guarantees — treat
# these as starting labels the user can rename, not ground truth.
KNOWN_ECU_NAMES: dict[int, str] = {
    0x7E8: "Engine Control Module (ECM)",
    0x7E9: "Transmission Control Module (TCM)",
    0x7EA: "Module (commonly ABS/EBCM)",
    0x7EB: "Module (commonly Airbag/SRS)",
    0x7EC: "Module (commonly Body Control Module)",
    0x7ED: "Module (commonly Instrument Cluster)",
    0x7EE: "Module (commonly HVAC)",
    0x7EF: "Module (broadcast address / gateway)",
}


@dataclass
class EcuNode:
    ecu_id: int
    label: str
    responded: bool = True


@dataclass
class TopologyGraph:
    bus_name: str
    nodes: list[EcuNode] = field(default_factory=list)

    def to_edge_list(self) -> list[tuple[str, str]]:
        """(bus, ecu_label) pairs for the GUI's QGraphicsScene renderer."""
        return [(self.bus_name, n.label) for n in self.nodes]


def label_for(ecu_id: int, overrides: dict[int, str] | None = None) -> str:
    if overrides and ecu_id in overrides:
        return overrides[ecu_id]
    if ecu_id in KNOWN_ECU_NAMES:
        return f"{KNOWN_ECU_NAMES[ecu_id]} ({ecu_id:#x})"
    return f"Unknown module ({ecu_id:#x})"


def discover_topology(elm: ELM327, bus_name: str = "OBD-II bus (CAN)",
                       name_overrides: dict[int, str] | None = None) -> TopologyGraph:
    """Discover responding ECUs and build a labeled topology graph.

    Uses the same broadcast-and-collect technique as
    `ELM327.discover_ecus()`, then applies best-effort naming. For a
    richer map (e.g. actually distinguishing ABS from SRS by querying
    each module's Mode 09 / DID 0xF190 VIN or a manufacturer DID), wire
    up per-ECU physically-addressed queries via `UDSClient` once you have
    a J2534-class raw CAN transport — see docs/ROADMAP.md.
    """
    ecu_ids = elm.discover_ecus()
    nodes = [EcuNode(ecu_id=eid, label=label_for(eid, name_overrides))
             for eid in sorted(ecu_ids)]
    return TopologyGraph(bus_name=bus_name, nodes=nodes)

"""Transport abstraction: a byte pipe to the vehicle interface.

Every backend (Bluetooth RFCOMM, USB serial, J2534) implements this same
tiny interface so everything above it (ELM327 driver, UDS/ISO-TP layer)
never has to know which physical link it's using.
"""

from __future__ import annotations

import abc


class TransportError(Exception):
    """Raised for connect/send/recv failures at the transport layer."""


class Transport(abc.ABC):
    """Abstract byte-level link to an OBD-II / diagnostic adapter."""

    #: Human-readable name shown in the connection dialog, e.g.
    #: "Veepeak OBDCheck BLE (00:1D:A5:xx:xx:xx)".
    name: str = "transport"

    @abc.abstractmethod
    def connect(self, timeout: float = 5.0) -> None:
        """Open the link. Raise TransportError on failure."""

    @abc.abstractmethod
    def close(self) -> None:
        """Close the link. Must be safe to call multiple times."""

    @abc.abstractmethod
    def write(self, data: bytes) -> None:
        """Write raw bytes to the adapter."""

    @abc.abstractmethod
    def read_until(self, terminator: bytes, timeout: float = 2.0) -> bytes:
        """Read bytes until `terminator` is seen or timeout elapses.

        Returns whatever was read (may be shorter than expected on
        timeout — callers should treat a missing terminator as a
        recoverable comms error, not a crash).
        """

    @property
    @abc.abstractmethod
    def is_connected(self) -> bool:
        ...

    def flush_input(self) -> None:
        """Discard any bytes currently sitting in the receive buffer.

        Default no-op; transports that can support it (serial, RFCOMM)
        override this. Called before every command is sent - cheap
        ELM327 clones over Bluetooth are prone to leaving a stray
        trailing byte or two in the buffer, which can shift the framing
        of the *next* command's response just enough to make it
        unparseable. Harmless to skip for transports that can't
        implement it (e.g. J2534, which is frame-based, not a byte
        stream with this kind of drift).
        """

    def __enter__(self) -> "Transport":
        self.connect()
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()

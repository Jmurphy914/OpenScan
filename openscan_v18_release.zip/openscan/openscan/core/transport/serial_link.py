"""USB / COM-port serial transport.

Works for: USB ELM327 adapters, Windows COM ports assigned to a paired
Bluetooth SPP device (Windows exposes paired Bluetooth serial adapters as
a COM port automatically), and Linux `/dev/rfcomm*` bound devices.
"""

from __future__ import annotations

import time

from .base import Transport, TransportError

try:
    import serial  # pyserial
except ImportError:  # pragma: no cover - exercised only when dependency missing
    serial = None


class SerialTransport(Transport):
    def __init__(self, port: str, baudrate: int = 38400):
        if serial is None:
            raise TransportError(
                "pyserial is required for SerialTransport (`pip install pyserial`)"
            )
        self.port = port
        self.baudrate = baudrate
        self.name = f"Serial ({port})"
        self._ser: "serial.Serial | None" = None

    def connect(self, timeout: float = 5.0) -> None:
        try:
            self._ser = serial.Serial(
                self.port, self.baudrate, timeout=timeout, write_timeout=timeout
            )
        except Exception as exc:  # noqa: BLE001 - surface as TransportError
            raise TransportError(f"Could not open {self.port}: {exc}") from exc

    def close(self) -> None:
        if self._ser is not None:
            try:
                self._ser.close()
            finally:
                self._ser = None

    def write(self, data: bytes) -> None:
        if not self._ser:
            raise TransportError("not connected")
        self._ser.write(data)
        self._ser.flush()

    def read_until(self, terminator: bytes, timeout: float = 2.0) -> bytes:
        if not self._ser:
            raise TransportError("not connected")
        deadline = time.monotonic() + timeout
        buf = bytearray()
        while time.monotonic() < deadline:
            chunk = self._ser.read(self._ser.in_waiting or 1)
            if chunk:
                buf.extend(chunk)
                if terminator in buf:
                    break
        return bytes(buf)

    @property
    def is_connected(self) -> bool:
        return self._ser is not None and self._ser.is_open

    def flush_input(self) -> None:
        if self._ser is not None and self._ser.is_open:
            try:
                self._ser.reset_input_buffer()
            except Exception:  # noqa: BLE001 - best-effort, never fatal
                pass

    @staticmethod
    def list_ports() -> list[tuple[str, str]]:
        """Return (device, description) for every detected serial port -
        e.g. ("COM3", "USB-SERIAL CH340") or ("/dev/ttyUSB0", "FT232R
        USB UART"). The description is what makes a USB ELM327 cable
        identifiable among several COM ports in the connection dialog,
        since Windows doesn't otherwise show anything more meaningful
        than a bare port number."""
        if serial is None:
            return []
        from serial.tools import list_ports

        return [(p.device, p.description or p.device) for p in list_ports.comports()]

    @staticmethod
    def probe(device: str, timeout: float = 2.0) -> bool:
        """Best-effort check that something ELM327-like is listening on
        this port: open it, send ATI (adapter identification), and see
        if anything at all comes back. Used by the connection dialog's
        "Quick Connect" to auto-detect a USB ELM327 cable without
        requiring the user to know which COM port it landed on."""
        transport = SerialTransport(device)
        try:
            transport.connect(timeout=timeout)
            transport.write(b"ATI\r")
            response = transport.read_until(b">", timeout=timeout)
            return bool(response.strip())
        except Exception:  # noqa: BLE001 - probing failure just means "not this port"
            return False
        finally:
            transport.close()

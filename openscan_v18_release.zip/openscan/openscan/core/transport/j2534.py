"""Windows J2534 PassThru DLL binding (ctypes).

This targets vehicle interfaces (VCIs) that install a standard SAE
J2534-1 PassThru DLL registered under the Windows registry key
`HKLM\\SOFTWARE\\PassThruSupport.04.04\\<vendor GUID>`. TOPDON's ONE VCI is
marketed as J2534 pass-thru capable for its supported OEM software list;
whether it registers a fully standard-conformant DLL usable outside
TOPDON's own app is vendor-dependent — see docs/HARDWARE.md, and validate
with `J2534Transport.discover()` on your machine first.

This talks to the vehicle over raw CAN (protocol ID 5), one 8-byte frame
at a time, and leaves ISO-TP segmentation to `core/uds/isotp.py` — that
keeps this class simple and keeps our framing logic testable without
hardware (see tests/test_isotp.py). J2534 also supports a built-in
ISO15765 protocol mode that does segmentation in the DLL/firmware itself;
that's a legitimate alternative (skip IsoTpLink, feed UDS payloads
straight to PassThruWriteMsgs/ReadMsgs with ProtocolID=ISO15765) but isn't
wired up here — flag it in docs/ROADMAP.md if you'd rather use that path.

The PASSTHRU_MSG struct layout below matches every published J2534 v04.04
header (SAE J2534-1, and every vendor SDK's j2534.h that implements it —
this part of the API is standardized, unlike OEM security/routine data).
What's genuinely untested here without real hardware: exact DLL export
calling convention quirks some vendors have, and whether the ONE VCI's
DLL requires additional SConfig/IOCTL calls before accepting raw CAN
traffic. Both are exactly the kind of thing your dongles let you find out.
"""

from __future__ import annotations

import ctypes
import platform
import time

from .base import Transport, TransportError

try:
    import winreg  # type: ignore[import-not-found]  # only resolved on Windows
except ImportError:  # pragma: no cover - non-Windows import safety
    winreg = None

# --- J2534 constants (subset needed for raw CAN diagnostics) ---------------
PROTOCOL_ID_CAN = 5
PROTOCOL_ID_ISO15765 = 6

CAN_29BIT_ID = 0x00000100
ISO15765_FRAME_PAD = 0x00000040

FILTER_PASS = 0x00000001

STATUS_NOERROR = 0
STATUS_BUFFER_EMPTY = 0x10
ERR_TIMEOUT = 0x0A


class PASSTHRU_MSG(ctypes.Structure):
    """Standard SAE J2534-1 v04.04 message struct."""

    _fields_ = [
        ("ProtocolID", ctypes.c_ulong),
        ("RxStatus", ctypes.c_ulong),
        ("TxFlags", ctypes.c_ulong),
        ("Timestamp", ctypes.c_ulong),
        ("DataSize", ctypes.c_ulong),
        ("ExtraDataIndex", ctypes.c_ulong),
        ("Data", ctypes.c_ubyte * 4128),
    ]


def _discover_passthru_dlls() -> dict[str, tuple[str, str]]:
    """Return {vendor_device_name: (dll_path, bitness)} from the Windows
    registry, checking BOTH the native 64-bit and WOW6432Node 32-bit
    registry views.

    This matters because almost every vendor J2534 DLL (very likely
    including TOPDON's) is 32-bit only, and their installer registers it
    under `WOW6432Node` on a 64-bit Windows machine. A 64-bit Python
    process can enumerate that key fine but CANNOT load the DLL itself via
    ctypes (`OSError: [WinError 193] %1 is not a valid Win32 application`)
    — you'd need a 32-bit Python interpreter for that specific DLL. This
    function reports which view each entry came from so that error is
    obvious rather than a mysterious ctypes failure.
    """
    devices: dict[str, tuple[str, str]] = {}
    if winreg is None:
        return devices
    key_path = r"SOFTWARE\PassThruSupport.04.04"
    views = [
        ("64-bit", getattr(winreg, "KEY_WOW64_64KEY", 0)),
        ("32-bit", getattr(winreg, "KEY_WOW64_32KEY", 0)),
    ]
    for bitness, access_flag in views:
        try:
            root = winreg.OpenKey(
                winreg.HKEY_LOCAL_MACHINE, key_path, 0,
                winreg.KEY_READ | access_flag,
            )
        except OSError:
            continue
        i = 0
        while True:
            try:
                subkey_name = winreg.EnumKey(root, i)
            except OSError:
                break
            i += 1
            try:
                subkey = winreg.OpenKey(root, subkey_name)
                name, _ = winreg.QueryValueEx(subkey, "Name")
                dll_path, _ = winreg.QueryValueEx(subkey, "FunctionLibrary")
                devices[name] = (dll_path, bitness)
            except OSError:
                continue
    return devices


class J2534Transport(Transport):
    """Raw CAN frame transport over a vendor J2534 PassThru DLL.

    Unlike the other transports, `write`/`read_until` are not used here
    (there's no AT-command text protocol) — the UDS/ISO-TP layer talks to
    this class via `send_frame`/`recv_frame` instead. It still implements
    the Transport ABC for uniform connect/close lifecycle handling.
    """

    def __init__(self, dll_path: str, protocol_id: int = PROTOCOL_ID_CAN,
                 baudrate: int = 500000, use_29bit_id: bool = False):
        if platform.system() != "Windows":
            raise TransportError("J2534Transport is only available on Windows")
        self.dll_path = dll_path
        self.protocol_id = protocol_id
        self.baudrate = baudrate
        self.use_29bit_id = use_29bit_id
        self.name = f"J2534 ({dll_path})"
        self._dll = None
        self._device_id = ctypes.c_ulong()
        self._channel_id = ctypes.c_ulong()
        self._filter_id = ctypes.c_ulong()

    @staticmethod
    def discover() -> dict[str, tuple[str, str]]:
        """List installed J2534 devices as {name: (dll_path, bitness)}.

        `bitness` is "32-bit" or "64-bit" depending on which registry view
        the entry was found in — a 32-bit entry means you need a 32-bit
        Python interpreter to actually load that DLL (see module docstring
        on `_discover_passthru_dlls`).
        """
        return _discover_passthru_dlls()

    def _check(self, rc: int, call_name: str) -> None:
        if rc != STATUS_NOERROR:
            raise TransportError(f"{call_name} failed (J2534 status {rc:#x})")

    def connect(self, timeout: float = 5.0) -> None:
        try:
            self._dll = ctypes.WinDLL(self.dll_path)
        except OSError as exc:
            raise TransportError(f"Could not load J2534 DLL: {exc}") from exc

        rc = self._dll.PassThruOpen(None, ctypes.byref(self._device_id))
        self._check(rc, "PassThruOpen")

        flags = CAN_29BIT_ID if self.use_29bit_id else 0
        rc = self._dll.PassThruConnect(
            self._device_id,
            ctypes.c_ulong(self.protocol_id),
            ctypes.c_ulong(flags),
            ctypes.c_ulong(self.baudrate),
            ctypes.byref(self._channel_id),
        )
        self._check(rc, "PassThruConnect")

        # A pass-all filter is required by the J2534 spec before the
        # channel will deliver any received messages.
        mask_msg = PASSTHRU_MSG(ProtocolID=self.protocol_id, DataSize=4)
        pattern_msg = PASSTHRU_MSG(ProtocolID=self.protocol_id, DataSize=4)
        rc = self._dll.PassThruStartMsgFilter(
            self._channel_id,
            ctypes.c_ulong(FILTER_PASS),
            ctypes.byref(mask_msg),
            ctypes.byref(pattern_msg),
            None,
            ctypes.byref(self._filter_id),
        )
        self._check(rc, "PassThruStartMsgFilter")

    def close(self) -> None:
        if self._dll is None:
            return
        try:
            if self._channel_id.value:
                self._dll.PassThruDisconnect(self._channel_id)
            if self._device_id.value:
                self._dll.PassThruClose(self._device_id)
        finally:
            self._dll = None
            self._channel_id = ctypes.c_ulong()
            self._device_id = ctypes.c_ulong()

    # -- raw CAN frame API used directly by core/uds/isotp.py ---------------
    def send_frame(self, can_id: int, data: bytes) -> None:
        if self._dll is None:
            raise TransportError("not connected")
        if len(data) > 8:
            raise TransportError("send_frame expects a single <=8-byte CAN frame")

        msg = PASSTHRU_MSG()
        msg.ProtocolID = self.protocol_id
        msg.TxFlags = CAN_29BIT_ID if (self.use_29bit_id or can_id > 0x7FF) else 0
        id_bytes = can_id.to_bytes(4, "big")
        payload = id_bytes + data
        msg.DataSize = len(payload)
        for i, b in enumerate(payload):
            msg.Data[i] = b

        num_msgs = ctypes.c_ulong(1)
        rc = self._dll.PassThruWriteMsgs(
            self._channel_id, ctypes.byref(msg), ctypes.byref(num_msgs), ctypes.c_ulong(1000)
        )
        self._check(rc, "PassThruWriteMsgs")

    def recv_frame(self, timeout_ms: int = 100) -> tuple[int, bytes] | None:
        if self._dll is None:
            raise TransportError("not connected")

        msg = PASSTHRU_MSG()
        num_msgs = ctypes.c_ulong(1)
        rc = self._dll.PassThruReadMsgs(
            self._channel_id, ctypes.byref(msg), ctypes.byref(num_msgs),
            ctypes.c_ulong(timeout_ms),
        )
        if rc in (STATUS_BUFFER_EMPTY, ERR_TIMEOUT) or num_msgs.value == 0:
            return None
        self._check(rc, "PassThruReadMsgs")

        if msg.DataSize < 4:
            return None
        raw = bytes(msg.Data[: msg.DataSize])
        can_id = int.from_bytes(raw[:4], "big")
        payload = raw[4:]
        return can_id, payload

    def drain_rx(self, duration_ms: int = 50) -> None:
        """Discard buffered receive messages (useful right after a write,
        since many VCIs loop back the sender's own frame)."""
        deadline = time.monotonic() + duration_ms / 1000
        while time.monotonic() < deadline:
            if self.recv_frame(timeout_ms=10) is None:
                break

    # -- Transport ABC plumbing (unused for this transport's real traffic) --
    def write(self, data: bytes) -> None:
        raise TransportError("Use send_frame() on J2534Transport, not write()")

    def read_until(self, terminator: bytes, timeout: float = 2.0) -> bytes:
        raise TransportError("Use recv_frame() on J2534Transport, not read_until()")

    @property
    def is_connected(self) -> bool:
        return self._dll is not None and bool(self._channel_id.value)

"""Bluetooth Classic (SPP/RFCOMM) transport for ELM327-based adapters
such as the Veepeak OBDCheck.

Linux: uses PyBluez2's RFCOMM socket directly (no OS-level pairing dance
required beyond initial pairing/trust).
Windows: Bluetooth SPP devices show up as a COM port once paired, so on
Windows prefer `SerialTransport` with that COM port instead — this class
is Linux-only. The connection dialog auto-picks the right one per OS.
"""

from __future__ import annotations

import platform
import time

from .base import Transport, TransportError

try:
    import bluetooth as _bluez  # pybluez2, provides classic RFCOMM sockets
except ImportError:  # pragma: no cover
    _bluez = None


class BluetoothRfcommTransport(Transport):
    RFCOMM_CHANNEL = 1  # standard SPP channel used by ELM327 clones

    def __init__(self, address: str, channel: int | None = None):
        if platform.system() == "Windows":
            raise TransportError(
                "Use SerialTransport with the paired device's COM port on "
                "Windows; direct RFCOMM sockets are Linux-only here."
            )
        if _bluez is None:
            raise TransportError(
                "pybluez2 is required for BluetoothRfcommTransport "
                "(`pip install pybluez2`)"
            )
        self.address = address
        self.channel = channel or self.RFCOMM_CHANNEL
        self.name = f"Bluetooth ({address})"
        self._sock = None

    def connect(self, timeout: float = 5.0) -> None:
        try:
            self._sock = _bluez.BluetoothSocket(_bluez.RFCOMM)
            self._sock.settimeout(timeout)
            self._sock.connect((self.address, self.channel))
        except Exception as exc:  # noqa: BLE001
            raise TransportError(
                f"Could not connect to {self.address}: {exc}"
            ) from exc

    def close(self) -> None:
        if self._sock is not None:
            try:
                self._sock.close()
            finally:
                self._sock = None

    def write(self, data: bytes) -> None:
        if not self._sock:
            raise TransportError("not connected")
        self._sock.send(data)

    def read_until(self, terminator: bytes, timeout: float = 2.0) -> bytes:
        if not self._sock:
            raise TransportError("not connected")
        self._sock.settimeout(timeout)
        deadline = time.monotonic() + timeout
        buf = bytearray()
        while time.monotonic() < deadline:
            try:
                chunk = self._sock.recv(256)
            except Exception:
                break
            if not chunk:
                break
            buf.extend(chunk)
            if terminator in buf:
                break
        return bytes(buf)

    @property
    def is_connected(self) -> bool:
        return self._sock is not None

    def flush_input(self) -> None:
        if self._sock is None:
            return
        try:
            self._sock.settimeout(0.01)
            while True:
                chunk = self._sock.recv(256)
                if not chunk:
                    break
        except Exception:  # noqa: BLE001 - timeout or nothing pending; both fine
            pass

    @staticmethod
    def discover(duration: int = 8) -> list[tuple[str, str]]:
        """Return [(address, device_name), ...] of nearby Bluetooth devices."""
        if _bluez is None:
            return []
        return _bluez.discover_devices(duration=duration, lookup_names=True)

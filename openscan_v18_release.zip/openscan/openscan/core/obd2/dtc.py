"""DTC (Diagnostic Trouble Code) bit-decoding + description/cause lookup.

Decoding the 2-byte -> "P0301"-style code is fully standardized (SAE
J2012 / ISO 15031-6) and works for every OBD-II vehicle regardless of
make. The *description* and *typical causes* for generic codes (the
P0xxx "SAE-defined" series) are also public/standardized information
about what the code fundamentally means; manufacturer-specific codes
are not included here (see openscan/data/dtc_generic.json header
comment and docs/HARDWARE.md) but can be added via a DtcPlugin. Wiring
schematics are genuine vehicle-specific OEM service data and are out of
scope for this project entirely.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent.parent.parent / "data"

_LETTER = {0b00: "P", 0b01: "C", 0b10: "B", 0b11: "U"}

_dtc_data_cache: dict[str, dict] | None = None


@dataclass
class DtcInfo:
    code: str
    description: str
    causes: list[str]


def decode_dtc_bytes(data: bytes) -> list[str]:
    """Decode a raw DTC payload (N pairs of bytes) into code strings.

    A pair of 0x00 0x00 means "no code" and is skipped, matching how
    Mode 03/07 pad their response.
    """
    codes: list[str] = []
    for i in range(0, len(data) - 1, 2):
        b1, b2 = data[i], data[i + 1]
        if b1 == 0 and b2 == 0:
            continue
        letter = _LETTER[(b1 >> 6) & 0b11]
        digit1 = (b1 >> 4) & 0b11
        digit2 = b1 & 0x0F
        digit3 = (b2 >> 4) & 0x0F
        digit4 = b2 & 0x0F
        codes.append(f"{letter}{digit1}{digit2:X}{digit3:X}{digit4:X}")
    return codes


def _load_dtc_data() -> dict[str, dict]:
    global _dtc_data_cache
    if _dtc_data_cache is None:
        with open(DATA_DIR / "dtc_generic.json", encoding="utf-8") as f:
            raw = json.load(f)
        _dtc_data_cache = raw["codes"]
    return _dtc_data_cache


_NO_DESCRIPTION = (
    "No description available (likely manufacturer-specific — "
    "add a DtcPlugin with your OEM's code list)"
)


def dtc_description(code: str, extra: dict[str, str] | None = None) -> str:
    """Look up a plain-English description for a DTC.

    `extra` lets callers merge in plugin-provided (e.g. OEM-specific)
    descriptions without mutating the built-in generic table. `extra`
    is a plain {code: description} mapping for simplicity, unlike the
    richer generic table which also carries causes.
    """
    if extra and code in extra:
        return extra[code]
    entry = _load_dtc_data().get(code)
    if entry is None:
        return _NO_DESCRIPTION
    return entry.get("description", _NO_DESCRIPTION)


def dtc_causes(code: str) -> list[str]:
    """Typical, generally-known possible causes for a generic DTC.

    Returns an empty list if the code isn't in the generic table (e.g.
    manufacturer-specific) or simply doesn't have a causes list yet -
    callers should treat an empty list as "not available" rather than
    "definitely no possible causes."
    """
    entry = _load_dtc_data().get(code)
    if entry is None:
        return []
    return list(entry.get("causes", []))


def dtc_info(code: str, extra_descriptions: dict[str, str] | None = None) -> DtcInfo:
    """Convenience bundle of description + causes for a single code,
    used by the DTC panel's click-to-detail popup."""
    return DtcInfo(
        code=code,
        description=dtc_description(code, extra_descriptions),
        causes=dtc_causes(code),
    )

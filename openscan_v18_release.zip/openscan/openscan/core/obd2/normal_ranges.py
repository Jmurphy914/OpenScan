"""Best-effort "normal operating range" bands for the live-data
green/red highlighting in the dashboard's gauges and live data table.

Deliberately conservative in scope: only parameters with a genuinely
condition-independent healthy band are listed here. Most PIDs (RPM,
vehicle speed, MAP, engine load, MAF, throttle position) don't have one
fixed "normal" value at all - 3000 RPM is perfectly normal while
accelerating and alarming at a stoplight - so highlighting those
green/red from a single static range would be actively misleading
rather than helpful, and they're intentionally left out rather than
guessed at. Anything not listed here simply isn't highlighted.

Ranges assume a warmed-up engine that's running unless noted otherwise,
and are general automotive knowledge (the kind of ballpark figures a
mechanic would recognize on sight) rather than a specific manufacturer's
published spec - an individual vehicle's exact acceptable range may
differ slightly. Units are US customary, matching what the dashboard
displays (see UNIT_CONVERSIONS in pids.py).
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class NormalRange:
    lo: float
    hi: float
    note: str = ""


#: {PID name: NormalRange}. PID name must exactly match PidDefinition.name
#: (pids_generic.json) so lookups from live-data dicts work directly.
NORMAL_RANGES: dict[str, NormalRange] = {
    "Coolant Temperature": NormalRange(180, 220, "warmed-up engine"),
    "Engine Oil Temperature": NormalRange(180, 230, "warmed-up engine"),
    "Short Term Fuel Trim (Bank 1)": NormalRange(-10, 10),
    "Long Term Fuel Trim (Bank 1)": NormalRange(-10, 10),
    "Short Term Fuel Trim (Bank 2)": NormalRange(-10, 10),
    "Long Term Fuel Trim (Bank 2)": NormalRange(-10, 10),
    "EGR Error": NormalRange(-10, 10),
    "Control Module Voltage": NormalRange(13.5, 14.8, "engine running, alternator charging"),
}


def status_for(name: str, value: float) -> str | None:
    """Returns "ok" or "out_of_range" for a parameter with a defined
    normal range, or None if this parameter isn't in NORMAL_RANGES -
    callers should leave it unhighlighted (neutral) in that case rather
    than guess at a range that doesn't really exist."""
    rng = NORMAL_RANGES.get(name)
    if rng is None:
        return None
    return "ok" if rng.lo <= value <= rng.hi else "out_of_range"

"""Generic SAE J1979 Mode 01/02 PID definitions and decoding formulas.

Metadata (name/unit/byte count/formula) lives in
`openscan/data/pids_generic.json` so it can be community-edited or
extended by plugins without touching code. This module only implements
the handful of numeric formulas the SAE spec defines and the loader that
turns JSON + formula name into a callable `PidDefinition`.
"""

from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Callable

DATA_DIR = Path(__file__).resolve().parent.parent.parent / "data"


def pct_1byte(d: bytes) -> float:
    return d[0] * 100 / 255


def signed_pct_1byte(d: bytes) -> float:
    return (d[0] - 128) * 100 / 128


def signed_half_1byte(d: bytes) -> float:
    return d[0] / 2 - 64


def temp_1byte(d: bytes) -> float:
    return d[0] - 40


def raw_1byte(d: bytes) -> float:
    return float(d[0])


def raw_2byte(d: bytes) -> float:
    return d[0] * 256 + d[1]


def rpm_2byte(d: bytes) -> float:
    return (d[0] * 256 + d[1]) / 4


def maf_2byte(d: bytes) -> float:
    return (d[0] * 256 + d[1]) / 100


def voltage_2byte(d: bytes) -> float:
    return (d[0] * 256 + d[1]) / 1000


def pct_2byte(d: bytes) -> float:
    return (d[0] * 256 + d[1]) * 100 / 65535


def kpa_1byte_x3(d: bytes) -> float:
    return d[0] * 3


def fuel_rate_2byte(d: bytes) -> float:
    return (d[0] * 256 + d[1]) * 0.05


def fuel_rail_pressure_vac_2byte(d: bytes) -> float:
    """Fuel rail pressure relative to manifold vacuum (PID 0x22), kPa."""
    return (d[0] * 256 + d[1]) * 0.079


def fuel_rail_gauge_2byte(d: bytes) -> float:
    """Fuel rail gauge pressure, diesel/direct-injection (PID 0x23), kPa."""
    return (d[0] * 256 + d[1]) * 10


def fuel_rail_abs_2byte(d: bytes) -> float:
    """Fuel rail absolute pressure (PID 0x59), kPa."""
    return (d[0] * 256 + d[1]) * 10


def evap_vapor_pressure_2byte(d: bytes) -> float:
    """EVAP system vapor pressure (PID 0x32), Pa. Signed, 1/4 Pa resolution."""
    raw = d[0] * 256 + d[1]
    if raw >= 0x8000:
        raw -= 0x10000
    return raw / 4

def cat_temp_2byte(d: bytes) -> float:
    """Catalyst temperature (PIDs 0x3C-0x3F), °C."""
    return (d[0] * 256 + d[1]) / 10 - 40


def equiv_ratio_2byte(d: bytes) -> float:
    """Commanded fuel-air equivalence ratio (PID 0x44), dimensionless."""
    return (d[0] * 256 + d[1]) * 2 / 65535


def torque_pct_1byte(d: bytes) -> float:
    """Driver's demand / actual engine torque (PIDs 0x61/0x62), % of max."""
    return d[0] - 125


def injection_timing_2byte(d: bytes) -> float:
    """Fuel injection timing (PID 0x5D), degrees relative to TDC."""
    return (d[0] * 256 + d[1]) / 128 - 210


def o2_voltage_2byte(d: bytes) -> float:
    """O2 sensor voltage (PIDs 0x14-0x1B), volts. Second byte (short-term
    fuel trim for that sensor) is not represented by this single-value
    PidDefinition - see docs/ROADMAP.md if you want both values surfaced."""
    return d[0] / 200


def abs_evap_vapor_pressure_2byte(d: bytes) -> float:
    """Absolute EVAP system vapor pressure (PID 0x53), kPa. Unlike PID
    0x32 (signed, relative), this one is unsigned/absolute, 1/200 kPa
    resolution."""
    return (d[0] * 256 + d[1]) / 200


def odometer_4byte(d: bytes) -> float:
    """Odometer (PID 0xA6), km. 4 bytes, 0.1 km resolution - one of the
    few Mode 01 PIDs most vehicles built in the last several years
    actually implement for a true always-on total-distance reading,
    unlike the MIL-on/since-cleared distance counters."""
    return (d[0] * 16777216 + d[1] * 65536 + d[2] * 256 + d[3]) / 10


#: Metric -> US customary conversion, applied once at load time (see
#: load_generic_pids()) so every part of the GUI (gauges, table, freeze
#: frame, strip charts) displays US units automatically without each
#: needing its own conversion logic. Keyed by the *native* unit the SAE
#: J1979 formula produces - pids_generic.json intentionally keeps
#: documenting that native/metric unit, since that's literally what the
#: spec defines; this table is the single place metric->US conversion
#: happens. EVAP vapor pressure (native unit Pa) converts to inH2O
#: rather than psi since the values involved are tiny fractions of a
#: psi - inH2O is what US scan tools conventionally show for it.
UNIT_CONVERSIONS: dict[str, tuple[str, Callable[[float], float]]] = {
    "°C": ("°F", lambda c: c * 9 / 5 + 32),
    "km/h": ("mph", lambda kmh: kmh / 1.60934),
    "km": ("mi", lambda km: km / 1.60934),
    "kPa": ("psi", lambda kpa: kpa / 6.89476),
    "Pa": ("inH2O", lambda pa: pa / 249.089),
    "L/h": ("gal/h", lambda lph: lph * 0.264172),
}


def _convert_decode(base: Callable[[bytes], float],
                     conv: Callable[[float], float]) -> Callable[[bytes], float]:
    """Wraps a formula so its output is converted before anything else
    ever sees it - the returned value is what PidDefinition.unit
    describes, so callers never need to know a conversion happened."""
    def wrapped(d: bytes) -> float:
        return conv(base(d))
    return wrapped


FORMULAS: dict[str, Callable[[bytes], float]] = {
    "pct_1byte": pct_1byte,
    "signed_pct_1byte": signed_pct_1byte,
    "signed_half_1byte": signed_half_1byte,
    "temp_1byte": temp_1byte,
    "raw_1byte": raw_1byte,
    "raw_2byte": raw_2byte,
    "rpm_2byte": rpm_2byte,
    "maf_2byte": maf_2byte,
    "voltage_2byte": voltage_2byte,
    "pct_2byte": pct_2byte,
    "kpa_1byte_x3": kpa_1byte_x3,
    "fuel_rate_2byte": fuel_rate_2byte,
    "fuel_rail_pressure_vac_2byte": fuel_rail_pressure_vac_2byte,
    "fuel_rail_gauge_2byte": fuel_rail_gauge_2byte,
    "fuel_rail_abs_2byte": fuel_rail_abs_2byte,
    "evap_vapor_pressure_2byte": evap_vapor_pressure_2byte,
    "cat_temp_2byte": cat_temp_2byte,
    "equiv_ratio_2byte": equiv_ratio_2byte,
    "torque_pct_1byte": torque_pct_1byte,
    "injection_timing_2byte": injection_timing_2byte,
    "o2_voltage_2byte": o2_voltage_2byte,
    "abs_evap_vapor_pressure_2byte": abs_evap_vapor_pressure_2byte,
    "odometer_4byte": odometer_4byte,
}


@dataclass
class PidDefinition:
    pid: int
    name: str
    unit: str
    n_bytes: int
    decode: Callable[[bytes], float]
    #: UDS/OBD service this identifier is requested under. Every generic
    #: SAE J1979 PID here is Mode 0x01 (live data), which is why it's the
    #: default - manufacturer-specific "enhanced" PIDs contributed by
    #: plugins (see openscan/plugins/enhanced/) typically live under
    #: Mode 0x22 (UDS ReadDataByIdentifier) instead, using a 2-byte
    #: identifier rather than Mode 01's 1-byte PID. OBD2Service.read_pid()
    #: uses this to pick the right request mode and to know whether the
    #: response needs its identifier-echo bytes stripped.
    mode: int = 0x01

    def value(self, data: bytes) -> float | None:
        if len(data) < self.n_bytes:
            return None
        return self.decode(data[: self.n_bytes])


def load_generic_pids(path: Path | None = None) -> dict[int, PidDefinition]:
    path = path or (DATA_DIR / "pids_generic.json")
    with open(path, encoding="utf-8") as f:
        raw = json.load(f)
    out: dict[int, PidDefinition] = {}
    for entry in raw["pids"]:
        pid = int(entry["pid"], 16)
        formula = FORMULAS[entry["formula"]]
        unit = entry["unit"]
        decode = formula
        if unit in UNIT_CONVERSIONS:
            new_unit, conv = UNIT_CONVERSIONS[unit]
            decode = _convert_decode(formula, conv)
            unit = new_unit
        out[pid] = PidDefinition(
            pid=pid,
            name=entry["name"],
            unit=unit,
            n_bytes=entry["bytes"],
            decode=decode,
        )
    return out

"""High-level generic OBD-II service (SAE J1979 Modes 01-0A).

This is the layer that works identically on the Veepeak (or any ELM327
adapter) with zero plugins — see docs/HARDWARE.md.
"""

from __future__ import annotations

import logging
import time

from ..elm327 import ELM327
from .dtc import decode_dtc_bytes, dtc_description
from .monitors import MonitorStatus, decode_monitor_status
from .pids import PidDefinition, load_generic_pids

logger = logging.getLogger(__name__)


class OBD2Service:
    def __init__(self, elm: ELM327):
        self.elm = elm
        self.pids: dict[int, PidDefinition] = load_generic_pids()
        #: Populated by refresh_supported_pids(); None until the first scan.
        #: read_live_data() uses this to avoid wasting every poll cycle on
        #: PIDs this vehicle doesn't implement (see supported_pids()).
        self.active_pids: set[int] | None = None

    # -- Mode 01: live data --------------------------------------------
    def read_pid(self, pid: int) -> dict[int, float]:
        """Read one PID; returns {ecu_id: value} for every ECU that answers
        (some PIDs, e.g. per-bank fuel trim, only make sense from one ECU;
        multiple entries usually means multiple banks/modules report it).

        Uses whichever service the PidDefinition declares (mode 0x01 for
        every generic SAE J1979 PID; manufacturer-specific "enhanced"
        PIDs from plugins typically declare mode 0x22 - UDS
        ReadDataByIdentifier - instead).
        """
        pid_def = self.pids.get(pid)
        mode = pid_def.mode if pid_def is not None else 0x01
        responses = self.elm.request(mode, pid)
        out: dict[int, float] = {}
        for r in responses:
            if pid_def is None:
                continue
            data = r.data
            if mode != 0x01 and len(data) >= 2:
                # _parse_lines() only strips the PID byte for Mode
                # 01/02 requests; a Mode 0x22 response instead echoes
                # the full 2-byte identifier ahead of the payload, so
                # strip that here before handing bytes to the formula.
                data = data[2:]
            value = pid_def.value(data)
            if value is not None:
                out[r.ecu_id] = value
        return out

    #: Small pause between consecutive PID requests within one
    #: read_live_data() cycle. Cheap Bluetooth ELM327 clones can choke
    #: on rapid back-to-back requests (queried once in isolation - like a
    #: manual DTC/VIN/readiness refresh - works fine, but hammering
    #: through dozens of PIDs with no gap between them starts silently
    #: failing every single one). Costs at most ~1.2s across the full
    #: 58-PID generic table; cheap insurance against that failure mode.
    INTER_PID_DELAY_S = 0.02

    def read_live_data(self, pids: list[int] | None = None) -> dict[int, dict[str, float]]:
        """Read several PIDs and return {ecu_id: {pid_name: value}}.

        A failure reading any single PID (timeout, transient bus error,
        adapter hiccup) is logged and skipped rather than aborting the
        whole call — otherwise one bad PID blanks out every value that
        already read successfully this cycle, which is exactly the kind
        of bug that makes a dashboard look like it's "only getting 3
        readings" when really most of them are fine.
        """
        if pids is None:
            base = sorted(self.active_pids) if self.active_pids is not None else list(self.pids.keys())
            # supported_pids() only probes Mode 01's bitmask, so it can
            # never confirm a manufacturer-specific Mode 0x22 "enhanced"
            # PID as supported - always attempt those too, alongside
            # whatever Mode 01 set was actually confirmed/known. The
            # per-PID try/except below silently skips whichever enhanced
            # PIDs this particular vehicle doesn't implement.
            enhanced = [p for p, d in self.pids.items() if d.mode != 0x01]
            pids = sorted(set(base) | set(enhanced))
        result: dict[int, dict[str, float]] = {}
        for i, pid in enumerate(pids):
            pid_def = self.pids.get(pid)
            if pid_def is None:
                continue
            try:
                readings = self.read_pid(pid)
            except Exception:  # noqa: BLE001 - one bad PID must not kill the cycle
                logger.debug("read_pid(0x%02X) failed", pid, exc_info=True)
                continue
            for ecu_id, value in readings.items():
                result.setdefault(ecu_id, {})[pid_def.name] = value
            if i < len(pids) - 1 and self.INTER_PID_DELAY_S:
                time.sleep(self.INTER_PID_DELAY_S)
        return result

    def supported_pids(self) -> set[int]:
        """Query Mode 01 PID 00/20/40/... bitmasks to find which PIDs this
        vehicle actually implements, intersected with our known table.

        Each probe retries a couple of times before being treated as
        "not supported" - the very first requests right after a fresh
        connection are exactly where bus/adapter flakiness tends to bite
        hardest, and a probe that legitimately failed here used to
        silently and permanently narrow what the whole dashboard could
        ever show (see refresh_supported_pids()).
        """
        supported: set[int] = set()
        for probe in (0x00, 0x20, 0x40, 0x60, 0x80, 0xA0, 0xC0):
            try:
                responses = self.elm.request_with_retry(0x01, probe, attempts=2)
            except Exception:  # noqa: BLE001
                logger.debug("supported_pids probe 0x%02X failed", probe, exc_info=True)
                continue
            for r in responses:
                if len(r.data) < 4:
                    continue
                bitmask = int.from_bytes(r.data[:4], "big")
                for i in range(32):
                    if bitmask & (1 << (31 - i)):
                        supported.add(probe + i + 1)
                # If this probe's own "next block supported" bit (bit 0,
                # i.e. PID probe+32) isn't set, no need to query further
                # blocks - but harmless to continue since request() simply
                # returns nothing for probes the vehicle doesn't answer.
        return supported & set(self.pids.keys())

    def refresh_supported_pids(self) -> set[int] | None:
        """Scan and cache the supported-PID set as `self.active_pids`,
        used by read_live_data()'s default. Call this once after connect
        (VehicleSession.connect() does this automatically), and again
        any time the user hits "rescan" in the dashboard.

        Every real OBD-II vehicle supports at least a handful of Mode 01
        PIDs (PID 0x00 itself is mandatory), so an empty result here
        almost always means the scan itself failed (bus noise, adapter
        hiccup, scanned too soon after connecting) rather than "this
        vehicle supports nothing." Caching an empty set as active_pids
        would otherwise permanently blank every future live-data poll,
        which is exactly the bug reported against a real 2016 Corolla -
        so an empty scan leaves active_pids as None (falls back to
        trying every known PID) instead of locking in a bad result.
        """
        result = self.supported_pids()
        if result:
            self.active_pids = result
        else:
            logger.warning(
                "supported_pids() scan came back empty - keeping the full "
                "PID list active rather than caching a suspicious 'nothing "
                "supported' result. Try refresh_supported_pids() again once "
                "the adapter/bus has settled."
            )
        return self.active_pids

    # -- Mode 01 PID 01: MIL / DTC count / readiness monitors --------------
    def get_monitor_status(self) -> dict[int, MonitorStatus]:
        """Returns {ecu_id: MonitorStatus} — MIL on/off, confirmed DTC
        count, and per-monitor supported/complete flags (the same data
        commercial tools show as "I/M Readiness")."""
        responses = self.elm.request(0x01, 0x01)
        out: dict[int, MonitorStatus] = {}
        for r in responses:
            if len(r.data) >= 4:
                out[r.ecu_id] = decode_monitor_status(r.data[:4])
        return out

    # -- Mode 02: freeze frame --------------------------------------------
    #: Common PIDs worth checking in a freeze frame snapshot - a small,
    #: near-universally-supported subset rather than every generic PID
    #: (freeze frame storage varies by ECU and querying dozens of PIDs
    #: that were never captured just wastes time).
    FREEZE_FRAME_PIDS = [0x04, 0x05, 0x0B, 0x0C, 0x0D, 0x0F, 0x10, 0x11]

    def read_freeze_frame(self, pid: int, frame: int = 0) -> dict[int, float]:
        pid_def = self.pids.get(pid)
        responses = self.elm.request_raw(f"02{pid:02X}{frame:02X}")
        out: dict[int, float] = {}
        for r in responses:
            if pid_def is None:
                continue
            # freeze frame responses carry an extra frame-number byte
            value = pid_def.value(r.data[1:]) if len(r.data) > 1 else None
            if value is not None:
                out[r.ecu_id] = value
        return out

    def read_freeze_frame_snapshot(self, frame: int = 0,
                                    pids: list[int] | None = None
                                    ) -> dict[int, dict[str, float]]:
        """Read a curated set of freeze frame PIDs and return
        {ecu_id: {pid_name: value}}, mirroring read_live_data()'s shape."""
        pids = pids or self.FREEZE_FRAME_PIDS
        result: dict[int, dict[str, float]] = {}
        for pid in pids:
            pid_def = self.pids.get(pid)
            if pid_def is None:
                continue
            try:
                readings = self.read_freeze_frame(pid, frame=frame)
            except Exception:  # noqa: BLE001
                logger.debug("read_freeze_frame(0x%02X) failed", pid, exc_info=True)
                continue
            for ecu_id, value in readings.items():
                result.setdefault(ecu_id, {})[pid_def.name] = value
        return result

    def get_freeze_frame_dtc(self, frame: int = 0,
                              extra_descriptions: dict[str, str] | None = None
                              ) -> dict[int, tuple[str, str] | None]:
        """The DTC that triggered a given freeze frame (Mode 02 PID 0x02)."""
        responses = self.elm.request_raw(f"0202{frame:02X}")
        out: dict[int, tuple[str, str] | None] = {}
        for r in responses:
            if len(r.data) < 3:
                out[r.ecu_id] = None
                continue
            codes = decode_dtc_bytes(r.data[1:3])
            if codes:
                out[r.ecu_id] = (codes[0], dtc_description(codes[0], extra_descriptions))
            else:
                out[r.ecu_id] = None
        return out

    # -- Mode 03/07: DTCs --------------------------------------------------
    def get_dtcs(self, pending: bool = False,
                 extra_descriptions: dict[str, str] | None = None
                 ) -> dict[int, list[tuple[str, str]]]:
        """Returns {ecu_id: [(code, description), ...]}.

        Uses request_with_retry(): a single empty/garbled response to a
        one-off DTC read (as opposed to continuous live-data polling)
        is worth retrying rather than reporting "no codes" when the
        vehicle may actually have one.
        """
        mode = 0x07 if pending else 0x03
        responses = self.elm.request_with_retry(mode, attempts=3)
        out: dict[int, list[tuple[str, str]]] = {}
        for r in responses:
            codes = decode_dtc_bytes(r.data)
            out[r.ecu_id] = [(c, dtc_description(c, extra_descriptions)) for c in codes]
        return out

    # -- Mode 0A: permanent DTCs -------------------------------------------
    def get_permanent_dtcs(self, extra_descriptions: dict[str, str] | None = None
                            ) -> dict[int, list[tuple[str, str]]]:
        responses = self.elm.request_with_retry(0x0A, attempts=3)
        out: dict[int, list[tuple[str, str]]] = {}
        for r in responses:
            codes = decode_dtc_bytes(r.data)
            out[r.ecu_id] = [(c, dtc_description(c, extra_descriptions)) for c in codes]
        return out

    # -- Mode 04: clear DTCs ------------------------------------------------
    def clear_dtcs(self) -> bool:
        responses = self.elm.request(0x04)
        # A clean clear typically yields an empty/ack response per ECU;
        # treat "no explicit error" as success since ELM327 filters most
        # negative responses out already in _parse_lines().
        return True if responses is not None else False

    # -- Mode 09: vehicle info ------------------------------------------------
    def get_vin(self) -> str | None:
        responses = self.elm.request(0x09, 0x02)
        for r in responses:
            raw = r.data
            # VIN response includes a leading "number of data items" byte
            # on some adapters; strip non-printable bytes defensively.
            text = bytes(b for b in raw if 32 <= b < 127).decode("ascii", errors="ignore")
            if len(text) >= 11:
                return text[-17:] if len(text) >= 17 else text
        return None

    def get_calibration_id(self) -> str | None:
        responses = self.elm.request(0x09, 0x04)
        for r in responses:
            text = bytes(b for b in r.data if 32 <= b < 127).decode("ascii", errors="ignore")
            if text:
                return text
        return None

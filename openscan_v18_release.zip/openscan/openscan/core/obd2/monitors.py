"""Mode 01 PID 01 decoding: MIL status, confirmed DTC count, and OBD
"readiness monitor" completion state — the same data behind every scan
tool's "I/M Readiness" or "Emissions Readiness" screen, and the thing
most auto parts store OBD-II checkers actually show. Fully standardized
(SAE J1979 / ISO 15031-5), works on any vehicle, no plugins needed.

Byte layout (4 bytes, byte indices 0-3):

Byte 0: bit 7 = MIL on/off, bits 6-0 = number of confirmed DTCs.
Byte 1: bit 3 = ignition type (0 = spark, 1 = compression/diesel).
        bits 0-2 = "continuous" monitors SUPPORTED (misfire, fuel system,
        components); bits 4-6 = same three monitors NOT COMPLETE (this
        polarity is inverted: 0 means the test *has* completed, 1 means
        it hasn't run yet this drive cycle).
Bytes 2-3: the "non-continuous" monitors, using the correct subset of
        11 possible tests for spark-ignition vs. compression-ignition
        engines (byte 2 = supported bitmask, byte 3 = not-complete
        bitmask, same bit order, same inverted-complete polarity as
        above).
"""

from __future__ import annotations

from dataclasses import dataclass, field

# (bit index, name) - shared across spark and compression ignition per SAE J1979.
_CONTINUOUS_MONITORS = [
    (0, "Misfire"),
    (1, "Fuel System"),
    (2, "Components"),
]

_SPARK_MONITORS = [
    (0, "Catalyst"),
    (1, "Heated Catalyst"),
    (2, "Evaporative System"),
    (3, "Secondary Air System"),
    (4, "A/C Refrigerant"),
    (5, "Oxygen Sensor"),
    (6, "Oxygen Sensor Heater"),
    (7, "EGR System"),
]

_COMPRESSION_MONITORS = [
    (0, "NMHC Catalyst"),
    (1, "NOx/SCR Monitor"),
    (2, "Reserved"),
    (3, "Boost Pressure"),
    (4, "Reserved"),
    (5, "Exhaust Gas Sensor"),
    (6, "PM Filter Monitoring"),
    (7, "EGR/VVT System"),
]


@dataclass
class MonitorResult:
    name: str
    supported: bool
    complete: bool


@dataclass
class MonitorStatus:
    mil_on: bool
    dtc_count: int
    ignition_type: str  # "spark" or "compression"
    monitors: list[MonitorResult] = field(default_factory=list)

    def incomplete_count(self) -> int:
        return sum(1 for m in self.monitors if m.supported and not m.complete)


def decode_monitor_status(data: bytes) -> MonitorStatus:
    if len(data) < 4:
        raise ValueError("monitor status requires 4 bytes")
    a, b, c, d = data[0], data[1], data[2], data[3]

    mil_on = bool(a & 0x80)
    dtc_count = a & 0x7F
    ignition_type = "compression" if (b & 0x08) else "spark"

    monitors: list[MonitorResult] = []
    for bit, name in _CONTINUOUS_MONITORS:
        supported = bool(b & (1 << bit))
        not_complete = bool(b & (1 << (bit + 4)))
        monitors.append(MonitorResult(name, supported, complete=not not_complete))

    non_continuous = _COMPRESSION_MONITORS if ignition_type == "compression" else _SPARK_MONITORS
    for bit, name in non_continuous:
        if name == "Reserved":
            continue
        supported = bool(c & (1 << bit))
        not_complete = bool(d & (1 << bit))
        monitors.append(MonitorResult(name, supported, complete=not not_complete))

    return MonitorStatus(mil_on=mil_on, dtc_count=dtc_count,
                          ignition_type=ignition_type, monitors=monitors)

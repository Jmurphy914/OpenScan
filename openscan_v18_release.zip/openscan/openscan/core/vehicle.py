"""Vehicle session: ties transport + ELM327/UDS + OBD2Service + topology
together into the single object the GUI talks to.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from .elm327 import ELM327
from .obd2.service import OBD2Service
from .plugin_api import PluginRegistry
from .transport.base import Transport
from .uds.topology import TopologyGraph, discover_topology
from .uds.uds import UDSClient


@dataclass
class VehicleSession:
    transport: Transport
    plugins: PluginRegistry = field(default_factory=PluginRegistry)

    elm: ELM327 = field(init=False)
    obd2: OBD2Service = field(init=False)
    uds: UDSClient = field(init=False)
    vin: str | None = field(default=None, init=False)
    topology: TopologyGraph | None = field(default=None, init=False)

    #: Manually entered by the user in the Vehicle Info tab. Auto-VIN-decode
    #: (turning a VIN into make/model/year) needs a reference database this
    #: project doesn't ship, and VIN read itself sometimes fails on real
    #: hardware (garbled response, vehicle doesn't support Mode 09, etc.),
    #: so these are plain user-editable fields rather than anything derived.
    #: Kept here (not just in the GUI) since future OEM plugins will want
    #: to key security-access algorithms / routine tables off `make`.
    vehicle_make: str | None = field(default=None, init=False)
    vehicle_model: str | None = field(default=None, init=False)
    vehicle_year: str | None = field(default=None, init=False)

    #: Most recent live-data poll, {ecu_id: {pid_name: value}} - published
    #: by the dashboard each cycle so other tabs (topology's per-node
    #: click detail) can show "what does this specific module report"
    #: without needing their own polling loop or direct dashboard access.
    last_live_data: dict[int, dict[str, float]] = field(default_factory=dict, init=False)

    def __post_init__(self) -> None:
        self.elm = ELM327(self.transport)

    def set_vehicle_info(self, vin: str | None = None, make: str | None = None,
                          model: str | None = None, year: str | None = None) -> None:
        """Manually set/override vehicle identity from the GUI. Any
        argument left as None leaves that field unchanged."""
        if vin is not None:
            self.vin = vin or None
        if make is not None:
            self.vehicle_make = make or None
        if model is not None:
            self.vehicle_model = model or None
        if year is not None:
            self.vehicle_year = year or None

    def connect(self) -> None:
        self.elm.connect()
        self.elm.detect_protocol()
        self.obd2 = OBD2Service(self.elm)
        # Only pulls in manufacturer-specific enhanced PID plugins that
        # match the declared make (set via the connection dialog or the
        # Vehicle Info tab) - see PluginRegistry.merged_pids_for_make().
        self.obd2.pids.update(self.plugins.merged_pids_for_make(self.vehicle_make))
        self.uds = UDSClient(self.elm)
        # A successful auto-read is more authoritative than anything
        # typed in beforehand (it came straight from the vehicle), so it
        # overwrites a pre-entered VIN - but a *failed* auto-read (empty/
        # None) must NOT wipe out a VIN the user already entered in the
        # connection dialog. main_window.py checks self.vin after
        # connect() and prompts for it if it's still empty.
        auto_vin = self.obd2.get_vin()
        if auto_vin:
            self.vin = auto_vin
        # Scan once up front so live-data polling only queries (and the
        # dashboard only shows) PIDs this specific vehicle actually
        # implements, instead of blindly querying every generic PID we
        # know about every single poll cycle.
        self.obd2.refresh_supported_pids()

    def disconnect(self) -> None:
        self.elm.close()

    def refresh_topology(self) -> TopologyGraph:
        self.topology = discover_topology(self.elm)
        return self.topology

    def dtc_descriptions_extra(self) -> dict[str, str]:
        return self.plugins.merged_dtc_descriptions()

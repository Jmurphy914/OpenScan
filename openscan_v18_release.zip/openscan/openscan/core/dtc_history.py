"""Persistent DTC history - a running log of every code ever seen on a
vehicle, kept across app restarts (unlike the DTC panel's live
read/clear view, which only shows what's *currently* stored on the
ECU). Useful for tracking an intermittent problem that comes and goes,
or codes that got cleared before you had a chance to note them down.

Stored as a plain JSON file rather than a database - this project has
no other persistence needs, so a full DB would be overkill. One entry
per (code, VIN) pair; re-seeing the same code just bumps times_seen and
last_seen rather than creating a duplicate row.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

#: Overridable for tests - defaults to a per-user config directory so a
#: fresh checkout/reinstall doesn't wipe history, and multiple OpenScan
#: checkouts on the same machine share one history file.
DEFAULT_HISTORY_PATH = Path.home() / ".openscan" / "dtc_history.json"


@dataclass
class HistoryEntry:
    code: str
    description: str
    vin: str | None
    first_seen: str
    last_seen: str
    times_seen: int


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def _load_raw(path: Path) -> list[dict]:
    if not path.exists():
        return []
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, OSError):
        # A corrupted/partially-written history file shouldn't crash the
        # app or block new codes from being recorded - start fresh
        # rather than raise.
        return []


def _save_raw(path: Path, entries: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(entries, f, indent=2)


def record_seen(codes: list[tuple[str, str]], vin: str | None = None,
                path: Path | None = None) -> None:
    """Record that each (code, description) pair in `codes` was just
    observed on the vehicle identified by `vin` (None if unknown -
    entries with no VIN are still tracked, just not attributable to a
    specific vehicle later)."""
    path = path or DEFAULT_HISTORY_PATH
    entries = _load_raw(path)
    by_key = {(e["code"], e.get("vin")): e for e in entries}
    now = _now_iso()
    for code, description in codes:
        key = (code, vin)
        existing = by_key.get(key)
        if existing is None:
            existing = {
                "code": code,
                "description": description,
                "vin": vin,
                "first_seen": now,
                "last_seen": now,
                "times_seen": 1,
            }
            by_key[key] = existing
            entries.append(existing)
        else:
            existing["last_seen"] = now
            existing["times_seen"] = existing.get("times_seen", 1) + 1
            # Keep the newest description in case a plugin/extra
            # description became available since this code was first seen.
            existing["description"] = description
    _save_raw(path, entries)


def load_history(vin: str | None = None, path: Path | None = None) -> list[HistoryEntry]:
    """All recorded history, optionally filtered to one VIN. Most
    recently seen first."""
    path = path or DEFAULT_HISTORY_PATH
    entries = _load_raw(path)
    if vin is not None:
        entries = [e for e in entries if e.get("vin") == vin]
    entries.sort(key=lambda e: e.get("last_seen", ""), reverse=True)
    return [HistoryEntry(**e) for e in entries]


def clear_history(path: Path | None = None) -> None:
    path = path or DEFAULT_HISTORY_PATH
    _save_raw(path, [])

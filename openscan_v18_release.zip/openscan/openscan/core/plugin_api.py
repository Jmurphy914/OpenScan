"""Plugin interfaces.

OpenScan's core is deliberately limited to open, standardized protocol
layers (generic OBD-II, ISO-TP/UDS framing). Anything make/model-specific
— extra PIDs, extra DTC descriptions, security-access seed/key algorithms,
or bidirectional routine tables — is supplied by plugins, so that:

1. The core project stays free of proprietary OEM data nobody has the
   right to redistribute.
2. Users/shops with legitimate access to that data (service manuals,
   their own reverse-engineering, licensed tools) can plug it in without
   forking the whole app.

A plugin is a Python module placed in `openscan/plugins/` exposing a
top-level `register(registry: PluginRegistry) -> None` function.
"""

from __future__ import annotations

import abc
from dataclasses import dataclass, field

from .obd2.pids import PidDefinition
from .uds.uds import RoutineDefinition


class PidPlugin(abc.ABC):
    """Adds extra (typically manufacturer-specific Mode 22) PIDs/DIDs.

    Set `make_aliases` to a set of lowercase make names (e.g.
    {"toyota", "lexus", "scion"}) so this plugin only activates for a
    vehicle whose declared make matches - see
    PluginRegistry.merged_pids_for_make(). Querying another brand's
    enhanced PIDs every poll cycle would just waste bus time (and cheap
    Bluetooth adapters' patience) for no chance of a real answer.
    Leave as None for a plugin meant to apply to any vehicle.
    """

    make_aliases: set[str] | None = None

    @abc.abstractmethod
    def pids(self) -> dict[int, PidDefinition]:
        ...


class DtcPlugin(abc.ABC):
    """Adds descriptions for manufacturer-specific DTCs."""

    @abc.abstractmethod
    def descriptions(self) -> dict[str, str]:
        ...


class SecurityAlgoPlugin(abc.ABC):
    """Computes a UDS SecurityAccess key from a seed for one make's
    algorithm. OpenScan ships none of these — you must supply your own,
    sourced legally (e.g. from your own reverse engineering of a vehicle
    you own, or a licensed source)."""

    make: str = "unknown"

    @abc.abstractmethod
    def compute_key(self, seed: bytes, level: int) -> bytes:
        ...


class RoutinePlugin(abc.ABC):
    """Supplies named bidirectional routines (actuator tests, relearns,
    resets) with their real routine IDs/parameters for specific
    make/model/ECU combinations."""

    make: str = "unknown"

    @abc.abstractmethod
    def routines(self) -> dict[str, RoutineDefinition]:
        ...


@dataclass
class PluginRegistry:
    pid_plugins: list[PidPlugin] = field(default_factory=list)
    dtc_plugins: list[DtcPlugin] = field(default_factory=list)
    security_algo_plugins: dict[str, SecurityAlgoPlugin] = field(default_factory=dict)
    routine_plugins: list[RoutinePlugin] = field(default_factory=list)

    def register_pid_plugin(self, plugin: PidPlugin) -> None:
        self.pid_plugins.append(plugin)

    def register_dtc_plugin(self, plugin: DtcPlugin) -> None:
        self.dtc_plugins.append(plugin)

    def register_security_algo(self, plugin: SecurityAlgoPlugin) -> None:
        self.security_algo_plugins[plugin.make] = plugin

    def register_routine_plugin(self, plugin: RoutinePlugin) -> None:
        self.routine_plugins.append(plugin)

    def merged_pids(self) -> dict[int, PidDefinition]:
        out: dict[int, PidDefinition] = {}
        for p in self.pid_plugins:
            out.update(p.pids())
        return out

    def merged_pids_for_make(self, make: str | None) -> dict[int, PidDefinition]:
        """Like merged_pids(), but skips any manufacturer-specific
        plugin (make_aliases set) unless the declared vehicle make
        matches. Plugins with make_aliases left as None are treated as
        universal and always included."""
        norm = (make or "").strip().lower()
        out: dict[int, PidDefinition] = {}
        for p in self.pid_plugins:
            aliases = p.make_aliases
            if aliases is None or (norm and norm in aliases):
                out.update(p.pids())
        return out

    def merged_dtc_descriptions(self) -> dict[str, str]:
        out: dict[str, str] = {}
        for p in self.dtc_plugins:
            out.update(p.descriptions())
        return out

    def security_algo_for(self, make: str) -> SecurityAlgoPlugin | None:
        return self.security_algo_plugins.get(make)

"""ELM327 AT-command driver.

Wraps any Transport (Bluetooth RFCOMM or serial) that talks the ELM327
command set, which is what the Veepeak adapter (and virtually every
consumer Bluetooth OBD-II dongle) implements. Handles adapter
initialization, protocol auto-detection, and raw request/response framing
for both single-frame and multi-ECU (functional-address) queries.

ELM327 is a strict one-command-at-a-time serial protocol - it has no way
to distinguish an interleaved command from garbage. OpenScan's GUI runs
live-data polling continuously on a background QThread while the user
can simultaneously trigger one-off reads (DTCs, topology discovery,
readiness monitors, VIN) from the main thread's button clicks. Without
coordination, both can end up writing to the same serial/Bluetooth
socket at once, corrupting both requests - which looks exactly like
"random intermittent" garbled results on real hardware, independent of
any actual bus noise. `_send_raw()` is the single choke point every
request funnels through, so a lock there serializes all adapter access
regardless of which thread initiated it.
"""

from __future__ import annotations

import re
import threading
import time
from collections import deque
from dataclasses import dataclass

from .transport.base import Transport, TransportError

PROMPT = b">"

#: How many recent command/response pairs to keep for the Adapter Log tab.
LOG_CAPACITY = 300


class ELM327Error(Exception):
    pass


@dataclass
class OBDResponse:
    """One ECU's answer to a request, prior to any PID-specific decoding."""

    ecu_id: int          # e.g. 0x7E8 for the first responder on ISO 15765
    mode: int
    pid: int | None
    data: bytes           # payload bytes after mode/pid


@dataclass
class LogEntry:
    timestamp: float
    command: str
    response: str


class ELM327:
    """Talks AT commands + OBD-II requests over a Transport."""

    #: Known ELM327 response-header ranges for the three OBD-II protocol
    #: families. Used to tell apart which ECU answered on a multi-drop bus.
    ISO15765_11BIT_RESP_BASE = 0x7E8   # responses to 0x7DF requests -> 0x7E8..0x7EF
    ISO15765_11BIT_REQ = 0x7DF

    def __init__(self, transport: Transport):
        self.transport = transport
        self.protocol: str | None = None
        #: Serializes all adapter I/O across threads - see module docstring.
        self._io_lock = threading.RLock()
        #: Recent raw command/response pairs, for the GUI's Adapter Log tab
        #: and for diagnosing real-hardware issues without guessing blind.
        self._log: deque[LogEntry] = deque(maxlen=LOG_CAPACITY)

    # -- lifecycle -----------------------------------------------------
    def connect(self, timeout: float = 5.0) -> None:
        self.transport.connect(timeout=timeout)
        self._reset()
        self._init_adapter()

    def close(self) -> None:
        self.transport.close()

    def get_log(self) -> list[LogEntry]:
        """Snapshot of recent raw adapter traffic, oldest first."""
        with self._io_lock:
            return list(self._log)

    def clear_log(self) -> None:
        with self._io_lock:
            self._log.clear()

    # -- low level AT command I/O ---------------------------------------
    def _send_raw(self, command: str, timeout: float = 2.0) -> str:
        # Held for the full write+read round trip, not just the write -
        # otherwise two threads could still interleave a write with
        # another thread's read of a *different* command's response.
        with self._io_lock:
            # Clear any stray bytes left in the receive buffer before
            # sending - a common source of "works once, then garbles
            # everything after" on cheap Bluetooth ELM327 clones, since a
            # trailing byte from one response can shift the framing of
            # the very next one just enough to make it unparseable.
            self.transport.flush_input()
            payload = (command.strip() + "\r").encode("ascii")
            self.transport.write(payload)
            raw = self.transport.read_until(PROMPT, timeout=timeout)
            text = raw.decode("ascii", errors="ignore")
            # Strip echo of the command (ELM327 echoes by default unless
            # ATE0 has been set), the trailing '>' prompt, and blank lines.
            text = text.replace(command.strip(), "", 1)
            text = text.replace(">", "").strip()
            self._log.append(LogEntry(timestamp=time.time(), command=command.strip(),
                                       response=text))
        return text

    def _reset(self) -> None:
        self._send_raw("ATZ", timeout=3.0)   # reset
        time.sleep(0.5)

    def _init_adapter(self) -> None:
        for cmd in (
            "ATE0",      # echo off
            "ATL0",      # linefeeds off
            "ATS1",      # spaces ON - _parse_lines() splits on whitespace to
                         # separate the CAN header from the data bytes; with
                         # spaces off the adapter runs everything together
                         # into one unbroken hex string and every response
                         # line becomes unparseable.
            "ATH1",      # headers ON - we need response IDs for topology
            "ATSP0",     # auto-detect protocol
        ):
            resp = self._send_raw(cmd)
            if "?" in resp:
                raise ELM327Error(f"Adapter rejected init command {cmd!r}: {resp!r}")

        # CAN auto-formatting ON - best effort only. Asks the adapter to
        # strip ISO-TP framing (the PCI/length byte) from CAN responses
        # itself. Not universally supported (older/cheaper clones can
        # reject it with "?"), so failure here is NOT fatal - unlike the
        # commands above, this one is not load-bearing: real hardware has
        # shown the PCI byte present in responses regardless of this
        # setting, so _parse_lines() strips it defensively either way.
        self._send_raw("ATCAF1")

    def detect_protocol(self) -> str:
        """Force a protocol probe by sending a Mode 01 PID 00 request."""
        self.request(0x01, 0x00)
        resp = self._send_raw("ATDPN")
        self.protocol = resp.strip()
        return self.protocol

    # -- request/response -------------------------------------------------
    def request(self, mode: int, pid: int | None = None,
                timeout: float = 2.0) -> list[OBDResponse]:
        """Send a Mode/PID request and return one OBDResponse per
        responding ECU (multiple entries => multiple modules on the bus,
        which is exactly the raw material `core/uds/topology.py` uses).
        """
        if pid is not None:
            cmd = f"{mode:02X}{pid:02X}"
        else:
            cmd = f"{mode:02X}"
        raw = self._send_raw(cmd, timeout=timeout)
        return self._parse_lines(raw, mode)

    def raw_command(self, command: str, timeout: float = 2.0) -> str:
        """Send any raw AT command or hex OBD/UDS request string exactly
        as typed and return the adapter's raw text response, with no
        parsing at all.

        This is the "advanced/custom command" escape hatch professional
        tools expose - useful for probing things this project doesn't
        (and, for manufacturer-specific requests, can't responsibly)
        ship a curated wrapper for, like SAE J1979 Mode 0x08 actuator
        tests (standardized as a *mode*, but the Test IDs within it are
        not standardized in practice and vary per vehicle - see
        docs/HARDWARE.md and the Bidirectional Tests tab's warning
        text). Goes through the same _io_lock/flush_input path as every
        other request, so it's safe to use even while live-data polling
        is running in the background.
        """
        return self._send_raw(command, timeout=timeout)

    def request_raw(self, hex_payload: str, timeout: float = 2.0) -> list[OBDResponse]:
        """Send an arbitrary hex payload (for UDS services not covered by
        the Mode/PID convenience wrapper above, e.g. Mode 22/2E/31)."""
        mode = int(hex_payload[:2], 16)
        raw = self._send_raw(hex_payload, timeout=timeout)
        return self._parse_lines(raw, mode)

    def request_with_retry(self, mode: int, pid: int | None = None,
                            attempts: int = 3, retry_delay: float = 0.3,
                            timeout: float = 2.0) -> list[OBDResponse]:
        """Like request(), but retries a couple of times on an empty
        response before giving up.

        Cheap Bluetooth ELM327 clones (and noisy CAN buses) are prone to
        dropping an individual request/response round trip here and
        there - a query that would normally succeed comes back with no
        data purely due to transient bus/adapter flakiness, not because
        the vehicle doesn't support it. For anything that only runs
        occasionally (DTC reads, ECU discovery, the one-time supported-PID
        scan at connect) it's worth a couple of retries rather than
        treating the first empty result as gospel. Not used for routine
        live-data polling, where retrying every PID every cycle would
        make the dashboard noticeably laggy.
        """
        last: list[OBDResponse] = []
        for attempt in range(attempts):
            last = self.request(mode, pid, timeout=timeout)
            if last:
                return last
            if attempt < attempts - 1:
                time.sleep(retry_delay)
        return last

    def _parse_lines(self, raw: str, sent_mode: int) -> list[OBDResponse]:
        responses: list[OBDResponse] = []
        for line in raw.splitlines():
            line = line.strip()
            if not line or "NO DATA" in line.upper() or "SEARCHING" in line.upper():
                continue
            if "ERROR" in line.upper() or line.upper() in ("?", "UNABLE TO CONNECT"):
                continue
            # headers are ON (ATH1), so each line is "<id> <mode+0x40> [pid] data..."
            parts = line.split()
            if len(parts) < 2:
                continue
            try:
                ecu_id = int(parts[0], 16)
                byte_stream = bytes.fromhex("".join(parts[1:]))
            except ValueError:
                continue
            if not byte_stream:
                continue
            # ISO 15765 (CAN) responses carry a leading ISO-TP PCI byte
            # (0x0N = single frame, N bytes follow) ahead of the actual
            # OBD-II mode/pid/data payload, confirmed present on real
            # hardware (e.g. "7E8 04 41 0C 0B E0" - the "04" here, not
            # "41 0C 0B E0" alone). A real positive-response mode byte is
            # always >= 0x41 (mode 0x01-0x0A + 0x40) and a negative
            # response is 0x7F, so anything <= 0x0F at this position can
            # only be that PCI byte, never legitimate payload - strip it
            # unconditionally when present. Without this, every byte
            # after it is shifted by one, corrupting live data, DTC
            # bitmasks, and readiness-monitor decoding alike.
            if byte_stream[0] <= 0x0F:
                byte_stream = byte_stream[1:]
            if not byte_stream:
                continue
            resp_mode = byte_stream[0] - 0x40 if byte_stream[0] >= 0x40 else byte_stream[0]
            rest = byte_stream[1:]
            pid = None
            data = rest
            if sent_mode in (0x01, 0x02) and rest:
                pid = rest[0]
                data = rest[1:]
            responses.append(OBDResponse(ecu_id=ecu_id, mode=resp_mode, pid=pid, data=data))
        return responses

    def discover_ecus(self) -> set[int]:
        """Broadcast a Mode 01 PID 00 request and collect every distinct
        responder ID — the cheap, hardware-agnostic basis for topology
        mapping described in docs/HARDWARE.md.

        Retries a few times: on real hardware this broadcast is one of
        the more failure-prone requests (every ECU is trying to answer
        at once), so a single empty result is more likely a transient
        bus collision than "zero ECUs on this vehicle."
        """
        responses = self.request_with_retry(0x01, 0x00, attempts=3)
        return {r.ecu_id for r in responses}

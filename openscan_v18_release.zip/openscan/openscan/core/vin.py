"""Plain-Python VIN format validation - split out from
openscan/gui/vin_scanner.py so it can be unit-tested without pulling in
PySide6/cv2/pyzbar, and reused anywhere else a "does this look like a
real VIN" check is useful."""

from __future__ import annotations

#: VIN characters never include I, O, or Q (too easily confused with
#: 1/0) - a candidate VIN containing them, or not exactly 17
#: characters, is almost certainly not a real VIN.
_INVALID_VIN_CHARS = set("IOQ")


def looks_like_vin(text: str) -> bool:
    text = text.strip().upper()
    if len(text) != 17:
        return False
    if not text.isalnum():
        return False
    if any(c in _INVALID_VIN_CHARS for c in text):
        return False
    return True

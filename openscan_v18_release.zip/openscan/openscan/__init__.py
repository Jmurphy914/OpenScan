"""OpenScan: open-source cross-platform automotive diagnostic scan tool."""

__version__ = "0.18.0"

"""Readiness monitors ("I/M Readiness" / emissions readiness) and freeze
frame viewer - the screens that tell you whether a vehicle will actually
pass a state emissions/OBD inspection, and what conditions existed when
a DTC was set. Standard commercial-scan-tool features, missing from most
consumer OBD-II apps."""

from __future__ import annotations

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from ..core.vehicle import VehicleSession

_STATUS_COLORS = {
    "complete": "#43a047",     # green
    "incomplete": "#fb8c00",   # amber
    "not supported": "#757575",  # gray
}


class ReadinessPanel(QWidget):
    def __init__(self, session: VehicleSession, parent=None):
        super().__init__(parent)
        self.session = session

        layout = QVBoxLayout(self)

        # -- MIL / DTC summary --------------------------------------------------
        summary_box = QGroupBox("Emissions readiness")
        summary_layout = QVBoxLayout(summary_box)
        header_row = QHBoxLayout()
        self.mil_label = QLabel("MIL: --")
        self.dtc_count_label = QLabel("Confirmed DTCs: --")
        self.ignition_label = QLabel("Ignition type: --")
        for lbl in (self.mil_label, self.dtc_count_label, self.ignition_label):
            lbl.setStyleSheet("font-size: 12pt; padding: 4px;")
            header_row.addWidget(lbl)
        summary_layout.addLayout(header_row)

        self.monitor_table = QTableWidget(0, 3)
        self.monitor_table.setHorizontalHeaderLabels(["Monitor", "Supported", "Status"])
        self.monitor_table.horizontalHeader().setStretchLastSection(True)
        summary_layout.addWidget(self.monitor_table)

        refresh_readiness_btn = QPushButton("Refresh readiness")
        refresh_readiness_btn.clicked.connect(self.refresh_readiness)
        summary_layout.addWidget(refresh_readiness_btn)
        layout.addWidget(summary_box)

        # -- freeze frame ---------------------------------------------------------
        freeze_box = QGroupBox("Freeze frame (conditions when a DTC was set)")
        freeze_layout = QVBoxLayout(freeze_box)
        self.freeze_dtc_label = QLabel("Freeze frame DTC: --")
        freeze_layout.addWidget(self.freeze_dtc_label)

        self.freeze_table = QTableWidget(0, 2)
        self.freeze_table.setHorizontalHeaderLabels(["Parameter", "Value"])
        self.freeze_table.horizontalHeader().setStretchLastSection(True)
        freeze_layout.addWidget(self.freeze_table)

        refresh_freeze_btn = QPushButton("Refresh freeze frame")
        refresh_freeze_btn.clicked.connect(self.refresh_freeze_frame)
        freeze_layout.addWidget(refresh_freeze_btn)
        layout.addWidget(freeze_box)

    # -- readiness ------------------------------------------------------------------
    def refresh_readiness(self) -> None:
        statuses = self.session.obd2.get_monitor_status()
        if not statuses:
            self.mil_label.setText("MIL: no response")
            self.monitor_table.setRowCount(0)
            return
        # Use the first responding ECU (normally the PCM/ECM) for the
        # headline summary; a multi-ECU breakdown isn't usually needed
        # here since readiness monitors are an engine-management concept.
        status = next(iter(statuses.values()))

        self.mil_label.setText(f"MIL: {'ON' if status.mil_on else 'off'}")
        self.dtc_count_label.setText(f"Confirmed DTCs: {status.dtc_count}")
        self.ignition_label.setText(f"Ignition type: {status.ignition_type}")

        self.monitor_table.setRowCount(0)
        for monitor in status.monitors:
            row = self.monitor_table.rowCount()
            self.monitor_table.insertRow(row)
            self.monitor_table.setItem(row, 0, QTableWidgetItem(monitor.name))
            self.monitor_table.setItem(
                row, 1, QTableWidgetItem("Yes" if monitor.supported else "No")
            )
            if not monitor.supported:
                status_text, color_key = "not supported", "not supported"
            elif monitor.complete:
                status_text, color_key = "complete", "complete"
            else:
                status_text, color_key = "incomplete", "incomplete"
            status_item = QTableWidgetItem(status_text)
            status_item.setForeground(Qt.white)
            status_item.setBackground(_qcolor(_STATUS_COLORS[color_key]))
            self.monitor_table.setItem(row, 2, status_item)

    # -- freeze frame -----------------------------------------------------------------
    def refresh_freeze_frame(self) -> None:
        extra = self.session.dtc_descriptions_extra()
        dtc_by_ecu = self.session.obd2.get_freeze_frame_dtc(extra_descriptions=extra)
        entries = [v for v in dtc_by_ecu.values() if v is not None]
        if entries:
            code, desc = entries[0]
            self.freeze_dtc_label.setText(f"Freeze frame DTC: {code} — {desc}")
        else:
            self.freeze_dtc_label.setText("Freeze frame DTC: none stored")

        snapshot = self.session.obd2.read_freeze_frame_snapshot()
        self.freeze_table.setRowCount(0)
        merged: dict[str, float] = {}
        for readings in snapshot.values():
            merged.update(readings)
        name_unit = {d.name: d.unit for d in self.session.obd2.pids.values()}
        for name, value in merged.items():
            row = self.freeze_table.rowCount()
            self.freeze_table.insertRow(row)
            self.freeze_table.setItem(row, 0, QTableWidgetItem(name))
            unit = name_unit.get(name, "")
            self.freeze_table.setItem(row, 1, QTableWidgetItem(f"{value:.2f} {unit}".strip()))


def _qcolor(hex_str: str):
    from PySide6.QtGui import QColor
    return QColor(hex_str)

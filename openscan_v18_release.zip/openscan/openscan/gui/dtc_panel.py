"""DTC panel: read stored/pending/permanent codes, plain-English
descriptions, and clear codes (with a confirmation prompt — clearing
also resets readiness monitors, which matters for emissions testing).

Double-click any code for a detail popup with description and typical
causes (generic-code knowledge, not vehicle-specific service data - see
docs/HARDWARE.md on why wiring schematics aren't included)."""

from __future__ import annotations

import urllib.parse
import webbrowser

from PySide6.QtCore import Qt
from PySide6.QtWidgets import (
    QHBoxLayout,
    QListWidget,
    QListWidgetItem,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from ..core.dtc_history import record_seen
from ..core.obd2.dtc import dtc_info
from ..core.vehicle import VehicleSession


class DtcPanel(QWidget):
    def __init__(self, session: VehicleSession, parent=None):
        super().__init__(parent)
        self.session = session

        layout = QVBoxLayout(self)
        self.list_widget = QListWidget()
        self.list_widget.itemDoubleClicked.connect(self._show_details)
        layout.addWidget(self.list_widget)

        button_row = QHBoxLayout()
        stored_btn = QPushButton("Read stored codes")
        stored_btn.clicked.connect(lambda: self._refresh(pending=False))
        pending_btn = QPushButton("Read pending codes")
        pending_btn.clicked.connect(lambda: self._refresh(pending=True))
        permanent_btn = QPushButton("Read permanent codes")
        permanent_btn.clicked.connect(self._refresh_permanent)
        clear_btn = QPushButton("Clear codes")
        clear_btn.clicked.connect(self._clear)

        for btn in (stored_btn, pending_btn, permanent_btn, clear_btn):
            button_row.addWidget(btn)
        layout.addLayout(button_row)

    def _refresh(self, pending: bool) -> None:
        extra = self.session.dtc_descriptions_extra()
        results = self.session.obd2.get_dtcs(pending=pending, extra_descriptions=extra)
        self._populate(results, "Pending" if pending else "Stored")

    def _refresh_permanent(self) -> None:
        extra = self.session.dtc_descriptions_extra()
        results = self.session.obd2.get_permanent_dtcs(extra_descriptions=extra)
        self._populate(results, "Permanent")

    def _populate(self, results: dict, category: str) -> None:
        self.list_widget.clear()
        if not any(results.values()):
            self.list_widget.addItem(QListWidgetItem(f"No {category.lower()} codes found."))
            return
        seen_this_scan: list[tuple[str, str]] = []
        for ecu_id, codes in results.items():
            for code, description in codes:
                item = QListWidgetItem(f"[{category}] {code} (ECU {ecu_id:#x}) — {description}"
                                        f"  (double-click for details)")
                item.setData(Qt.UserRole, code)
                self.list_widget.addItem(item)
                seen_this_scan.append((code, description))
        if seen_this_scan:
            # Persisted across app restarts (unlike this panel, which
            # only shows what's currently stored on the ECU) - see the
            # DTC History tab and core/dtc_history.py.
            record_seen(seen_this_scan, vin=self.session.vin)

    def _show_details(self, item: QListWidgetItem) -> None:
        code = item.data(Qt.UserRole)
        if not code:
            return
        info = dtc_info(code, self.session.dtc_descriptions_extra())
        if info.causes:
            causes_text = "\n".join(f"  • {c}" for c in info.causes)
        else:
            causes_text = ("  (no common-causes list available for this code yet - "
                           "it may be manufacturer-specific)")
        box = QMessageBox(self)
        box.setIcon(QMessageBox.Information)
        box.setWindowTitle(f"DTC {info.code}")
        box.setText(
            f"{info.code} — {info.description}\n\n"
            f"Typical causes:\n{causes_text}\n\n"
            f"Note: this is general diagnostic knowledge about what the code "
            f"means, not a vehicle-specific repair procedure. Wiring "
            f"schematics and exact test steps are proprietary OEM service "
            f"data (ALLDATA, Mitchell1, factory service manuals, etc.) and "
            f"aren't something this project can bundle - see docs/HARDWARE.md.\n\n"
            f"For more on this specific code (forum write-ups, repair "
            f"walkthroughs, model-specific notes), use the button below - "
            f"it opens a Google search in your browser. Nothing is sent "
            f"anywhere automatically; this only runs when you click it."
        )
        search_btn = box.addButton("Search this code on Google", QMessageBox.ActionRole)
        box.addButton(QMessageBox.Ok)
        box.exec()
        if box.clickedButton() == search_btn:
            query = urllib.parse.quote(f"{info.code} OBD2 trouble code")
            webbrowser.open(f"https://www.google.com/search?q={query}")

    def _clear(self) -> None:
        confirm = QMessageBox.question(
            self,
            "Clear diagnostic codes",
            "This clears stored/pending DTCs and resets readiness monitors "
            "on this vehicle. Continue?",
        )
        if confirm != QMessageBox.Yes:
            return
        self.session.obd2.clear_dtcs()
        self.list_widget.clear()
        self.list_widget.addItem(QListWidgetItem("Codes cleared."))

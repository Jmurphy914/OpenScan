"""Network topology map: draws the discovered ECUs as nodes hanging off
a central bus node, the same basic visual language used by commercial
scan tools' "vehicle topology" screens. Nodes are clickable - shows
whatever live data that specific module has reported so far (from the
Live Data tab's most recent poll, published on the session)."""

from __future__ import annotations

import math
from typing import Callable

from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QBrush, QPen
from PySide6.QtWidgets import (
    QGraphicsEllipseItem,
    QGraphicsLineItem,
    QGraphicsScene,
    QGraphicsSceneMouseEvent,
    QGraphicsTextItem,
    QGraphicsView,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from ..core.vehicle import VehicleSession

NODE_RADIUS = 40
BUS_RADIUS = 55
RING_RADIUS = 220


class _ClickableEcuNode(QGraphicsEllipseItem):
    """An ECU node that reports clicks back to the view - QGraphicsItem
    has no Qt signals of its own, so this just calls a plain callback."""

    def __init__(self, rect: QRectF, ecu_id: int, label: str,
                 on_click: Callable[[int, str], None]):
        super().__init__(rect)
        self.ecu_id = ecu_id
        self.label = label
        self._on_click = on_click
        self.setCursor(Qt.PointingHandCursor)
        self.setToolTip(f"Click for {label}'s live data")

    def mousePressEvent(self, event: QGraphicsSceneMouseEvent) -> None:  # noqa: N802
        self._on_click(self.ecu_id, self.label)
        super().mousePressEvent(event)


class TopologyView(QWidget):
    def __init__(self, session: VehicleSession, parent=None):
        super().__init__(parent)
        self.session = session

        layout = QVBoxLayout(self)
        refresh_btn = QPushButton("Discover ECUs / refresh topology")
        refresh_btn.clicked.connect(self.refresh)
        layout.addWidget(refresh_btn)

        self.scene = QGraphicsScene()
        self.view = QGraphicsView(self.scene)
        self.view.setRenderHint(self.view.renderHints())
        layout.addWidget(self.view)

    def refresh(self) -> None:
        graph = self.session.refresh_topology()
        self._draw(graph)

    def _on_node_clicked(self, ecu_id: int, label: str) -> None:
        readings = self.session.last_live_data.get(ecu_id, {})
        if readings:
            body = "\n".join(f"  {name}: {value:.2f}" for name, value in sorted(readings.items()))
        else:
            body = ("  (no live data captured from this module yet - open the "
                    "Live Data tab to start polling, then come back here)")
        QMessageBox.information(
            self, label,
            f"{label}\nECU address: {ecu_id:#x}\n\nMost recent readings:\n{body}",
        )

    def _draw(self, graph) -> None:
        self.scene.clear()
        center_x, center_y = 0, 0

        bus_item = QGraphicsEllipseItem(
            QRectF(center_x - BUS_RADIUS, center_y - BUS_RADIUS,
                   BUS_RADIUS * 2, BUS_RADIUS * 2)
        )
        bus_item.setBrush(QBrush(Qt.darkGray))
        self.scene.addItem(bus_item)
        bus_label = QGraphicsTextItem(graph.bus_name)
        bus_label.setDefaultTextColor(Qt.white)
        bus_label.setPos(center_x - BUS_RADIUS + 5, center_y - 10)
        self.scene.addItem(bus_label)

        n = max(len(graph.nodes), 1)
        for i, node in enumerate(graph.nodes):
            angle = 2 * math.pi * i / n
            x = center_x + RING_RADIUS * math.cos(angle)
            y = center_y + RING_RADIUS * math.sin(angle)

            line = QGraphicsLineItem(center_x, center_y, x, y)
            line.setPen(QPen(Qt.gray, 2))
            self.scene.addItem(line)

            node_item = _ClickableEcuNode(
                QRectF(x - NODE_RADIUS, y - NODE_RADIUS, NODE_RADIUS * 2, NODE_RADIUS * 2),
                ecu_id=node.ecu_id, label=node.label, on_click=self._on_node_clicked,
            )
            node_item.setBrush(QBrush(Qt.blue if node.responded else Qt.red))
            self.scene.addItem(node_item)

            label = QGraphicsTextItem(node.label)
            label.setDefaultTextColor(Qt.white)
            label.setPos(x - NODE_RADIUS, y - 8)
            label.setTextWidth(NODE_RADIUS * 2)
            # Let clicks pass through to the node underneath rather than
            # being swallowed by the text label sitting on top of it.
            label.setAcceptedMouseButtons(Qt.NoButton)
            self.scene.addItem(label)

        self.view.fitInView(self.scene.itemsBoundingRect(), Qt.KeepAspectRatio)

"""Dark theme stylesheet - closer to what most dedicated scan tools
(and most people's expectations of a "pro" tool) look like than Qt's
default light palette. Applied/removed at the QApplication level via
MainWindow's toolbar toggle; session-only (not persisted between runs
yet - see docs/ROADMAP.md if you want that added)."""

DARK_QSS = """
QWidget {
    background-color: #232629;
    color: #e0e0e0;
}
QGroupBox {
    border: 1px solid #444;
    border-radius: 4px;
    margin-top: 1.2em;
    padding-top: 0.4em;
}
QGroupBox::title {
    subcontrol-origin: margin;
    left: 8px;
    padding: 0 4px;
    color: #e0e0e0;
}
QPushButton {
    background-color: #3a3f44;
    border: 1px solid #555;
    border-radius: 3px;
    padding: 4px 10px;
}
QPushButton:hover {
    background-color: #454b52;
}
QPushButton:pressed, QPushButton:checked {
    background-color: #565f68;
}
QLineEdit, QComboBox, QPlainTextEdit, QTextEdit {
    background-color: #2b2f33;
    border: 1px solid #555;
    color: #e0e0e0;
    padding: 2px;
}
QTableWidget, QListWidget, QTreeWidget {
    background-color: #2b2f33;
    gridline-color: #444;
    color: #e0e0e0;
}
QHeaderView::section {
    background-color: #3a3f44;
    color: #e0e0e0;
    border: 1px solid #444;
    padding: 2px;
}
QTabWidget::pane {
    border: 1px solid #444;
}
QTabBar::tab {
    background: #2b2f33;
    color: #cfcfcf;
    padding: 6px 12px;
    border: 1px solid #444;
    border-bottom: none;
}
QTabBar::tab:selected {
    background: #3a3f44;
    color: #ffffff;
}
QStatusBar {
    background: #2b2f33;
}
QToolBar {
    background: #2b2f33;
    border: none;
}
QScrollArea {
    border: none;
}
"""

"""Small display-formatting helpers shared across GUI panels - kept in
their own module (rather than in main_window.py) so panels can import
them without a circular import back to the main window."""

from __future__ import annotations


def describe_protocol(raw: str | None) -> str:
    """ELM327's ATDPN reply prefixes an 'A' when the protocol was
    auto-selected (via ATSP0) rather than manually forced, e.g. "A6"
    means ISO 15765-4 CAN (11-bit, 500 kbps), auto-detected. Shown as
    plain "6 (auto-detected)" instead of the raw "A6", which otherwise
    looks like an error or an unrecognized protocol code."""
    if not raw:
        return "unknown"
    if raw.startswith("A") and len(raw) > 1:
        return f"{raw[1:]} (auto-detected)"
    return raw

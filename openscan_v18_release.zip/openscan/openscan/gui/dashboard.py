"""Live data dashboard: split down the middle - gauges and user-chosen
strip charts on the left, the full live data stream (every parameter
the vehicle is currently reporting, one row each, updating in real
time) on the right.

Polling happens on a QThread worker so adapter I/O (which can block for
the transport's read timeout) never freezes the UI.
"""

from __future__ import annotations

import csv
import datetime
from collections import defaultdict, deque

import pyqtgraph as pg
from PySide6.QtCore import QObject, Qt, QThread, Signal
from PySide6.QtGui import QBrush, QColor
from PySide6.QtWidgets import (
    QComboBox,
    QFileDialog,
    QGridLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QScrollArea,
    QSplitter,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from ..core.obd2.normal_ranges import status_for
from ..core.vehicle import VehicleSession
from .widgets import GaugeWidget

#: Cell background colors for the live data stream table's green/red
#: normal-range highlighting - pale rather than saturated so the text
#: stays easily readable. No entry (status is None) leaves the cell's
#: default background untouched.
_TABLE_STATUS_COLORS = {
    "ok": QColor(200, 255, 200),
    "out_of_range": QColor(255, 200, 200),
}

HISTORY_LEN = 200

#: (pid name to match against live-data readings, shorter display title,
#: unit shown on the gauge, min, max, redline fraction). The lookup key
#: (first element) must exactly match the PidDefinition.name used
#: elsewhere (pids_generic.json) - the display title is separate and
#: deliberately kept short so it doesn't overflow the circular gauge's
#: width when centered (a long title like the PID's full name can get
#: clipped on both edges - see widgets.py). These are the headline
#: gauges shown at the top regardless of what else the vehicle
#: supports - they'll simply read "--" until the first successful poll
#: for that specific parameter comes back. Units are US customary -
#: see UNIT_CONVERSIONS in core/obd2/pids.py.
GAUGE_SPECS = [
    ("Engine RPM", "RPM", "rpm", 0, 7000, 0.85),
    ("Vehicle Speed", "Speed", "mph", 0, 140, None),
    ("Coolant Temperature", "Coolant", "°F", -40, 300, 0.85),
    ("Throttle Position", "Throttle", "%", 0, 100, None),
]

#: Default selections for the user-configurable strip charts.
DEFAULT_CHART_PIDS = ["Engine RPM", "Vehicle Speed", "Coolant Temperature"]

#: Fallback (lo, hi, redline_fraction) for a gauge added at runtime for a
#: PID that isn't one of the curated GAUGE_SPECS above, keyed by that
#: PID's (already-US-converted) unit string. Best-effort - a parameter
#: with an unusual real-world range may not scale perfectly, but the
#: exact figure is always still visible in the live data stream on the
#: right regardless of how the gauge needle looks.
DEFAULT_GAUGE_RANGE_BY_UNIT: dict[str, tuple[float, float, float | None]] = {
    "rpm": (0, 8000, 0.85),
    "mph": (0, 160, None),
    "°F": (-40, 300, 0.85),
    "%": (-100, 100, None),
    "psi": (0, 100, None),
    "inH2O": (-50, 50, None),
    "V": (0, 20, None),
    "g/s": (0, 500, None),
    "gal/h": (0, 20, None),
    "mi": (0, 999999, None),
}
DEFAULT_GAUGE_RANGE_FALLBACK = (0, 100, None)

#: How many gauges sit side by side before wrapping to a new row - the
#: left pane is only half the window's width, so more than 2-3 wide
#: circular gauges would get uncomfortably small.
GAUGE_COLUMNS = 2


class PollWorker(QObject):
    # Signal(object), not Signal(dict): this crosses a thread boundary
    # (worker thread -> GUI thread), which PySide6 delivers as a queued
    # connection needing the payload marshaled through Qt's C++ type
    # system. Signal(dict) tries to convert to QVariantMap, which
    # requires string keys and QVariant-compatible values - our payload
    # is {int: {str: float}}, which doesn't fit, so every emission was
    # spamming "Shiboken::Conversions::_pythonToCppCopy: Cannot
    # copy-convert ... (dict) to C++" to the console. Signal(object)
    # instead passes the Python dict through untouched (no C++
    # conversion attempted), which is the standard way to move arbitrary
    # Python data across threads in PySide6.
    data_ready = Signal(object)    # {ecu_id: {name: value}}
    error = Signal(str)

    def __init__(self, session: VehicleSession, interval_ms: int = 500):
        super().__init__()
        self.session = session
        self.interval_ms = interval_ms
        self._running = False

    def start(self) -> None:
        self._running = True
        self._loop()

    def stop(self) -> None:
        self._running = False

    def _loop(self) -> None:
        while self._running:
            try:
                data = self.session.obd2.read_live_data()
                self.data_ready.emit(data)
            except Exception as exc:  # noqa: BLE001
                self.error.emit(str(exc))
            QThread.msleep(self.interval_ms)


class DashboardWidget(QWidget):
    def __init__(self, session: VehicleSession, parent=None):
        super().__init__(parent)
        self.session = session
        self._history: dict[str, deque] = defaultdict(lambda: deque(maxlen=HISTORY_LEN))
        self._name_unit: dict[str, str] = {d.name: d.unit for d in session.obd2.pids.values()}
        # Seeded with every PID this vehicle's plugin/table set knows
        # about (not just ones already seen live) so the gauge-picker
        # and chart dropdowns are useful immediately, before the first
        # poll even completes.
        self._known_names: list[str] = sorted(self._name_unit.keys())
        self._row_for_name: dict[str, int] = {}
        #: Populated while logging is active - one row per (ecu_id, name)
        #: reading per poll cycle. Exported to CSV on demand; cleared each
        #: time logging is (re)started so exports don't accumulate stale
        #: data across separate recording sessions.
        self._log_rows: list[tuple] = []
        self._logging = False

        outer = QVBoxLayout(self)

        supported_row = QHBoxLayout()
        supported_note = QLabel(self._supported_summary())
        supported_note.setStyleSheet("color: gray;")
        supported_row.addWidget(supported_note, stretch=1)
        rescan_btn = QPushButton("Rescan supported parameters")
        rescan_btn.setToolTip(
            "If live data looks empty or thin, the initial scan for "
            "supported parameters may have failed due to bus/adapter "
            "noise right after connecting. Try again here."
        )
        rescan_btn.clicked.connect(self._rescan_supported_pids)
        supported_row.addWidget(rescan_btn)
        self.log_btn = QPushButton("Start logging")
        self.log_btn.setCheckable(True)
        self.log_btn.setToolTip("Records every poll cycle's readings so you can export them as CSV afterward.")
        self.log_btn.clicked.connect(self._toggle_logging)
        supported_row.addWidget(self.log_btn)
        export_btn = QPushButton("Export log to CSV...")
        export_btn.clicked.connect(self._export_log_csv)
        supported_row.addWidget(export_btn)
        outer.addLayout(supported_row)
        self.supported_note = supported_note

        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(self._build_left_pane())
        splitter.addWidget(self._build_right_pane())
        splitter.setStretchFactor(0, 1)
        splitter.setStretchFactor(1, 1)
        splitter.setSizes([1, 1])   # equal 50/50 split to start
        outer.addWidget(splitter, stretch=1)

        self.thread = QThread()
        self.worker = PollWorker(session)
        self.worker.moveToThread(self.thread)
        self.thread.started.connect(self.worker.start)
        self.worker.data_ready.connect(self._on_data)
        self.worker.error.connect(self._on_error)

    # -- left pane: gauges the user can add to, plus strip charts ---------
    def _build_left_pane(self) -> QWidget:
        content = QWidget()
        content_layout = QVBoxLayout(content)

        gauges_box = QGroupBox("Key metrics")
        gauges_box_layout = QVBoxLayout(gauges_box)
        self.gauges_grid = QGridLayout()
        gauges_box_layout.addLayout(self.gauges_grid)
        self.gauges: dict[str, GaugeWidget] = {}
        for pid_name, display_title, unit, lo, hi, redline in GAUGE_SPECS:
            self._add_gauge(pid_name, display_title, unit, lo, hi, redline)

        picker_row = QHBoxLayout()
        picker_row.addWidget(QLabel("Add gauge for:"))
        self.gauge_picker = QComboBox()
        self.gauge_picker.addItems(self._known_names)
        picker_row.addWidget(self.gauge_picker, stretch=1)
        add_gauge_btn = QPushButton("Add")
        add_gauge_btn.clicked.connect(self._add_gauge_from_picker)
        picker_row.addWidget(add_gauge_btn)
        reset_btn = QPushButton("Reset to defaults")
        reset_btn.setToolTip("Removes any gauges you've added and restores the original four.")
        reset_btn.clicked.connect(self._reset_gauges_to_defaults)
        picker_row.addWidget(reset_btn)
        gauges_box_layout.addLayout(picker_row)
        range_note = QLabel(
            "Green/red ring = within/outside this parameter's normal "
            "operating range (only shown for parameters that have one "
            "regardless of driving conditions - see core/obd2/normal_ranges.py)."
        )
        range_note.setWordWrap(True)
        range_note.setStyleSheet("color: gray;")
        gauges_box_layout.addWidget(range_note)
        content_layout.addWidget(gauges_box)

        charts_box = QGroupBox("Graphs")
        charts_layout = QGridLayout(charts_box)
        self.chart_combos: list[QComboBox] = []
        self.plots: dict[int, tuple[pg.PlotWidget, pg.PlotDataItem]] = {}
        for i, default_pid in enumerate(DEFAULT_CHART_PIDS):
            combo = QComboBox()
            combo.addItems(self._known_names)
            if default_pid in self._known_names:
                combo.setCurrentText(default_pid)
            combo.currentTextChanged.connect(lambda _t, idx=i: self._on_chart_selection_changed(idx))
            plot = pg.PlotWidget()
            plot.showGrid(x=True, y=True, alpha=0.3)
            curve = plot.plot(pen=pg.mkPen(width=2))
            charts_layout.addWidget(combo, 0, i)
            charts_layout.addWidget(plot, 1, i)
            self.chart_combos.append(combo)
            self.plots[i] = (plot, curve)
        self._charts_box = charts_box
        snapshot_btn = QPushButton("Save graphs as image...")
        snapshot_btn.clicked.connect(lambda: self._save_widget_snapshot(charts_box, "openscan_graphs.png"))
        charts_layout.addWidget(snapshot_btn, 2, 0, 1, len(DEFAULT_CHART_PIDS))
        content_layout.addWidget(charts_box, stretch=1)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setWidget(content)
        return scroll

    # -- right pane: the full live data stream -----------------------------
    def _build_right_pane(self) -> QWidget:
        table_box = QGroupBox("Live data stream — every parameter, updating in real time")
        table_layout = QVBoxLayout(table_box)
        self.table = QTableWidget(0, 4)
        self.table.setHorizontalHeaderLabels(["Parameter", "Value", "Unit", "ECU"])
        self.table.setSortingEnabled(True)
        self.table.horizontalHeader().setStretchLastSection(True)
        table_layout.addWidget(self.table)
        table_snapshot_btn = QPushButton("Save table as image...")
        table_snapshot_btn.clicked.connect(lambda: self._save_widget_snapshot(self.table, "openscan_table.png"))
        table_layout.addWidget(table_snapshot_btn)
        return table_box

    def _save_widget_snapshot(self, widget: QWidget, default_name: str) -> None:
        path, _ = QFileDialog.getSaveFileName(
            self, "Save snapshot", default_name, "PNG image (*.png)",
        )
        if not path:
            return
        pixmap = widget.grab()
        if not pixmap.save(path, "PNG"):
            QMessageBox.warning(self, "Save failed", f"Couldn't write image to {path}.")
        else:
            QMessageBox.information(self, "Saved", f"Snapshot saved to {path}.")

    def _supported_summary(self) -> str:
        active = self.session.obd2.active_pids
        total = len(self.session.obd2.pids)
        if active is None:
            return f"Scanning for supported parameters (of {total} known)..."
        return (f"{len(active)} of {total} known parameters supported by this "
                f"vehicle. Unsupported ones simply won't appear below - see "
                f"docs/HARDWARE.md.")

    def start_polling(self) -> None:
        self.thread.start()

    def stop_polling(self) -> None:
        self.worker.stop()
        self.thread.quit()
        self.thread.wait(2000)

    def _toggle_logging(self, checked: bool) -> None:
        self._logging = checked
        if checked:
            self._log_rows = []
            self.log_btn.setText("Stop logging")
        else:
            self.log_btn.setText("Start logging")

    def _export_log_csv(self) -> None:
        if not self._log_rows:
            QMessageBox.information(
                self, "No log data",
                "Nothing recorded yet - click \"Start logging\" first, "
                "then let it run a while before exporting.",
            )
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export live data log", "openscan_log.csv", "CSV files (*.csv)",
        )
        if not path:
            return
        with open(path, "w", newline="", encoding="utf-8") as f:
            writer = csv.writer(f)
            writer.writerow(["timestamp", "ecu_id", "parameter", "value", "unit"])
            writer.writerows(self._log_rows)
        QMessageBox.information(self, "Exported", f"Wrote {len(self._log_rows)} rows to {path}.")

    def _rescan_supported_pids(self) -> None:
        # Runs synchronously on the GUI thread (briefly blocking, same as
        # the DTC/topology "refresh" buttons elsewhere in the app) - safe
        # to do even while the background poll worker is mid-cycle now
        # that ELM327 serializes all adapter I/O behind a lock; this call
        # will simply wait its turn rather than corrupt anything.
        self.supported_note.setText("Rescanning...")
        self.session.obd2.refresh_supported_pids()
        self.supported_note.setText(self._supported_summary())

    # -- gauges --------------------------------------------------------
    def _add_gauge(self, pid_name: str, display_title: str, unit: str,
                   lo: float, hi: float, redline: float | None) -> None:
        if pid_name in self.gauges:
            return
        gauge = GaugeWidget(title=display_title, unit=unit, min_value=lo, max_value=hi,
                             redline_fraction=redline)
        self.gauges[pid_name] = gauge
        idx = len(self.gauges) - 1
        row, col = divmod(idx, GAUGE_COLUMNS)
        self.gauges_grid.addWidget(gauge, row, col)

    def _add_gauge_from_picker(self) -> None:
        name = self.gauge_picker.currentText()
        if not name or name in self.gauges:
            return
        unit = self._name_unit.get(name, "")
        lo, hi, redline = DEFAULT_GAUGE_RANGE_BY_UNIT.get(unit, DEFAULT_GAUGE_RANGE_FALLBACK)
        self._add_gauge(name, name, unit, lo, hi, redline)

    def _reset_gauges_to_defaults(self) -> None:
        for gauge in list(self.gauges.values()):
            self.gauges_grid.removeWidget(gauge)
            gauge.setParent(None)
            gauge.deleteLater()
        self.gauges.clear()
        for pid_name, display_title, unit, lo, hi, redline in GAUGE_SPECS:
            self._add_gauge(pid_name, display_title, unit, lo, hi, redline)

    # -- strip charts ----------------------------------------------------
    def _on_chart_selection_changed(self, idx: int) -> None:
        # switching series - history for the newly selected name may
        # already exist from earlier polls, so just redraw immediately
        # rather than waiting for the next poll tick.
        name = self.chart_combos[idx].currentText()
        hist = self._history.get(name)
        if hist:
            self.plots[idx][1].setData(list(hist))

    def _ensure_chart_options(self, names) -> None:
        new_names = [n for n in names if n not in self._known_names]
        if not new_names:
            return
        self._known_names.extend(new_names)
        self._known_names.sort()
        for combo in self.chart_combos:
            current = combo.currentText()
            combo.blockSignals(True)
            combo.clear()
            combo.addItems(self._known_names)
            if current in self._known_names:
                combo.setCurrentText(current)
            combo.blockSignals(False)
        current_pick = self.gauge_picker.currentText()
        self.gauge_picker.blockSignals(True)
        self.gauge_picker.clear()
        self.gauge_picker.addItems(self._known_names)
        if current_pick in self._known_names:
            self.gauge_picker.setCurrentText(current_pick)
        self.gauge_picker.blockSignals(False)

    def _on_data(self, data: dict) -> None:
        self.supported_note.setText(self._supported_summary())
        # Published for other tabs (e.g. topology's per-node click detail)
        # to read without needing their own polling loop.
        self.session.last_live_data = data

        # Merge all responding ECUs' readings for the headline gauges/
        # charts (which don't care which module answered); the table
        # keeps per-ECU rows since that detail is genuinely useful there.
        merged: dict[str, float] = {}
        for readings in data.values():
            merged.update(readings)

        if self._logging:
            ts = datetime.datetime.now().isoformat(timespec="seconds")
            for ecu_id, readings in data.items():
                for name, value in readings.items():
                    self._log_rows.append((ts, f"{ecu_id:#x}", name, value, self._name_unit.get(name, "")))

        self._ensure_chart_options(merged.keys())

        for name, gauge in self.gauges.items():
            if name in merged:
                value = merged[name]
                gauge.set_value(value)
                gauge.set_status(status_for(name, value))

        for name, value in merged.items():
            self._history[name].append(value)
        for idx, combo in enumerate(self.chart_combos):
            name = combo.currentText()
            if name in self._history:
                self.plots[idx][1].setData(list(self._history[name]))

        self._update_table(data)

    def _update_table(self, data: dict) -> None:
        self.table.setSortingEnabled(False)
        for ecu_id, readings in data.items():
            for name, value in readings.items():
                key = (name, ecu_id)
                unit = self._name_unit.get(name, "")
                if key not in self._row_for_name:
                    row = self.table.rowCount()
                    self.table.insertRow(row)
                    self.table.setItem(row, 0, QTableWidgetItem(name))
                    self.table.setItem(row, 2, QTableWidgetItem(unit))
                    self.table.setItem(row, 3, QTableWidgetItem(f"{ecu_id:#x}"))
                    self._row_for_name[key] = row
                row = self._row_for_name[key]
                value_item = QTableWidgetItem(f"{value:.2f}")
                value_item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                status = status_for(name, value)
                color = _TABLE_STATUS_COLORS.get(status)
                if color is not None:
                    value_item.setBackground(QBrush(color))
                self.table.setItem(row, 1, value_item)
        self.table.setSortingEnabled(True)

    def _on_error(self, message: str) -> None:
        self.supported_note.setText(f"Poll error: {message}")

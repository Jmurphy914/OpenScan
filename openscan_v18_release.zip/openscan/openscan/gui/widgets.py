"""Reusable custom-painted widgets for the dashboard - a circular gauge
in the style of a real instrument cluster / professional scan tool,
instead of a plain text label."""

from __future__ import annotations

from PySide6.QtCore import QRectF, Qt
from PySide6.QtGui import QColor, QFont, QPainter, QPen
from PySide6.QtWidgets import QWidget

#: Sweep of the gauge arc, in degrees. Qt angles are in 1/16ths of a
#: degree and go counter-clockwise from the 3-o'clock position; a real
#: gauge reads clockwise from about 8-o'clock to 4-o'clock, hence the
#: negative span and the start angle below.
_START_ANGLE_DEG = 225   # 7:30 position
_SPAN_DEG = -270          # sweep clockwise 270 degrees to 4:30 position


class GaugeWidget(QWidget):
    def __init__(self, title: str, unit: str = "", min_value: float = 0,
                 max_value: float = 100, redline_fraction: float | None = None,
                 parent=None):
        super().__init__(parent)
        self.title = title
        self.unit = unit
        self.min_value = min_value
        self.max_value = max_value
        self.redline_fraction = redline_fraction
        self.value: float | None = None
        #: "ok" / "out_of_range" / None (no defined normal range for
        #: this parameter - see core/obd2/normal_ranges.py). Drawn as a
        #: thin outer ring so it doesn't visually collide with the
        #: redline arc coloring, which answers a different question
        #: ("how close to max") than this one ("is this healthy").
        self._status: str | None = None
        self.setMinimumSize(160, 160)

    def set_value(self, value: float) -> None:
        self.value = value
        self.update()

    def set_status(self, status: str | None) -> None:
        self._status = status
        self.update()

    def set_range(self, min_value: float, max_value: float) -> None:
        self.min_value = min_value
        self.max_value = max_value
        self.update()

    def _fraction(self) -> float:
        if self.value is None:
            return 0.0
        span = self.max_value - self.min_value
        if span <= 0:
            return 0.0
        frac = (self.value - self.min_value) / span
        return max(0.0, min(1.0, frac))

    def paintEvent(self, event) -> None:  # noqa: N802 - Qt override
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        side = min(self.width(), self.height())
        margin = side * 0.10
        rect = QRectF(margin, margin, side - 2 * margin, side - 2 * margin)

        # normal-range status ring, drawn at the very outer edge (outside
        # the value track below) so it never overlaps the redline
        # coloring - green means "within this parameter's normal
        # operating range," red means outside it. No ring at all means
        # no defined normal range for this parameter (see
        # core/obd2/normal_ranges.py) - most PIDs are condition-dependent
        # (RPM, speed, load...) and intentionally have none.
        if self._status is not None:
            ring_color = QColor(76, 175, 80) if self._status == "ok" else QColor(229, 57, 53)
            ring_pen = QPen(ring_color, max(2.0, side * 0.015))
            painter.setPen(ring_pen)
            painter.setBrush(Qt.NoBrush)
            ring_rect = QRectF(side * 0.02, side * 0.02, side * 0.96, side * 0.96)
            painter.drawEllipse(ring_rect)

        # background track
        bg_pen = QPen(QColor(60, 60, 60), side * 0.06)
        bg_pen.setCapStyle(Qt.RoundCap)
        painter.setPen(bg_pen)
        painter.drawArc(rect, _START_ANGLE_DEG * 16, _SPAN_DEG * 16)

        # value arc
        frac = self._fraction()
        if frac > 0:
            color = QColor(66, 165, 245)  # blue
            if self.redline_fraction is not None and frac >= self.redline_fraction:
                color = QColor(229, 57, 53)  # red
            elif self.redline_fraction is not None and frac >= self.redline_fraction * 0.85:
                color = QColor(255, 179, 0)  # amber
            fg_pen = QPen(color, side * 0.06)
            fg_pen.setCapStyle(Qt.RoundCap)
            painter.setPen(fg_pen)
            painter.drawArc(rect, _START_ANGLE_DEG * 16, int(_SPAN_DEG * frac * 16))

        # center value text
        painter.setPen(QPen(QColor(230, 230, 230)))
        value_font = QFont()
        value_font.setPointSizeF(side * 0.14)
        value_font.setBold(True)
        painter.setFont(value_font)
        value_text = "--" if self.value is None else f"{self.value:.0f}"
        painter.drawText(rect, Qt.AlignCenter, value_text)

        # unit + title below center. Text is horizontally centered, so if
        # a title is wider than the widget itself, it overflows equally
        # on both sides and gets clipped by the widget's own edges -
        # chopping the first and last characters (e.g. "Coolant
        # Temperature" losing its leading "C"). TextWordWrap lets Qt
        # break long titles onto a second line instead of overflowing.
        small_font = QFont()
        small_font.setPointSizeF(side * 0.075)
        painter.setFont(small_font)
        label_rect = QRectF(rect.x(), rect.y() + rect.height() * 0.62,
                             rect.width(), rect.height() * 0.38)
        painter.drawText(label_rect, Qt.AlignHCenter | Qt.AlignTop | Qt.TextWordWrap,
                          f"{self.unit}\n{self.title}")

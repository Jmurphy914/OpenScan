"""Vehicle info panel: VIN, calibration ID, protocol in use, plus
manually-editable make/model/year - useful when auto-VIN-read fails or
returns nothing on a given adapter/vehicle combination (no VIN decoder
database is bundled here, so this is plain user-entered data, not
derived from the VIN itself), and this is where OEM plugins will
eventually key off "make" for security-access/routine selection."""

from __future__ import annotations

from PySide6.QtWidgets import (
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from ..core.vehicle import VehicleSession
from .format_utils import describe_protocol


class VinPanel(QWidget):
    def __init__(self, session: VehicleSession, parent=None):
        super().__init__(parent)
        self.session = session

        layout = QVBoxLayout(self)
        form = QFormLayout()

        self.protocol_label = QLabel(describe_protocol(session.elm.protocol))
        self.calibration_label = QLabel("--")

        self.vin_edit = QLineEdit(session.vin or "")
        self.vin_edit.setPlaceholderText("17-character VIN (auto-read if available)")
        self.make_edit = QLineEdit(session.vehicle_make or "")
        self.make_edit.setPlaceholderText("e.g. Toyota")
        self.model_edit = QLineEdit(session.vehicle_model or "")
        self.model_edit.setPlaceholderText("e.g. Corolla")
        self.year_edit = QLineEdit(session.vehicle_year or "")
        self.year_edit.setPlaceholderText("e.g. 2016")

        form.addRow("VIN", self.vin_edit)
        form.addRow("Make", self.make_edit)
        form.addRow("Model", self.model_edit)
        form.addRow("Year", self.year_edit)
        form.addRow("Protocol", self.protocol_label)
        form.addRow("Calibration ID", self.calibration_label)
        layout.addLayout(form)

        note = QLabel(
            "Make/model/year aren't auto-detected (that needs a VIN decoder "
            "database this project doesn't bundle) - enter them manually if "
            "you'd like them recorded for this session. \"Save\" just keeps "
            "them in memory for this session; nothing is written to a file. "
            "Note: manufacturer enhanced-PID plugins are only activated "
            "once, right when you connect (based on the make entered in "
            "the connection dialog) - changing the make here won't "
            "retroactively enable a different plugin without disconnecting "
            "and reconnecting."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: gray;")
        layout.addWidget(note)

        button_row = QHBoxLayout()
        save_btn = QPushButton("Save")
        save_btn.clicked.connect(self._save)
        refresh_btn = QPushButton("Refresh auto-detected info")
        refresh_btn.clicked.connect(self.refresh)
        button_row.addWidget(save_btn)
        button_row.addWidget(refresh_btn)
        layout.addLayout(button_row)

    def _save(self) -> None:
        vin = self.vin_edit.text().strip()
        if vin and len(vin) != 17:
            QMessageBox.warning(
                self, "VIN length",
                f"VINs are normally 17 characters (got {len(vin)}). Saving "
                f"anyway, but double-check it if this wasn't intentional.",
            )
        self.session.set_vehicle_info(
            vin=vin or None,
            make=self.make_edit.text().strip() or None,
            model=self.model_edit.text().strip() or None,
            year=self.year_edit.text().strip() or None,
        )

    def refresh(self) -> None:
        vin = self.session.obd2.get_vin()
        if vin:
            self.vin_edit.setText(vin)
            self.session.vin = vin
        self.calibration_label.setText(self.session.obd2.get_calibration_id() or "--")
        self.protocol_label.setText(describe_protocol(self.session.elm.protocol))

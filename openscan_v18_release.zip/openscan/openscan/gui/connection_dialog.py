"""Adapter connection dialog: pick a transport (serial/COM, Linux
Bluetooth RFCOMM, or Windows J2534) and build a Transport for it."""

from __future__ import annotations

import platform

from PySide6.QtWidgets import (
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
)

from ..core.transport.base import Transport, TransportError
from ..core.transport.serial_link import SerialTransport
from .vin_scanner import VinEntryDialog


class ConnectionDialog(QDialog):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Connect to vehicle")
        self.transport: Transport | None = None
        #: {"make": ..., "model": ..., "year": ...} - populated in
        #: _accept() from the fields below, applied to the session
        #: before connect() so make/model/year are already known up
        #: front (e.g. for auto-selecting a matching manufacturer
        #: enhanced-PID plugin) rather than only after the fact.
        self.vehicle_info: dict[str, str] = {}

        layout = QVBoxLayout(self)

        vehicle_box = QGroupBox("Vehicle info (optional, before connecting)")
        vehicle_form = QFormLayout(vehicle_box)

        vin_row = QHBoxLayout()
        self.vin_edit = QLineEdit()
        self.vin_edit.setPlaceholderText("17-character VIN")
        self.vin_edit.setMaxLength(17)
        vin_row.addWidget(self.vin_edit)
        vin_scan_btn = QPushButton("Scan/Enter...")
        vin_scan_btn.setToolTip("Opens a bigger VIN entry dialog with an optional camera barcode scan.")
        vin_scan_btn.clicked.connect(self._open_vin_dialog)
        vin_row.addWidget(vin_scan_btn)
        vehicle_form.addRow("VIN", vin_row)

        self.make_edit = QLineEdit()
        self.make_edit.setPlaceholderText("e.g. Toyota")
        self.model_edit = QLineEdit()
        self.model_edit.setPlaceholderText("e.g. Corolla")
        self.year_edit = QLineEdit()
        self.year_edit.setPlaceholderText("e.g. 2016")
        vehicle_form.addRow("Make", self.make_edit)
        vehicle_form.addRow("Model", self.model_edit)
        vehicle_form.addRow("Year", self.year_edit)
        vehicle_note = QLabel(
            "All of this is optional - entering the make automatically "
            "activates that manufacturer's enhanced-PID plugin, if one "
            "is installed. If you leave VIN blank and the vehicle "
            "doesn't answer a VIN request after connecting, you'll be "
            "asked for it again before the main window opens."
        )
        vehicle_note.setWordWrap(True)
        vehicle_note.setStyleSheet("color: gray;")
        vehicle_form.addRow(vehicle_note)
        layout.addWidget(vehicle_box)

        form = QFormLayout()

        self.kind_combo = QComboBox()
        self.kind_combo.addItem(
            "USB / Serial / COM port (USB ELM327 cable, or Veepeak paired as COM)", "serial",
        )
        if platform.system() != "Windows":
            self.kind_combo.addItem("Bluetooth (Linux RFCOMM, Veepeak)", "bluetooth")
        else:
            self.kind_combo.addItem("J2534 pass-thru (TOPDON ONE VCI, Windows)", "j2534")
        self.kind_combo.currentIndexChanged.connect(self._refresh_targets)
        form.addRow("Adapter type", self.kind_combo)

        self.target_combo = QComboBox()
        self.target_combo.setEditable(True)
        form.addRow("Device", self.target_combo)

        scan_row = QHBoxLayout()
        refresh_btn = QPushButton("Scan")
        refresh_btn.clicked.connect(self._refresh_targets)
        scan_row.addWidget(refresh_btn)
        self.quick_connect_btn = QPushButton("Quick Connect (auto-detect USB adapter)")
        self.quick_connect_btn.setToolTip(
            "Tries every detected USB/serial port in turn, sending an "
            "ATI handshake, and connects to the first one that answers "
            "like an ELM327 adapter - no need to know which COM port it "
            "landed on."
        )
        self.quick_connect_btn.clicked.connect(self._quick_connect)
        scan_row.addWidget(self.quick_connect_btn)
        form.addRow("", scan_row)

        layout.addLayout(form)
        layout.addWidget(QLabel(
            "Tip: on Windows, pair your Bluetooth adapter first in Settings, "
            "then pick its COM port here. See docs/HARDWARE.md for details "
            "on Veepeak vs. TOPDON ONE capabilities."
        ))

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self._refresh_targets()

    def _open_vin_dialog(self) -> None:
        dialog = VinEntryDialog(
            self, title="Enter VIN", initial_vin=self.vin_edit.text().strip(),
            message="Enter the VIN manually, or scan its barcode with a camera if available.",
        )
        if dialog.exec() and dialog.vin:
            self.vin_edit.setText(dialog.vin)

    def _refresh_targets(self) -> None:
        self.target_combo.clear()
        kind = self.kind_combo.currentData()
        self.quick_connect_btn.setVisible(kind == "serial")
        if kind == "serial":
            ports = SerialTransport.list_ports()
            if not ports:
                self.target_combo.addItem(
                    "No serial/USB ports detected — is the cable plugged in?", None,
                )
            for device, description in ports:
                self.target_combo.addItem(f"{device} — {description}", device)
        elif kind == "bluetooth":
            try:
                from ..core.transport.bluetooth_rfcomm import BluetoothRfcommTransport
                for addr, dev_name in BluetoothRfcommTransport.discover():
                    self.target_combo.addItem(f"{dev_name} ({addr})", addr)
            except Exception as exc:  # noqa: BLE001
                self.target_combo.addItem(f"Scan failed: {exc}", None)
        elif kind == "j2534":
            try:
                import struct as _struct
                from ..core.transport.j2534 import J2534Transport
                python_bits = "64-bit" if _struct.calcsize("P") == 8 else "32-bit"
                for name, (dll_path, bitness) in J2534Transport.discover().items():
                    warn = "" if bitness == python_bits else (
                        f"  ⚠ {bitness} DLL, this Python is {python_bits} — "
                        "will fail to load, see docs/HARDWARE.md"
                    )
                    self.target_combo.addItem(f"{name} ({bitness}){warn}", dll_path)
                if self.target_combo.count() == 0:
                    self.target_combo.addItem(
                        "No J2534 devices found in registry — is the TOPDON "
                        "driver/software installed?", None,
                    )
            except Exception as exc:  # noqa: BLE001
                self.target_combo.addItem(f"Scan failed: {exc}", None)

    def _quick_connect(self) -> None:
        ports = SerialTransport.list_ports()
        if not ports:
            QMessageBox.warning(
                self, "No ports found",
                "No serial/USB ports detected. Make sure the cable is "
                "plugged in and, on Windows, that its driver installed "
                "(check Device Manager for a new COM port when you plug "
                "it in).",
            )
            return
        self.quick_connect_btn.setEnabled(False)
        self.quick_connect_btn.setText("Probing ports...")
        try:
            for device, description in ports:
                if SerialTransport.probe(device):
                    self.target_combo.setCurrentText(f"{device} — {description}")
                    try:
                        self.transport = SerialTransport(device)
                    except TransportError as exc:
                        QMessageBox.critical(self, "Connection error", str(exc))
                        return
                    self.vehicle_info = {
                        k: v for k, v in (
                            ("vin", self.vin_edit.text().strip().upper()),
                            ("make", self.make_edit.text().strip()),
                            ("model", self.model_edit.text().strip()),
                            ("year", self.year_edit.text().strip()),
                        ) if v
                    }
                    self.accept()
                    return
        finally:
            self.quick_connect_btn.setEnabled(True)
            self.quick_connect_btn.setText("Quick Connect (auto-detect USB adapter)")
        QMessageBox.warning(
            self, "No adapter found",
            f"Tried all {len(ports)} detected port(s) but none answered "
            f"like an ELM327 adapter. Pick the port manually from the "
            f"list below instead, or double-check the cable/driver.",
        )

    def _accept(self) -> None:
        kind = self.kind_combo.currentData()
        target = self.target_combo.currentData() or self.target_combo.currentText()
        try:
            if kind == "serial":
                self.transport = SerialTransport(target)
            elif kind == "bluetooth":
                from ..core.transport.bluetooth_rfcomm import BluetoothRfcommTransport
                self.transport = BluetoothRfcommTransport(target)
            elif kind == "j2534":
                from ..core.transport.j2534 import J2534Transport
                self.transport = J2534Transport(target)
        except TransportError as exc:
            QMessageBox.critical(self, "Connection error", str(exc))
            return
        self.vehicle_info = {
            k: v for k, v in (
                ("vin", self.vin_edit.text().strip().upper()),
                ("make", self.make_edit.text().strip()),
                ("model", self.model_edit.text().strip()),
                ("year", self.year_edit.text().strip()),
            ) if v
        }
        self.accept()

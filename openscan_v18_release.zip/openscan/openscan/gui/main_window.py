"""Main application window: connection lifecycle + tabbed views."""

from __future__ import annotations

from PySide6.QtWidgets import (
    QApplication,
    QLabel,
    QMainWindow,
    QMessageBox,
    QTabWidget,
    QToolBar,
)

from .. import __version__
from ..core.plugin_api import PluginRegistry
from ..core.transport.base import TransportError
from ..core.vehicle import VehicleSession
from ..plugins.loader import load_plugins
from .adapter_log_panel import AdapterLogPanel
from .bidirectional_panel import BidirectionalPanel
from .connection_dialog import ConnectionDialog
from .dashboard import DashboardWidget
from .dtc_history_panel import DtcHistoryPanel
from .dtc_panel import DtcPanel
from .format_utils import describe_protocol
from .readiness_panel import ReadinessPanel
from .theme import DARK_QSS
from .topology_view import TopologyView
from .vin_panel import VinPanel
from .vin_scanner import VinEntryDialog


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("OpenScan")
        self.resize(1000, 700)

        self.session: VehicleSession | None = None
        self.dashboard: DashboardWidget | None = None

        self.tabs = QTabWidget()
        self.setCentralWidget(self.tabs)

        toolbar = QToolBar("Main")
        self.addToolBar(toolbar)
        connect_action = toolbar.addAction("Connect")
        connect_action.triggered.connect(self.open_connection_dialog)
        disconnect_action = toolbar.addAction("Disconnect")
        disconnect_action.triggered.connect(self.disconnect_vehicle)
        self.dark_mode_action = toolbar.addAction("Dark mode")
        self.dark_mode_action.setCheckable(True)
        self.dark_mode_action.toggled.connect(self._toggle_dark_mode)

        self.status_label = QLabel("Not connected")
        self.statusBar().addWidget(self.status_label)

        # Permanent widgets are pinned to the right edge of the status bar,
        # unlike addWidget() ones (left-aligned) - exactly where users
        # expect an app's version number to live.
        version_label = QLabel(f"OpenScan v{__version__}")
        version_label.setStyleSheet("color: gray;")
        self.statusBar().addPermanentWidget(version_label)

        try:
            self.plugins: PluginRegistry = load_plugins(include_examples=False)
        except Exception:  # noqa: BLE001 - plugin loading must never block startup
            self.plugins = PluginRegistry()

    def _toggle_dark_mode(self, checked: bool) -> None:
        app = QApplication.instance()
        if app is not None:
            app.setStyleSheet(DARK_QSS if checked else "")

    def open_connection_dialog(self) -> None:
        dialog = ConnectionDialog(self)
        if dialog.exec() and dialog.transport is not None:
            self._connect(dialog.transport, dialog.vehicle_info)

    def _connect(self, transport, vehicle_info: dict | None = None) -> None:
        session = VehicleSession(transport=transport, plugins=self.plugins)
        if vehicle_info:
            # Set before connect() so make-specific enhanced-PID plugins
            # (see openscan/plugins/enhanced/) are already selected by
            # the time the first live-data scan runs, instead of only
            # taking effect after a later Vehicle Info tab edit + reconnect.
            session.set_vehicle_info(
                vin=vehicle_info.get("vin"),
                make=vehicle_info.get("make"),
                model=vehicle_info.get("model"),
                year=vehicle_info.get("year"),
            )
        try:
            session.connect()
        except TransportError as exc:
            QMessageBox.critical(self, "Connection failed", str(exc))
            return
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Connection failed", f"Unexpected error: {exc}")
            return

        if not session.vin:
            # Neither a pre-entered VIN nor the post-connect auto-read
            # (Mode 09) produced anything - ask once more before the
            # main window opens, rather than silently proceeding with
            # "unknown". Skippable (Cancel just leaves it blank) since
            # nothing in the app actually requires a VIN to function.
            dialog = VinEntryDialog(
                self, title="VIN not found",
                message=(
                    "OpenScan couldn't read the VIN automatically from "
                    "this vehicle. Enter it manually, or scan its "
                    "barcode with a camera if available - or Cancel to "
                    "continue without one."
                ),
            )
            if dialog.exec() and dialog.vin:
                session.set_vehicle_info(vin=dialog.vin)

        self.session = session
        n_supported = len(session.obd2.active_pids or [])
        n_known = len(session.obd2.pids)
        self.status_label.setText(
            f"Connected via {transport.name} — protocol "
            f"{describe_protocol(session.elm.protocol)} — "
            f"VIN {session.vin or 'unknown'} — {n_supported}/{n_known} parameters supported"
        )
        self._build_tabs()

    def _build_tabs(self) -> None:
        assert self.session is not None
        self.tabs.clear()

        self.dashboard = DashboardWidget(self.session)
        self.tabs.addTab(self.dashboard, "Live Data")
        self.dashboard.start_polling()

        self.tabs.addTab(DtcPanel(self.session), "Diagnostic Codes")
        self.tabs.addTab(DtcHistoryPanel(self.session), "DTC History")
        self.tabs.addTab(ReadinessPanel(self.session), "Readiness / Freeze Frame")
        self.tabs.addTab(TopologyView(self.session), "Topology")
        self.tabs.addTab(VinPanel(self.session), "Vehicle Info")
        self.tabs.addTab(BidirectionalPanel(self.session), "Bidirectional Tests")
        self.tabs.addTab(AdapterLogPanel(self.session), "Adapter Log")

    def disconnect_vehicle(self) -> None:
        if self.dashboard is not None:
            self.dashboard.stop_polling()
            self.dashboard = None
        if self.session is not None:
            self.session.disconnect()
            self.session = None
        self.tabs.clear()
        self.status_label.setText("Not connected")

    def closeEvent(self, event) -> None:  # noqa: N802 - Qt override
        self.disconnect_vehicle()
        super().closeEvent(event)

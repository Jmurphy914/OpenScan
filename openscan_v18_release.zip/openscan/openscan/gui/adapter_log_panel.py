"""Raw adapter traffic log: shows the last few hundred command/response
pairs exactly as the adapter sent them. Exists mainly for diagnosing
real-hardware issues concretely - copy/paste this instead of describing
symptoms secondhand when something looks wrong."""

from __future__ import annotations

import time

from PySide6.QtWidgets import (
    QHBoxLayout,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from ..core.vehicle import VehicleSession


class AdapterLogPanel(QWidget):
    def __init__(self, session: VehicleSession, parent=None):
        super().__init__(parent)
        self.session = session

        layout = QVBoxLayout(self)

        self.table = QTableWidget(0, 3)
        self.table.setHorizontalHeaderLabels(["Time", "Command sent", "Raw response"])
        self.table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.table)

        button_row = QHBoxLayout()
        refresh_btn = QPushButton("Refresh log")
        refresh_btn.clicked.connect(self.refresh)
        clear_btn = QPushButton("Clear log")
        clear_btn.clicked.connect(self._clear)
        button_row.addWidget(refresh_btn)
        button_row.addWidget(clear_btn)
        layout.addLayout(button_row)

    def refresh(self) -> None:
        entries = self.session.elm.get_log()
        self.table.setRowCount(0)
        # newest first - the most recent traffic is almost always what
        # you actually want to look at.
        for entry in reversed(entries):
            row = self.table.rowCount()
            self.table.insertRow(row)
            ts = time.strftime("%H:%M:%S", time.localtime(entry.timestamp))
            self.table.setItem(row, 0, QTableWidgetItem(ts))
            self.table.setItem(row, 1, QTableWidgetItem(entry.command))
            response_display = entry.response if entry.response else "(no response / NO DATA)"
            self.table.setItem(row, 2, QTableWidgetItem(response_display))

    def _clear(self) -> None:
        self.session.elm.clear_log()
        self.table.setRowCount(0)

"""Bidirectional / Actuator Tests panel.

Deliberately limited in scope. Real bidirectional actuator tests (fan
on/off, injector cutout, ABS bleed sequences, service resets, key/TPMS
programming) are triggered by manufacturer-specific routine IDs that
aren't published - the same reason openscan/plugins/enhanced/ ships a
framework with placeholder identifiers rather than invented ones.
Presenting a curated list of "Test A / Test B" buttons here that
secretly don't do what they claim, or that send an unverified guess of
a routine ID to a real vehicle, would be actively harmful rather than
just incomplete.

What's here instead is the two things that are genuinely standardized
(or at least genuinely generic) and safe to expose without fabricating
anything:

1. A raw custom-command box - sends exactly what you type, no more, no
   less. This is the same "advanced/custom PID" escape hatch commercial
   tools include for power users, and it's how you'd explore/verify a
   real manufacturer routine ID yourself before it's worth adding to a
   plugin (see openscan/plugins/enhanced/README.md for the same
   verify-before-trusting workflow).
2. An SAE J1979 Mode 0x08 ("Request control of on-board system, test,
   or component") wrapper. Mode 08 itself is part of the standard, but
   the Test IDs *within* it are not standardized in practice and vary
   by vehicle - most consumer vehicles don't implement Mode 08 at all,
   so this will very likely just return NO DATA. It's included anyway
   because on the rare vehicle that does support it, this is genuinely
   the correct standardized way to ask - no invented codes needed.
"""

from __future__ import annotations

from PySide6.QtWidgets import (
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from ..core.vehicle import VehicleSession

_WARNING_TEXT = (
    "Advanced tools - these send commands directly to the vehicle "
    "exactly as entered. Only send a command you understand; some "
    "requests can change vehicle behavior (that's the whole point of "
    "\"bidirectional\"). Nothing here is manufacturer-specific or "
    "invented - see the module docstring for why real actuator tests "
    "(fan control, ABS bleed, resets, etc.) aren't offered as ready-made "
    "buttons."
)


class BidirectionalPanel(QWidget):
    def __init__(self, session: VehicleSession, parent=None):
        super().__init__(parent)
        self.session = session

        layout = QVBoxLayout(self)

        warning = QLabel(_WARNING_TEXT)
        warning.setWordWrap(True)
        warning.setStyleSheet("color: #b45309; font-weight: bold;")
        layout.addWidget(warning)

        # -- raw custom command -------------------------------------------------
        custom_box = QGroupBox("Custom command")
        custom_layout = QVBoxLayout(custom_box)
        input_row = QHBoxLayout()
        self.custom_edit = QLineEdit()
        self.custom_edit.setPlaceholderText("e.g. 010C, ATRV, 22F190, 08016300...")
        input_row.addWidget(self.custom_edit, stretch=1)
        send_btn = QPushButton("Send")
        send_btn.clicked.connect(self._send_custom)
        input_row.addWidget(send_btn)
        custom_layout.addLayout(input_row)
        self.custom_log = QPlainTextEdit()
        self.custom_log.setReadOnly(True)
        self.custom_log.setMaximumBlockCount(500)
        custom_layout.addWidget(self.custom_log)
        layout.addWidget(custom_box)

        # -- Mode 08 I/O control experimental ------------------------------------
        mode08_box = QGroupBox("SAE J1979 Mode 08 - I/O control test (experimental)")
        mode08_layout = QVBoxLayout(mode08_box)
        mode08_note = QLabel(
            "Test IDs are not standardized in practice and vary by "
            "vehicle - most vehicles don't support Mode 08 at all and "
            "this will likely return NO DATA. Included because it's the "
            "one genuinely generic bidirectional mechanism SAE J1979 "
            "defines, not because a specific Test ID here is known to "
            "do anything in particular."
        )
        mode08_note.setWordWrap(True)
        mode08_note.setStyleSheet("color: gray;")
        mode08_layout.addWidget(mode08_note)
        mode08_row = QHBoxLayout()
        mode08_row.addWidget(QLabel("Test ID (hex byte):"))
        self.tid_edit = QLineEdit()
        self.tid_edit.setPlaceholderText("e.g. 01")
        self.tid_edit.setMaxLength(2)
        mode08_row.addWidget(self.tid_edit)
        mode08_row.addWidget(QLabel("Data (hex, optional):"))
        self.tid_data_edit = QLineEdit()
        self.tid_data_edit.setPlaceholderText("e.g. 6300")
        mode08_row.addWidget(self.tid_data_edit)
        mode08_send_btn = QPushButton("Send Mode 08 request")
        mode08_send_btn.clicked.connect(self._send_mode08)
        mode08_row.addWidget(mode08_send_btn)
        mode08_layout.addLayout(mode08_row)
        layout.addWidget(mode08_box)

        layout.addStretch(1)

    def _append_log(self, command: str, response: str) -> None:
        self.custom_log.appendPlainText(f">>> {command}\n{response}\n")

    def _send_custom(self) -> None:
        command = self.custom_edit.text().strip()
        if not command:
            return
        try:
            response = self.session.elm.raw_command(command)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Command failed", str(exc))
            return
        self._append_log(command, response)

    def _send_mode08(self) -> None:
        tid = self.tid_edit.text().strip()
        if not tid:
            QMessageBox.warning(self, "Test ID required", "Enter a hex Test ID byte (e.g. 01).")
            return
        try:
            int(tid, 16)
        except ValueError:
            QMessageBox.warning(self, "Invalid Test ID", f"'{tid}' isn't a valid hex byte.")
            return
        data = self.tid_data_edit.text().strip()
        command = f"08{tid}{data}"
        try:
            response = self.session.elm.raw_command(command)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, "Command failed", str(exc))
            return
        self._append_log(command, response)

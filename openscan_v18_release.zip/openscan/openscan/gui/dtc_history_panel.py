"""DTC History tab: every code ever seen on this vehicle, persisted
across app restarts (see core/dtc_history.py) - unlike the Diagnostic
Codes tab, which only shows what's currently stored on the ECU right
now. Useful for an intermittent problem that comes and goes between
drives, or a code that got cleared before you had a chance to note it."""

from __future__ import annotations

from PySide6.QtWidgets import (
    QCheckBox,
    QHBoxLayout,
    QMessageBox,
    QPushButton,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from ..core.dtc_history import clear_history, load_history
from ..core.vehicle import VehicleSession


class DtcHistoryPanel(QWidget):
    def __init__(self, session: VehicleSession, parent=None):
        super().__init__(parent)
        self.session = session

        layout = QVBoxLayout(self)

        button_row = QHBoxLayout()
        self.this_vehicle_only = QCheckBox("This vehicle only (by VIN)")
        self.this_vehicle_only.setChecked(bool(session.vin))
        self.this_vehicle_only.setEnabled(bool(session.vin))
        self.this_vehicle_only.stateChanged.connect(self._refresh)
        button_row.addWidget(self.this_vehicle_only)
        refresh_btn = QPushButton("Refresh")
        refresh_btn.clicked.connect(self._refresh)
        button_row.addWidget(refresh_btn)
        clear_btn = QPushButton("Clear history")
        clear_btn.clicked.connect(self._clear)
        button_row.addWidget(clear_btn)
        layout.addLayout(button_row)

        self.table = QTableWidget(0, 6)
        self.table.setHorizontalHeaderLabels(
            ["Code", "Description", "VIN", "First seen", "Last seen", "Times seen"]
        )
        self.table.setSortingEnabled(True)
        self.table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.table)

        self._refresh()

    def _refresh(self) -> None:
        vin = self.session.vin if self.this_vehicle_only.isChecked() else None
        entries = load_history(vin=vin)
        self.table.setSortingEnabled(False)
        self.table.setRowCount(len(entries))
        for row, entry in enumerate(entries):
            self.table.setItem(row, 0, QTableWidgetItem(entry.code))
            self.table.setItem(row, 1, QTableWidgetItem(entry.description))
            self.table.setItem(row, 2, QTableWidgetItem(entry.vin or "(unknown)"))
            self.table.setItem(row, 3, QTableWidgetItem(entry.first_seen))
            self.table.setItem(row, 4, QTableWidgetItem(entry.last_seen))
            self.table.setItem(row, 5, QTableWidgetItem(str(entry.times_seen)))
        self.table.setSortingEnabled(True)

    def _clear(self) -> None:
        confirm = QMessageBox.question(
            self, "Clear DTC history",
            "This permanently deletes the entire saved DTC history for "
            "every vehicle, not just this one. Continue?",
        )
        if confirm != QMessageBox.Yes:
            return
        clear_history()
        self._refresh()

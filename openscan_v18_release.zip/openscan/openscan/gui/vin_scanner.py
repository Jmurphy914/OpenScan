"""VIN entry dialog with an optional live camera barcode scan.

Most vehicles built in the last few decades carry the VIN as a Code 39
barcode on a sticker (driver's door jamb, engine bay, or a corner of
the windshield) in addition to the printed/etched characters - decoding
that barcode with a webcam is far more reliable than trying to OCR
stamped or etched VIN text (glare, odd fonts, curved surfaces), so
that's the approach used here rather than OCR.

Camera scanning is entirely optional and gracefully degrades: if
opencv-python and pyzbar aren't installed (they're optional - see
requirements.txt) or no camera is available, the scan button is simply
disabled with an explanation, and typing the VIN in always works.
This hasn't been validated against real hardware yet - if the barcode
on your vehicle doesn't scan, manual entry is the reliable fallback.
"""

from __future__ import annotations

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QVBoxLayout,
)

try:
    import cv2
except ImportError:  # optional dependency
    cv2 = None

try:
    from pyzbar.pyzbar import decode as _zbar_decode
except ImportError:  # optional dependency
    _zbar_decode = None

from ..core.vin import looks_like_vin

CAMERA_AVAILABLE = cv2 is not None and _zbar_decode is not None


class VinEntryDialog(QDialog):
    """Modal VIN entry, with an optional live camera barcode scan.
    Always usable purely by typing, even with no camera or without the
    optional cv2/pyzbar packages installed."""

    def __init__(self, parent=None, title: str = "Enter VIN",
                 message: str | None = None, initial_vin: str = ""):
        super().__init__(parent)
        self.setWindowTitle(title)
        self.vin: str | None = None
        self._capture = None

        layout = QVBoxLayout(self)
        if message:
            msg_label = QLabel(message)
            msg_label.setWordWrap(True)
            layout.addWidget(msg_label)

        self.camera_label = QLabel("Camera preview")
        self.camera_label.setFixedSize(320, 240)
        self.camera_label.setStyleSheet("background: #222; color: #aaa;")
        self.camera_label.setAlignment(Qt.AlignCenter)
        self.camera_label.hide()
        layout.addWidget(self.camera_label, alignment=Qt.AlignHCenter)

        form = QFormLayout()
        self.vin_edit = QLineEdit(initial_vin)
        self.vin_edit.setPlaceholderText("17-character VIN")
        self.vin_edit.setMaxLength(17)
        form.addRow("VIN", self.vin_edit)
        layout.addLayout(form)

        button_row = QHBoxLayout()
        self.scan_btn = QPushButton("Scan VIN barcode with camera")
        self.scan_btn.setCheckable(True)
        self.scan_btn.clicked.connect(self._toggle_scan)
        button_row.addWidget(self.scan_btn)
        layout.addLayout(button_row)

        if not CAMERA_AVAILABLE:
            self.scan_btn.setEnabled(False)
            self.scan_btn.setToolTip(
                "Requires the optional opencv-python and pyzbar packages "
                "(pip install opencv-python pyzbar) plus a connected "
                "camera. Manual entry below always works regardless."
            )

        note = QLabel(
            "Tip: most vehicles have the VIN as a barcode sticker in the "
            "driver's door jamb or on the dash (visible through the "
            "windshield). Scanning that barcode is far more reliable "
            "than trying to read the etched/printed characters with a "
            "camera - this hasn't been tested on real hardware yet, so "
            "manual entry is the dependable fallback if it doesn't work."
        )
        note.setWordWrap(True)
        note.setStyleSheet("color: gray;")
        layout.addWidget(note)

        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.accepted.connect(self._accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

        self._timer = QTimer(self)
        self._timer.timeout.connect(self._grab_frame)

    def _toggle_scan(self, checked: bool) -> None:
        if checked:
            self._capture = cv2.VideoCapture(0)
            if not self._capture.isOpened():
                QMessageBox.warning(
                    self, "Camera",
                    "Couldn't open a camera. Enter the VIN manually below.",
                )
                self.scan_btn.setChecked(False)
                self._capture = None
                return
            self.camera_label.show()
            self._timer.start(150)
            self.scan_btn.setText("Stop scanning")
        else:
            self._stop_scan()

    def _stop_scan(self) -> None:
        self._timer.stop()
        if self._capture is not None:
            self._capture.release()
            self._capture = None
        self.camera_label.hide()
        self.scan_btn.setChecked(False)
        self.scan_btn.setText("Scan VIN barcode with camera")

    def _grab_frame(self) -> None:
        if self._capture is None:
            return
        ok, frame = self._capture.read()
        if not ok:
            return
        from PySide6.QtGui import QImage, QPixmap
        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        h, w, ch = rgb.shape
        qimg = QImage(rgb.data, w, h, ch * w, QImage.Format_RGB888)
        self.camera_label.setPixmap(
            QPixmap.fromImage(qimg).scaled(
                self.camera_label.width(), self.camera_label.height(),
                Qt.KeepAspectRatio,
            )
        )
        for symbol in _zbar_decode(frame):
            payload = symbol.data.decode("utf-8", errors="ignore")
            if looks_like_vin(payload):
                self.vin_edit.setText(payload.strip().upper())
                self._stop_scan()
                break

    def _accept(self) -> None:
        self._stop_scan()
        vin = self.vin_edit.text().strip().upper()
        if vin and not looks_like_vin(vin):
            confirm = QMessageBox.question(
                self, "VIN format",
                f"'{vin}' doesn't look like a standard 17-character VIN "
                f"(no I/O/Q characters allowed). Use it anyway?",
            )
            if confirm != QMessageBox.Yes:
                return
        self.vin = vin or None
        self.accept()

    def reject(self) -> None:  # noqa: N802 - Qt override
        self._stop_scan()
        super().reject()

    def closeEvent(self, event) -> None:  # noqa: N802 - Qt override
        self._stop_scan()
        super().closeEvent(event)

"""Discovers and loads plugin modules from `openscan/plugins/` (excluding
this loader and `examples/`, which is opt-in via explicit import so a
fresh checkout doesn't silently activate demo/sample plugins).

Real plugins can be a single top-level module (openscan/plugins/foo.py
with a register() function) or a package grouping several related
modules, e.g. `enhanced/` - one file per manufacturer's best-effort
enhanced PID set (see openscan/plugins/enhanced/README for how those
were sourced and their accuracy caveats). Any subpackage other than
`examples` is always recursed into and loaded, since - unlike the demo
plugin - those are meant to be active by default.
"""

from __future__ import annotations

import importlib
import pkgutil

from ..core.plugin_api import PluginRegistry

_SKIP = {"loader", "__init__"}


def load_plugins(package: str = "openscan.plugins",
                  include_examples: bool = False) -> PluginRegistry:
    registry = PluginRegistry()
    pkg = importlib.import_module(package)
    for _, modname, is_pkg in pkgutil.iter_modules(pkg.__path__):
        if modname in _SKIP:
            continue
        if modname == "examples" and not include_examples:
            continue
        full_name = f"{package}.{modname}"
        module = importlib.import_module(full_name)
        if hasattr(module, "register"):
            module.register(registry)
        if is_pkg:
            # Recurse one level into any plugin sub-package, picking up
            # every module inside that exposes its own register().
            sub_pkg = importlib.import_module(full_name)
            for _, sub_modname, _ in pkgutil.iter_modules(sub_pkg.__path__):
                if sub_modname == "__init__":
                    continue
                sub_full = f"{full_name}.{sub_modname}"
                sub_module = importlib.import_module(sub_full)
                if hasattr(sub_module, "register"):
                    sub_module.register(registry)
    return registry

"""Example plugin demonstrating the extension points a real OEM plugin
would use. Contains no proprietary data — the "security algorithm" here
is an obviously-fake XOR placeholder, not a real one, and the routine IDs
are made up. Copy this file's structure for a real plugin, replacing the
fake bits with data you're legally entitled to use.

Not loaded by default — enable explicitly with
`load_plugins(include_examples=True)`.
"""

from __future__ import annotations

from openscan.core.obd2.pids import PidDefinition, raw_2byte
from openscan.core.plugin_api import (
    DtcPlugin,
    PidPlugin,
    PluginRegistry,
    RoutinePlugin,
    SecurityAlgoPlugin,
)
from openscan.core.uds.uds import RoutineDefinition


class DemoPidPlugin(PidPlugin):
    def pids(self) -> dict[int, PidDefinition]:
        return {
            0xF190: PidDefinition(
                pid=0xF190, name="Demo Custom Sensor", unit="units",
                n_bytes=2, decode=raw_2byte,
            ),
        }


class DemoDtcPlugin(DtcPlugin):
    def descriptions(self) -> dict[str, str]:
        return {
            "P1DEM": "Demo Manufacturer-Specific Code (placeholder — not a real DTC)",
        }


class DemoSecurityAlgo(SecurityAlgoPlugin):
    make = "DemoMotors"

    def compute_key(self, seed: bytes, level: int) -> bytes:
        # Placeholder only — real algorithms are make-specific and NOT
        # something OpenScan ships. Replace with your own legally-sourced
        # implementation.
        return bytes((b ^ 0xFF) for b in seed)


class DemoRoutinePlugin(RoutinePlugin):
    make = "DemoMotors"

    def routines(self) -> dict[str, RoutineDefinition]:
        return {
            "demo_actuator_test": RoutineDefinition(
                name="Demo Actuator Test",
                routine_id=0x1234,
                ecu_id=0x7E0,
            ),
        }


def register(registry: PluginRegistry) -> None:
    registry.register_pid_plugin(DemoPidPlugin())
    registry.register_dtc_plugin(DemoDtcPlugin())
    registry.register_security_algo(DemoSecurityAlgo())
    registry.register_routine_plugin(DemoRoutinePlugin())

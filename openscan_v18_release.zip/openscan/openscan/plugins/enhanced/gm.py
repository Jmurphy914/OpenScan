"""GM (Chevrolet / GMC / Cadillac / Buick) enhanced PID plugin.

See README.md in this directory: the identifier below is a clearly
marked PLACEHOLDER, not a verified real DID. It's fully wired up
(Mode 0x22, auto-activates only for a declared GM-family vehicle) -
replace it once you've confirmed a real identifier against real
hardware."""

from __future__ import annotations

from openscan.core.obd2.pids import PidDefinition, raw_2byte
from openscan.core.plugin_api import PidPlugin, PluginRegistry


class GmPidPlugin(PidPlugin):
    make_aliases = {"chevrolet", "chevy", "gmc", "cadillac", "buick", "gm"}

    def pids(self) -> dict[int, PidDefinition]:
        return {
            0xF203: PidDefinition(
                pid=0xF203,
                name="GM Enhanced PID Example (placeholder)",
                unit="raw",
                n_bytes=2,
                decode=raw_2byte,
                mode=0x22,
            ),
        }


def register(registry: PluginRegistry) -> None:
    registry.register_pid_plugin(GmPidPlugin())

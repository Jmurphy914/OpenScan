"""Volkswagen / Audi (VAG) enhanced PID plugin.

See README.md in this directory: the identifier below is a clearly
marked PLACEHOLDER, not a verified real DID. It's fully wired up
(Mode 0x22, auto-activates only for a declared VW/Audi vehicle) -
replace it once you've confirmed a real identifier against real
hardware. Note: VAG vehicles are unusually well documented by the
Ross-Tech community (the makers of VCDS) - if any brand here is worth
searching out real values for first, it's this one."""

from __future__ import annotations

from openscan.core.obd2.pids import PidDefinition, raw_2byte
from openscan.core.plugin_api import PidPlugin, PluginRegistry


class VwAudiPidPlugin(PidPlugin):
    make_aliases = {"volkswagen", "vw", "audi"}

    def pids(self) -> dict[int, PidDefinition]:
        return {
            0xF206: PidDefinition(
                pid=0xF206,
                name="VW/Audi Enhanced PID Example (placeholder)",
                unit="raw",
                n_bytes=2,
                decode=raw_2byte,
                mode=0x22,
            ),
        }


def register(registry: PluginRegistry) -> None:
    registry.register_pid_plugin(VwAudiPidPlugin())

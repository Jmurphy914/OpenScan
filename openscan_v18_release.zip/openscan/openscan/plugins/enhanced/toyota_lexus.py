"""Toyota / Lexus / Scion enhanced PID plugin.

See README.md in this directory before trusting anything here: the
identifier below is a clearly-marked PLACEHOLDER (same convention as
openscan/plugins/examples/demo_plugin.py), not a verified real DID.
It's wired up correctly - Mode 0x22, auto-activates only when the
declared vehicle make is Toyota/Lexus/Scion, response identifier bytes
handled correctly - so once you confirm a real identifier for your
vehicle (see README.md's "how to turn a placeholder into a real PID"),
dropping it in here is all it takes to have it show up live in the
dashboard.

This is the one plugin in this directory you're actually equipped to
validate yourself: you have a real 2016 Corolla and a working Adapter
Log tab. If you go looking for a real Toyota enhanced identifier and
confirm one, this is the file to update.
"""

from __future__ import annotations

from openscan.core.obd2.pids import PidDefinition, raw_2byte
from openscan.core.plugin_api import PidPlugin, PluginRegistry


class ToyotaLexusPidPlugin(PidPlugin):
    make_aliases = {"toyota", "lexus", "scion"}

    def pids(self) -> dict[int, PidDefinition]:
        return {
            0xF200: PidDefinition(
                pid=0xF200,
                name="Toyota Enhanced PID Example (placeholder)",
                unit="raw",
                n_bytes=2,
                decode=raw_2byte,
                mode=0x22,
            ),
        }


def register(registry: PluginRegistry) -> None:
    registry.register_pid_plugin(ToyotaLexusPidPlugin())

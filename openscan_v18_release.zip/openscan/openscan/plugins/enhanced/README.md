# Enhanced (manufacturer-specific) PID plugins

Generic OBD-II (SAE J1979 Mode 01) is powertrain-only by design and
identical across every make - that's the whole point of "generic." It
physically cannot reach ABS, SRS/airbag, body, HVAC, or infotainment
modules, and it can't expose manufacturer-specific extra powertrain
signals (individual wheel speeds, transmission fluid temperature,
hybrid battery cell detail, etc.) either.

To get *any* of that, a scan tool has to speak a manufacturer's own
diagnostic dialect on top of the standard bus - almost always UDS
service `0x22` (ReadDataByIdentifier) with a 2-byte identifier the
manufacturer chose, instead of Mode 01's 1-byte generic PID. Real
professional tools (Autel, Snap-on, Techstream, etc.) ship this data
because they've licensed it from the manufacturer or reverse-engineered
it in-house over years. OpenScan, being open source, has neither - so
this directory is a **framework and a starting point, not a finished
database**.

## What's actually in these files right now

Each file below (`toyota_lexus.py`, `honda_acura.py`, `nissan_infiniti.py`,
`gm.py`, `ford.py`, `chrysler_stellantis.py`, `vw_audi.py`, `bmw_mini.py`,
`mercedes_benz.py`) is a fully working `PidPlugin` - correctly wired
into the Mode 0x22 request path, correctly filtered by declared vehicle
make (see `PluginRegistry.merged_pids_for_make()`), and ready to show up
in the Live Data tab the moment the vehicle actually answers.

What each one is **not**, yet: a verified list of real identifiers.
The single PID each file currently defines uses an obviously-placeholder
identifier (0xF2xx, the same convention OpenScan's `examples/demo_plugin.py`
uses) and is explicitly labeled as an example, not a researched value. We
did not fabricate specific-looking hex codes and present them as if
they'd been sourced from real reverse-engineering - that would risk
someone trusting a wrong number for an actual repair decision.

## How to turn a placeholder into a real, working PID

1. Find a candidate identifier. Community-maintained sources exist for
   several brands (search e.g. "Toyota enhanced PID list", "VAG-COM /
   Ross-Tech DID list" for VW/Audi, or open-source scanner projects on
   GitHub that target your brand) - OpenScan doesn't bundle any of them
   for licensing/verification reasons, but nothing stops you from adding
   what you find and can confirm.
2. Send it manually and look at the raw bytes: open the Adapter Log tab,
   and note that `22` + a 4-hex-digit identifier (e.g. `221005`) is a
   valid raw request you can reason about from a captured log the same
   way the ISO-TP PCI-byte bug in this project's history was diagnosed -
   from one real captured line, not guesswork.
3. Confirm the decoded value against something you can independently
   verify (a known-good gauge reading, a value that should be zero at
   idle, etc.) before trusting it.
4. Replace the placeholder `PidDefinition` in the relevant file with
   your confirmed identifier/formula, and send a pull request so the
   next person with your make doesn't have to start from zero.

This mirrors exactly how the real ISO-TP PCI-byte and empty-supported-PID
bugs earlier in this project got fixed: real hardware evidence first,
code changes second - never the other way around.

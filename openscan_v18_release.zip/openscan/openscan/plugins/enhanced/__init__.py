"""Manufacturer-specific "enhanced" PID plugins - one file per brand
group. See README.md in this directory for what these are, how they're
sourced, and their accuracy caveats before relying on any of them."""

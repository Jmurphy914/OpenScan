@echo off
REM OpenScan setup for Windows.
REM Works no matter how you launch it - double-click in File Explorer (which
REM runs with this script's own folder as the working directory) or from a
REM Command Prompt anywhere. It always switches to the project root itself
REM (one level up from this scripts\ folder) before doing anything else.

setlocal enabledelayedexpansion
cd /d "%~dp0.."

echo === OpenScan setup ===
echo Working directory: %cd%
echo.

if not exist "requirements.txt" (
    echo [ERROR] Could not find requirements.txt in %cd%
    echo This script expects to live in a "scripts" subfolder directly under
    echo the OpenScan project root. If you moved setup_windows.bat elsewhere,
    echo move it back into openscan\scripts\ and try again.
    pause
    exit /b 1
)

REM -- locate a working Python 3.10+ interpreter -----------------------------
REM Prefer the "py" launcher/install-manager command over "python" - on
REM machines using the newer Python install manager, "python" can be a
REM stale shortcut left pointing at a runtime you've since removed/upgraded,
REM which fails immediately with its own error instead of a normal version
REM string. "py" is the manager's own dispatch and is more reliable.
set "PY_CMD="

py --version >nul 2>nul
if not errorlevel 1 (
    py -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
    if not errorlevel 1 set "PY_CMD=py"
)

if not defined PY_CMD (
    python --version >nul 2>nul
    if not errorlevel 1 (
        python -c "import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)" >nul 2>nul
        if not errorlevel 1 set "PY_CMD=python"
    )
)

if not defined PY_CMD (
    echo [ERROR] Could not find a working Python 3.10+ interpreter via "py" or "python".
    echo.
    echo Raw diagnostic output:
    echo   "py --version" says:
    py --version
    echo   "python --version" says:
    python --version
    echo.
    echo If either of those printed something like "No Python at ...", your
    echo Python install manager's shortcuts are stale. Try, in a NEW terminal:
    echo   py list
    echo   py install 3.12
    echo   py install --refresh
    echo Then re-run this script.
    pause
    exit /b 1
)

for /f "delims=" %%v in ('%PY_CMD% --version 2^>^&1') do echo Using %%v via "%PY_CMD%" command.

REM -- create / reuse a virtual environment ----------------------------------
if not exist ".venv" (
    echo Creating virtual environment in .venv ...
    %PY_CMD% -m venv .venv
    if errorlevel 1 (
        echo [ERROR] Failed to create the virtual environment.
        pause
        exit /b 1
    )
) else (
    echo Reusing existing .venv virtual environment.
)

call .venv\Scripts\activate.bat

echo.
echo Upgrading pip...
python -m pip install --upgrade pip

echo.
echo Installing OpenScan dependencies (PySide6, pyqtgraph, pyserial)...
pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] pip install failed - see the output above for details.
    pause
    exit /b 1
)

echo.
echo === Setup complete ===
echo.
echo To run OpenScan from now on, open a Command Prompt in this folder and run:
echo   .venv\Scripts\activate
echo   python -m openscan
echo.
echo Note: the TOPDON ONE VCI's J2534 pass-thru path needs its own driver/
echo software installed separately (from TOPDON) - it registers the J2534
echo DLL that OpenScan talks to. See docs\HARDWARE.md for details, including
echo a note about 32-bit vs 64-bit Python for that specific path.
echo.
pause

#!/usr/bin/env bash
# OpenScan setup for Linux.
# Can be run from anywhere - always switches to the project root (one level
# up from this scripts/ folder) before doing anything else:
#   bash scripts/setup_linux.sh
#   ./setup_linux.sh   (from inside scripts/)

set -euo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")/.."

echo "=== OpenScan setup ==="
echo "Working directory: $(pwd)"
echo

if [ ! -f "requirements.txt" ]; then
    echo "[ERROR] Could not find requirements.txt in $(pwd)"
    echo "This script expects to live in a scripts/ subfolder directly under"
    echo "the OpenScan project root."
    exit 1
fi

if ! command -v python3 >/dev/null 2>&1; then
    echo "[ERROR] python3 was not found on PATH."
    echo "Install Python 3.10+ with your distro's package manager, e.g.:"
    echo "  sudo apt install python3 python3-venv python3-pip"
    exit 1
fi

PYVER=$(python3 -c 'import sys; print("%d.%d" % sys.version_info[:2])')
echo "Found Python $PYVER"

if ! python3 -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)'; then
    echo "[ERROR] Python 3.10+ is required, found $PYVER."
    exit 1
fi

if [ ! -d ".venv" ]; then
    echo "Creating virtual environment in .venv ..."
    python3 -m venv .venv
else
    echo "Reusing existing .venv virtual environment."
fi

# shellcheck disable=SC1091
source .venv/bin/activate

echo
echo "Upgrading pip..."
python -m pip install --upgrade pip

echo
echo "Installing OpenScan dependencies (PySide6, pyqtgraph, pyserial, pybluez2)..."
pip install -r requirements.txt

cat <<'EOF'

=== Setup complete ===

To run OpenScan from now on:
  source .venv/bin/activate
  python -m openscan

Note: pybluez2 (direct Bluetooth RFCOMM for the Veepeak) needs Bluetooth
dev headers on some distros if the wheel doesn't have a prebuilt binary
for your platform, e.g.:
  sudo apt install libbluetooth-dev
then re-run: pip install -r requirements.txt

Pair the adapter first with bluetoothctl (or your desktop's Bluetooth
settings) before connecting from OpenScan.
EOF

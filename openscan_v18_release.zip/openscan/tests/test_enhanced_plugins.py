"""Tests for the manufacturer enhanced-PID plugin system: that
load_plugins() discovers every file under openscan/plugins/enhanced/,
and that PluginRegistry.merged_pids_for_make() only activates a
manufacturer-specific plugin when the declared vehicle make matches -
this is what stops OpenScan from wasting every poll cycle probing eight
other brands' placeholder PIDs on, say, a real Toyota."""

from openscan.core.plugin_api import PluginRegistry
from openscan.plugins.loader import load_plugins


def test_load_plugins_discovers_all_enhanced_manufacturer_plugins():
    registry = load_plugins(include_examples=False)
    # One plugin per brand group file in openscan/plugins/enhanced/.
    assert len(registry.pid_plugins) >= 9
    all_aliases: set[str] = set()
    for p in registry.pid_plugins:
        assert p.make_aliases, f"{p!r} should declare make_aliases"
        all_aliases |= p.make_aliases
    for expected in ("toyota", "honda", "ford", "gm", "bmw", "vw", "nissan"):
        assert expected in all_aliases


def test_examples_demo_plugin_not_loaded_by_default():
    registry = load_plugins(include_examples=False)
    # The demo plugin's placeholder PID (0xF190) must not leak in unless
    # explicitly opted into via include_examples=True.
    assert 0xF190 not in registry.merged_pids()


def test_merged_pids_for_make_only_activates_matching_brand():
    registry = load_plugins(include_examples=False)
    toyota_pids = registry.merged_pids_for_make("Toyota")
    assert 0xF200 in toyota_pids       # toyota_lexus.py's placeholder
    assert 0xF203 not in toyota_pids   # gm.py's placeholder must not leak in

    ford_pids = registry.merged_pids_for_make("Ford")
    assert 0xF204 in ford_pids
    assert 0xF200 not in ford_pids

    # Case/whitespace shouldn't matter.
    assert 0xF207 in registry.merged_pids_for_make("  BMW  ")


def test_merged_pids_for_make_none_activates_no_manufacturer_plugins():
    # Every plugin currently shipped is manufacturer-specific
    # (make_aliases is always set) - with no declared make, none of
    # them should activate, avoiding wasted bus time probing brands
    # that can't possibly match.
    registry = load_plugins(include_examples=False)
    assert registry.merged_pids_for_make(None) == {}
    assert registry.merged_pids_for_make("") == {}


def test_universal_plugin_always_included_regardless_of_make():
    registry = PluginRegistry()

    class _UniversalPlugin:
        make_aliases = None

        def pids(self):
            return {0x1234: "fake-def-for-this-test"}

    registry.register_pid_plugin(_UniversalPlugin())
    assert registry.merged_pids_for_make(None) == {0x1234: "fake-def-for-this-test"}
    assert registry.merged_pids_for_make("Toyota") == {0x1234: "fake-def-for-this-test"}

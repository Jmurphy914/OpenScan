from openscan.core.obd2.normal_ranges import status_for


def test_status_ok_within_range():
    assert status_for("Coolant Temperature", 195) == "ok"


def test_status_out_of_range_low():
    # Cold engine right after startup - correctly flagged as outside
    # the warmed-up operating band, not "broken."
    assert status_for("Coolant Temperature", 90) == "out_of_range"


def test_status_out_of_range_high():
    assert status_for("Coolant Temperature", 260) == "out_of_range"


def test_status_none_for_condition_dependent_pid():
    # RPM has no fixed "normal" - it depends entirely on what the
    # vehicle is doing right now, so it must not be in NORMAL_RANGES.
    assert status_for("Engine RPM", 3000) is None
    assert status_for("Vehicle Speed", 65) is None


def test_fuel_trim_boundaries():
    assert status_for("Short Term Fuel Trim (Bank 1)", 10) == "ok"
    assert status_for("Short Term Fuel Trim (Bank 1)", 10.1) == "out_of_range"
    assert status_for("Short Term Fuel Trim (Bank 1)", -10) == "ok"
    assert status_for("Short Term Fuel Trim (Bank 1)", -10.1) == "out_of_range"

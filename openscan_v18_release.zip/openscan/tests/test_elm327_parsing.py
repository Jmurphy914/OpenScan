from openscan.core.elm327 import ELM327


class _FakeTransport:
    """Minimal stand-in for Transport so we can unit-test ELM327's line
    parsing without any real serial/Bluetooth hardware."""

    name = "fake"

    def connect(self, timeout=5.0):
        pass

    def close(self):
        pass

    def write(self, data):
        pass

    def read_until(self, terminator, timeout=2.0):
        return b""

    @property
    def is_connected(self):
        return True


def _elm():
    return ELM327(_FakeTransport())


def test_parse_single_ecu_response():
    elm = _elm()
    responses = elm._parse_lines("7E8 41 0C 1A F8", sent_mode=0x01)
    assert len(responses) == 1
    r = responses[0]
    assert r.ecu_id == 0x7E8
    assert r.mode == 0x01
    assert r.pid == 0x0C
    assert r.data == bytes([0x1A, 0xF8])


def test_parse_multiple_ecus_for_topology():
    raw = "7E8 41 00 BE 1F A8 13\n7E9 41 00 98 18 80 10"
    responses = ELM327(_FakeTransport())._parse_lines(raw, sent_mode=0x01)
    ecu_ids = {r.ecu_id for r in responses}
    assert ecu_ids == {0x7E8, 0x7E9}


def test_parse_skips_no_data_and_searching():
    raw = "SEARCHING...\nNO DATA\n7E8 41 0C 1A F8"
    responses = ELM327(_FakeTransport())._parse_lines(raw, sent_mode=0x01)
    assert len(responses) == 1


def test_discover_ecus_returns_distinct_ids(monkeypatch):
    elm = _elm()
    monkeypatch.setattr(
        elm,
        "request",
        lambda mode, pid=None, timeout=2.0: elm._parse_lines(
            "7E8 41 00 BE 1F A8 13\n7E9 41 00 98 18 80 10", sent_mode=0x01
        ),
    )
    assert elm.discover_ecus() == {0x7E8, 0x7E9}


def test_parse_strips_leading_iso_tp_pci_byte():
    # Real hardware capture (2016 Corolla, Veepeak Bluetooth ELM327
    # clone): "04" here is the ISO-TP single-frame length byte, not
    # payload - the actual response is "41 0C 0B E0" (RPM = 760).
    elm = _elm()
    responses = elm._parse_lines("7E8 04 41 0C 0B E0", sent_mode=0x01)
    assert len(responses) == 1
    r = responses[0]
    assert r.ecu_id == 0x7E8
    assert r.mode == 0x01
    assert r.pid == 0x0C
    assert r.data == bytes([0x0B, 0xE0])


def test_parse_pci_byte_stripping_does_not_break_clean_format():
    # Adapters that DO honor ATCAF1 and send clean framing (no PCI byte)
    # must keep working exactly as before - byte_stream[0] here is 0x41,
    # well above the 0x0F cutoff, so nothing should be stripped.
    elm = _elm()
    responses = elm._parse_lines("7E8 41 0C 1A F8", sent_mode=0x01)
    assert responses[0].data == bytes([0x1A, 0xF8])


def test_parse_pci_byte_with_full_pid_decode():
    from openscan.core.obd2.pids import load_generic_pids

    elm = _elm()
    responses = elm._parse_lines("7E8 04 41 0C 0B E0", sent_mode=0x01)
    pids = load_generic_pids()
    rpm = pids[0x0C].value(responses[0].data)
    assert rpm == 760.0

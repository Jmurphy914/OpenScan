import tempfile
from pathlib import Path

from openscan.core.dtc_history import clear_history, load_history, record_seen


def _tmp_path():
    d = tempfile.mkdtemp()
    return Path(d) / "dtc_history.json"


def test_record_and_load_new_entry():
    path = _tmp_path()
    record_seen([("P0301", "Cylinder 1 Misfire Detected")], vin="1HGCM82633A004352", path=path)
    history = load_history(path=path)
    assert len(history) == 1
    entry = history[0]
    assert entry.code == "P0301"
    assert entry.vin == "1HGCM82633A004352"
    assert entry.times_seen == 1


def test_seeing_same_code_again_bumps_times_seen_not_duplicate_row():
    path = _tmp_path()
    record_seen([("P0301", "Cylinder 1 Misfire Detected")], vin="VIN1", path=path)
    record_seen([("P0301", "Cylinder 1 Misfire Detected")], vin="VIN1", path=path)
    record_seen([("P0301", "Cylinder 1 Misfire Detected")], vin="VIN1", path=path)
    history = load_history(path=path)
    assert len(history) == 1
    assert history[0].times_seen == 3


def test_same_code_different_vin_is_a_separate_entry():
    path = _tmp_path()
    record_seen([("P0301", "desc")], vin="VIN1", path=path)
    record_seen([("P0301", "desc")], vin="VIN2", path=path)
    history = load_history(path=path)
    assert len(history) == 2
    vins = {e.vin for e in history}
    assert vins == {"VIN1", "VIN2"}


def test_filter_by_vin():
    path = _tmp_path()
    record_seen([("P0301", "desc")], vin="VIN1", path=path)
    record_seen([("P0420", "desc2")], vin="VIN2", path=path)
    only_vin1 = load_history(vin="VIN1", path=path)
    assert len(only_vin1) == 1
    assert only_vin1[0].code == "P0301"


def test_clear_history():
    path = _tmp_path()
    record_seen([("P0301", "desc")], vin="VIN1", path=path)
    assert len(load_history(path=path)) == 1
    clear_history(path=path)
    assert load_history(path=path) == []


def test_corrupted_file_does_not_crash():
    path = _tmp_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text("not valid json {{{")
    # Should treat as empty rather than raising.
    assert load_history(path=path) == []
    record_seen([("P0301", "desc")], vin="VIN1", path=path)
    assert len(load_history(path=path)) == 1

from openscan.core.obd2.monitors import decode_monitor_status


def _find(status, name):
    for m in status.monitors:
        if m.name == name:
            return m
    raise KeyError(name)


def test_mil_on_and_dtc_count():
    # byte A: MIL on (bit7=1), dtc_count=2 -> 0x80 | 0x02 = 0x82
    data = bytes([0x82, 0x00, 0x00, 0x00])
    status = decode_monitor_status(data)
    assert status.mil_on is True
    assert status.dtc_count == 2


def test_mil_off_and_zero_dtcs():
    data = bytes([0x00, 0x00, 0x00, 0x00])
    status = decode_monitor_status(data)
    assert status.mil_on is False
    assert status.dtc_count == 0


def test_spark_ignition_continuous_monitors():
    # byte B: bits0-2 supported=0b111, bit5 (fuel system not complete)=1 -> 0x27
    data = bytes([0x00, 0x27, 0x00, 0x00])
    status = decode_monitor_status(data)
    assert status.ignition_type == "spark"
    misfire = _find(status, "Misfire")
    fuel_system = _find(status, "Fuel System")
    components = _find(status, "Components")
    assert misfire.supported and misfire.complete
    assert fuel_system.supported and not fuel_system.complete
    assert components.supported and components.complete


def test_compression_ignition_selected_when_bit_set():
    data = bytes([0x00, 0x08, 0x00, 0x00])  # bit3 of byte B set
    status = decode_monitor_status(data)
    assert status.ignition_type == "compression"


def test_spark_non_continuous_monitor_bits():
    # byte C: catalyst(bit0)+evap(bit2) supported = 0x05
    # byte D: evap(bit2) not complete = 0x04
    data = bytes([0x00, 0x00, 0x05, 0x04])
    status = decode_monitor_status(data)
    catalyst = _find(status, "Catalyst")
    evap = _find(status, "Evaporative System")
    egr = _find(status, "EGR System")
    assert catalyst.supported and catalyst.complete
    assert evap.supported and not evap.complete
    assert not egr.supported


def test_incomplete_count():
    # fuel system supported+not complete, evap supported+not complete -> 2 incomplete
    data = bytes([0x00, 0x27, 0x05, 0x04])
    status = decode_monitor_status(data)
    assert status.incomplete_count() == 2


def test_requires_four_bytes():
    try:
        decode_monitor_status(bytes([0x00, 0x00]))
        raised = False
    except ValueError:
        raised = True
    assert raised

"""Proves ELM327 serializes adapter I/O across threads.

The real bug this guards against: the GUI's live-data poll worker runs
continuously on a background QThread while DTC/topology/readiness/VIN
refreshes are triggered from the main thread. Without a lock around the
full write+read round trip in _send_raw(), two threads' commands and
responses can interleave on the shared serial/Bluetooth socket - which
looks like the "random intermittent" garbled results reported against
real hardware, independent of any actual bus noise.
"""

import threading
import time

from openscan.core.elm327 import ELM327
from openscan.core.transport.base import Transport


class _RaceDetectingTransport(Transport):
    """Records which command was in flight when read_until() returns.

    write() latches the command that was just sent; read_until() sleeps
    briefly (simulating real adapter/Bluetooth round-trip latency) and
    then checks whether some *other* thread's write() clobbered that
    latch in the meantime. Without _send_raw()'s lock serializing the
    full write+read pair, concurrent threads reliably trigger this - with
    the lock, it's structurally impossible.
    """

    name = "race-detector"

    def __init__(self):
        self._current = None
        self.violations: list[tuple[str, str]] = []

    def connect(self, timeout: float = 5.0) -> None:
        pass

    def close(self) -> None:
        pass

    def write(self, data: bytes) -> None:
        self._current = data.decode("ascii").strip()

    def read_until(self, terminator: bytes, timeout: float = 2.0) -> bytes:
        expected = self._current
        time.sleep(0.02)  # simulate slow adapter/Bluetooth round trip
        if self._current != expected:
            self.violations.append((expected, self._current))
        return b"7E8 41 00 00 00 00 00\r\r>"

    @property
    def is_connected(self) -> bool:
        return True


def test_concurrent_requests_do_not_interleave():
    transport = _RaceDetectingTransport()
    elm = ELM327(transport)

    commands = [(0x01, 0x00), (0x01, 0x0C), (0x03, None), (0x09, 0x02), (0x0A, None)]

    def worker(n):
        for _ in range(20):
            mode, pid = commands[n % len(commands)]
            elm.request(mode, pid)

    threads = [threading.Thread(target=worker, args=(i,)) for i in range(6)]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=10)

    assert transport.violations == [], (
        f"detected {len(transport.violations)} interleaved command/response "
        f"race(s) - _send_raw()'s lock should make this impossible"
    )

from openscan.core.obd2.dtc import decode_dtc_bytes, dtc_description


def test_decode_p0301():
    # P0301: letter=P (00), digit1=0, digit2=3, digit3=0, digit4=1
    # byte1 bits: [letter(2)][digit1(2)][digit2(4)] = 00 00 0011 = 0x03
    # byte2 bits: [digit3(4)][digit4(4)] = 0000 0001 = 0x01
    codes = decode_dtc_bytes(bytes([0x03, 0x01]))
    assert codes == ["P0301"]


def test_decode_multiple_and_skip_zero():
    # 0x41, 0x71 -> letter bits 01 = C, digit1=0, digit2=1, digit3=7, digit4=1 -> C0171
    codes = decode_dtc_bytes(bytes([0x03, 0x01, 0x00, 0x00, 0x41, 0x71]))
    assert codes[0] == "P0301"
    assert codes[1] == "C0171"
    assert len(codes) == 2


def test_decode_u_code():
    # U0100: letter=U(11), digit1=0 -> byte1 = 11 00 0001 = 0xC1
    codes = decode_dtc_bytes(bytes([0xC1, 0x00]))
    assert codes == ["U0100"]


def test_description_lookup_known():
    assert "Misfire" in dtc_description("P0301")


def test_description_lookup_unknown_falls_back():
    desc = dtc_description("P9999")
    assert "manufacturer-specific" in desc.lower()


def test_description_extra_override():
    extra = {"P0301": "Custom override description"}
    assert dtc_description("P0301", extra) == "Custom override description"

from openscan.core.obd2.pids import load_generic_pids


def test_rpm_decode():
    pids = load_generic_pids()
    rpm_def = pids[0x0C]
    # A=0x1A, B=0xF8 -> ((26*256)+248)/4 = 1726 rpm
    assert rpm_def.value(bytes([0x1A, 0xF8])) == 1726.0


def test_coolant_temp_decode():
    # OpenScan displays US customary units - the SAE formula's native
    # 123 - 40 = 83 degC gets converted to degF (83 * 9/5 + 32 = 181.4)
    # by the UNIT_CONVERSIONS wrapper applied in load_generic_pids().
    pids = load_generic_pids()
    temp_def = pids[0x05]
    assert temp_def.unit == "°F"
    assert round(temp_def.value(bytes([0x7B])), 1) == 181.4


def test_speed_decode():
    # Native formula gives 50 km/h; converted to mph (50 / 1.60934).
    pids = load_generic_pids()
    speed_def = pids[0x0D]
    assert speed_def.unit == "mph"
    assert round(speed_def.value(bytes([0x32])), 2) == 31.07


def test_throttle_pct_decode():
    pids = load_generic_pids()
    throttle_def = pids[0x11]
    assert round(throttle_def.value(bytes([0xFF])), 2) == 100.0


def test_value_returns_none_when_short():
    pids = load_generic_pids()
    rpm_def = pids[0x0C]
    assert rpm_def.value(bytes([0x1A])) is None


def test_odometer_decode_and_unit_conversion():
    # PID 0xA6: 4 bytes, 0.1 km resolution. 0x00030D40 -> 200000 * 0.1 = 20000.0 km,
    # converted to miles (20000 / 1.60934).
    pids = load_generic_pids()
    odo_def = pids[0xA6]
    assert odo_def.unit == "mi"
    raw = bytes([0x00, 0x03, 0x0D, 0x40])
    assert round(odo_def.value(raw), 1) == round(20000.0 / 1.60934, 1)


def test_wideband_o2_equivalence_ratio_pids_present():
    pids = load_generic_pids()
    for pid in range(0x24, 0x2C):
        assert pid in pids
    for pid in range(0x34, 0x3C):
        assert pid in pids

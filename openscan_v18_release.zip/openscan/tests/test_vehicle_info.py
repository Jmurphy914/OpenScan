from openscan.core.transport.base import Transport
from openscan.core.vehicle import VehicleSession


class _InertTransport(Transport):
    name = "inert"

    def connect(self, timeout: float = 5.0) -> None:
        pass

    def close(self) -> None:
        pass

    def write(self, data: bytes) -> None:
        pass

    def read_until(self, terminator: bytes, timeout: float = 2.0) -> bytes:
        return b">"

    @property
    def is_connected(self) -> bool:
        return True


def test_set_vehicle_info_updates_only_given_fields():
    session = VehicleSession(transport=_InertTransport())
    session.elm.connect = lambda timeout=5.0: None  # bypass real init sequence

    session.set_vehicle_info(make="Toyota", model="Corolla", year="2016")
    assert session.vehicle_make == "Toyota"
    assert session.vehicle_model == "Corolla"
    assert session.vehicle_year == "2016"
    assert session.vin is None

    session.set_vehicle_info(vin="1G1JC5447000001")
    assert session.vin == "1G1JC5447000001"
    # unspecified fields are left untouched by a second call
    assert session.vehicle_make == "Toyota"


def test_set_vehicle_info_empty_string_clears_field():
    session = VehicleSession(transport=_InertTransport())
    session.set_vehicle_info(make="Toyota")
    assert session.vehicle_make == "Toyota"
    session.set_vehicle_info(make="")
    assert session.vehicle_make is None

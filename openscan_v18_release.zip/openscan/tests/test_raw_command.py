"""Tests for ELM327.raw_command() - the advanced/custom-command escape
hatch used by the Bidirectional Tests panel's custom command box and
Mode 08 wrapper."""

from openscan.core.elm327 import ELM327


class _ScriptedTransport:
    name = "fake"

    def __init__(self, response: str):
        self._response = response
        self._last_cmd = None

    def connect(self, timeout=5.0):
        pass

    def close(self):
        pass

    def write(self, data):
        self._last_cmd = data.decode("ascii").strip()

    def flush_input(self):
        pass

    def read_until(self, terminator, timeout=2.0):
        return (self._response + "\r\r>").encode("ascii")

    @property
    def is_connected(self):
        return True


def test_raw_command_returns_adapter_text_unparsed():
    elm = ELM327(_ScriptedTransport("7E8 41 0C 1A F8"))
    result = elm.raw_command("010C")
    assert result == "7E8 41 0C 1A F8"


def test_raw_command_works_for_arbitrary_at_commands():
    elm = ELM327(_ScriptedTransport("OK"))
    assert elm.raw_command("ATRV") == "OK"


def test_raw_command_logs_to_adapter_log():
    elm = ELM327(_ScriptedTransport("NO DATA"))
    elm.raw_command("0801")
    log = elm.get_log()
    assert log[-1].command == "0801"
    assert log[-1].response == "NO DATA"

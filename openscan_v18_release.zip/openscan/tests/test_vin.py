from openscan.core.vin import looks_like_vin


def test_valid_17_char_vin():
    assert looks_like_vin("1HGCM82633A004352")


def test_rejects_wrong_length():
    assert not looks_like_vin("SHORTVIN")
    assert not looks_like_vin("1HGCM82633A0043521")  # 18 chars


def test_rejects_invalid_characters():
    assert not looks_like_vin("1HGCMI2633A004352")   # contains I
    assert not looks_like_vin("1HGCMO2633A004352")   # contains O
    assert not looks_like_vin("1HGCMQ2633A004352")   # contains Q


def test_case_and_whitespace_normalized():
    assert looks_like_vin("  1hgcm82633a004352  ")

"""Regression test for the bug reported against a real 2016 Corolla: a
single failing PID read used to abort the entire read_live_data() cycle,
discarding every value already read successfully - making the dashboard
look like almost nothing was supported when most PIDs were actually fine.
"""

from openscan.core.obd2.pids import PidDefinition, raw_1byte
from openscan.core.obd2.service import OBD2Service


class _DummyElm:
    protocol = "6"


def _service_with_pids(names_and_ids):
    svc = OBD2Service.__new__(OBD2Service)  # bypass __init__'s JSON load
    svc.elm = _DummyElm()
    svc.active_pids = None
    svc.pids = {
        pid: PidDefinition(pid=pid, name=name, unit="", n_bytes=1, decode=raw_1byte)
        for pid, name in names_and_ids.items()
    }
    return svc


def test_one_failing_pid_does_not_blank_the_whole_cycle(monkeypatch):
    svc = _service_with_pids({0x04: "Engine Load", 0x0A: "Fuel Pressure", 0x0C: "Engine RPM"})

    def fake_read_pid(pid):
        if pid == 0x0A:
            raise TimeoutError("simulated adapter timeout on this PID")
        return {0x7E8: float(pid)}

    monkeypatch.setattr(svc, "read_pid", fake_read_pid)

    result = svc.read_live_data(pids=[0x04, 0x0A, 0x0C])
    names = set(result[0x7E8].keys())
    assert names == {"Engine Load", "Engine RPM"}
    assert "Fuel Pressure" not in names


def test_read_live_data_defaults_to_active_pids_when_set(monkeypatch):
    svc = _service_with_pids({0x04: "Engine Load", 0x0C: "Engine RPM"})
    svc.active_pids = {0x0C}

    seen_pids = []

    def fake_read_pid(pid):
        seen_pids.append(pid)
        return {0x7E8: float(pid)}

    monkeypatch.setattr(svc, "read_pid", fake_read_pid)
    svc.read_live_data()
    assert seen_pids == [0x0C]


def test_read_live_data_falls_back_to_all_known_pids_when_unset(monkeypatch):
    svc = _service_with_pids({0x04: "Engine Load", 0x0C: "Engine RPM"})
    assert svc.active_pids is None

    seen_pids = []

    def fake_read_pid(pid):
        seen_pids.append(pid)
        return {0x7E8: float(pid)}

    monkeypatch.setattr(svc, "read_pid", fake_read_pid)
    svc.read_live_data()
    assert set(seen_pids) == {0x04, 0x0C}

from openscan.core.uds.isotp import IsoTpLink


class _LoopbackBackend:
    """Fakes a raw-CAN backend for exercising IsoTpLink framing logic."""

    def __init__(self):
        self.sent_frames = []
        self._rx_queue = []

    def send_frame(self, can_id, data):
        self.sent_frames.append((can_id, data))

    def queue_rx(self, can_id, data):
        self._rx_queue.append((can_id, data))

    def recv_frame(self, timeout_ms=100):
        if not self._rx_queue:
            return None
        return self._rx_queue.pop(0)


def test_single_frame_send():
    backend = _LoopbackBackend()
    link = IsoTpLink(backend, tx_id=0x7E0, rx_id=0x7E8)
    link.send(bytes([0x22, 0xF1, 0x90]))
    can_id, frame = backend.sent_frames[0]
    assert can_id == 0x7E0
    assert frame[0] == 0x03  # single-frame PCI, length=3
    assert frame[1:4] == bytes([0x22, 0xF1, 0x90])


def test_single_frame_recv():
    backend = _LoopbackBackend()
    link = IsoTpLink(backend, tx_id=0x7E0, rx_id=0x7E8)
    backend.queue_rx(0x7E8, bytes([0x03, 0x62, 0xF1, 0x90, 0, 0, 0, 0]))
    data = link.recv()
    assert data == bytes([0x62, 0xF1, 0x90])


def test_multi_frame_send_awaits_flow_control():
    backend = _LoopbackBackend()
    link = IsoTpLink(backend, tx_id=0x7E0, rx_id=0x7E8)
    backend.queue_rx(0x7E8, bytes([0x30, 0, 0, 0, 0, 0, 0, 0]))  # flow control CTS
    payload = bytes(range(1, 11))  # 10 bytes -> needs first frame + 1 consecutive
    link.send(payload)
    first_id, first_frame = backend.sent_frames[0]
    assert (first_frame[0] >> 4) == 0x1  # first-frame PCI
    assert first_frame[2:8] == payload[:6]
    # second sent frame should be the consecutive frame with remaining bytes
    _, consecutive = backend.sent_frames[1]
    assert (consecutive[0] >> 4) == 0x2
    assert consecutive[1:5] == payload[6:10]

"""Tests that OBD2Service correctly requests and decodes Mode 0x22
(UDS ReadDataByIdentifier) PIDs - the mechanism every manufacturer
enhanced-PID plugin in openscan/plugins/enhanced/ relies on. Mode 0x22
responses echo the 2-byte identifier ahead of the payload (unlike Mode
01, where _parse_lines() already strips the single PID byte), so
read_pid() has to strip those itself - this is the behavior under
test."""

from openscan.core.elm327 import ELM327, OBDResponse
from openscan.core.obd2.pids import PidDefinition, raw_2byte
from openscan.core.obd2.service import OBD2Service


class _FakeTransport:
    name = "fake"

    def connect(self, timeout=5.0):
        pass

    def close(self):
        pass

    def write(self, data):
        pass

    def read_until(self, terminator, timeout=2.0):
        return b""

    @property
    def is_connected(self):
        return True


def test_read_pid_uses_mode22_and_strips_did_echo(monkeypatch):
    elm = ELM327(_FakeTransport())
    service = OBD2Service(elm)
    # A Mode 0x22 request for DID 0xF200 with 2-byte payload 0x00 0x2A (42).
    service.pids[0xF200] = PidDefinition(
        pid=0xF200, name="Test Enhanced PID", unit="raw",
        n_bytes=2, decode=raw_2byte, mode=0x22,
    )

    captured_request = {}

    def fake_request(mode, pid=None, timeout=2.0):
        captured_request["mode"] = mode
        captured_request["pid"] = pid
        # Simulate a real Mode 22 positive response: mode byte already
        # stripped by _parse_lines (0x62 -> 0x22), followed by the
        # echoed 2-byte DID, then the actual 2-byte payload.
        return [OBDResponse(ecu_id=0x7E0, mode=0x22, pid=None,
                             data=bytes([0xF2, 0x00, 0x00, 0x2A]))]

    monkeypatch.setattr(elm, "request", fake_request)

    result = service.read_pid(0xF200)
    assert captured_request["mode"] == 0x22
    assert captured_request["pid"] == 0xF200
    assert result == {0x7E0: 42.0}


def test_read_live_data_always_attempts_enhanced_pids_even_with_active_pids_set(monkeypatch):
    elm = ELM327(_FakeTransport())
    service = OBD2Service(elm)
    service.pids[0xF200] = PidDefinition(
        pid=0xF200, name="Test Enhanced PID", unit="raw",
        n_bytes=2, decode=raw_2byte, mode=0x22,
    )
    # Simulate a completed Mode-01-only supported-PID scan that (quite
    # correctly) never discovered the Mode 0x22 enhanced PID, since that
    # scan mechanism is inherent to Mode 01's bitmask response.
    service.active_pids = {0x0C}  # only Engine RPM confirmed supported

    requested_pids = []

    def fake_request(mode, pid=None, timeout=2.0):
        requested_pids.append(pid)
        return []

    monkeypatch.setattr(elm, "request", fake_request)
    service.read_live_data()
    assert 0x0C in requested_pids
    assert 0xF200 in requested_pids

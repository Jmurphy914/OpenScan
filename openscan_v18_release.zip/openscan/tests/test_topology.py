from openscan.core.uds.topology import label_for, KNOWN_ECU_NAMES


def test_label_known_ecm():
    assert "Engine Control Module" in label_for(0x7E8)


def test_label_unknown_module():
    assert "Unknown module" in label_for(0x7F3)


def test_label_override():
    overrides = {0x7E8: "My Custom ECM Name"}
    assert label_for(0x7E8, overrides) == "My Custom ECM Name"


def test_known_names_cover_standard_range():
    assert all(0x7E8 <= addr <= 0x7EF for addr in KNOWN_ECU_NAMES)

"""End-to-end smoke test through a scripted fake transport simulating a
single-ECU vehicle (like the reported 2016 Corolla): exercises connect(),
live data polling, readiness monitors, and freeze frame together, the
same code paths the GUI drives. Doesn't validate real-vehicle byte
values (no hardware here) - just that the whole pipeline runs without
raising, now that read_live_data() is per-PID fault tolerant and
supported-PID scanning is wired into connect().
"""

from openscan.core.transport.base import Transport
from openscan.core.vehicle import VehicleSession

# command (after stripping \r) -> raw adapter response text
_SCRIPT = {
    "ATZ": "ELM327 v1.5",
    "ATE0": "OK",
    "ATL0": "OK",
    "ATS1": "OK",
    "ATH1": "OK",
    "ATSP0": "OK",
    "ATDPN": "6",
    # Mode 01 PID 00: supported PIDs 01-20 bitmask - bits set for engine
    # load(0x04), coolant(0x05), rpm(0x0C), speed(0x0D), throttle(0x11).
    "0100": "7E8 41 00 18 18 80 00",
    "0104": "7E8 41 04 50",             # engine load
    "0105": "7E8 41 05 5A",             # coolant temp
    "010C": "7E8 41 0C 1A F8",          # rpm
    "010D": "7E8 41 0D 32",             # speed
    "0111": "7E8 41 11 40",             # throttle
    "0101": "7E8 41 01 82 27 05 04",    # monitor status
    "0902": "7E8 49 02 01 31 47 31 4A 43 35 34 34 37 30 30 30 30 30 31",
    "020200": "7E8 42 02 00 03 01",     # freeze frame DTC bytes -> P0301
    "020400": "7E8 42 04 00 50",        # freeze frame engine load
    "020500": "7E8 42 05 00 5A",        # freeze frame coolant temp
}

_NO_DATA_DEFAULT = "NO DATA"


class ScriptedTransport(Transport):
    name = "scripted-fake"

    def __init__(self):
        self._last_cmd = None
        self._connected = False

    def connect(self, timeout: float = 5.0) -> None:
        self._connected = True

    def close(self) -> None:
        self._connected = False

    def write(self, data: bytes) -> None:
        self._last_cmd = data.decode("ascii").strip()

    def read_until(self, terminator: bytes, timeout: float = 2.0) -> bytes:
        resp = _SCRIPT.get(self._last_cmd, _NO_DATA_DEFAULT)
        return (resp + "\r\r>").encode("ascii")

    @property
    def is_connected(self) -> bool:
        return self._connected


def test_full_session_smoke():
    session = VehicleSession(transport=ScriptedTransport())
    session.connect()

    assert session.elm.protocol == "6"
    # engine load, coolant, rpm, speed, throttle should all be flagged
    # supported per the 0100 bitmask response above.
    assert session.obd2.active_pids is not None
    assert {0x04, 0x05, 0x0C, 0x0D, 0x11}.issubset(session.obd2.active_pids)

    live = session.obd2.read_live_data()
    merged = {}
    for readings in live.values():
        merged.update(readings)
    assert merged["Engine RPM"] == (0x1A * 256 + 0xF8) / 4
    # Vehicle Speed displays in mph (US customary units) - native SAE
    # formula gives 0x32 (50) km/h, converted to mph.
    assert round(merged["Vehicle Speed"], 2) == round(0x32 / 1.60934, 2)
    assert "Coolant Temperature" in merged
    assert "Engine Load" in merged
    assert "Throttle Position" in merged

    statuses = session.obd2.get_monitor_status()
    assert 0x7E8 in statuses
    assert statuses[0x7E8].mil_on is True
    assert statuses[0x7E8].dtc_count == 2

    dtc = session.obd2.get_freeze_frame_dtc()
    assert dtc[0x7E8] is not None
    code, _desc = dtc[0x7E8]
    assert code == "P0301"

    snapshot = session.obd2.read_freeze_frame_snapshot()
    merged_ff = {}
    for readings in snapshot.values():
        merged_ff.update(readings)
    assert "Engine Load" in merged_ff
    assert "Coolant Temperature" in merged_ff

    graph = session.refresh_topology()
    assert any(n.ecu_id == 0x7E8 for n in graph.nodes)

    session.disconnect()

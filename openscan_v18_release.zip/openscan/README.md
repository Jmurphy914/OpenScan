# OpenScan

An open-source, cross-platform (Linux + Windows) automotive diagnostic scan
tool, built to bring professional-shop features — live data, DTC read/clear,
freeze frame, VIN decode, ECU network topology mapping, and a bidirectional
command framework — to hobbyist-grade Bluetooth OBD-II adapters.

OpenScan is written in Python with a PySide6 (Qt) desktop GUI so the same
codebase runs on Linux and Windows without changes.

## Why this exists

Tools like the Autel MaxiSys Ultra, Snap-on APOLLO, and Bosch ADS line cost
$5,000–$15,000+ and bundle three things:

1. A generic OBD-II engine (this is fully open and standardized — SAE J1979 /
   ISO 15031). **Fully replicable, and OpenScan implements it.**
2. An enhanced UDS/KWP2000 diagnostic engine (ISO 14229 / ISO 14230) that
   talks to individual modules (ECM, TCM, ABS, BCM, etc.), builds a network
   topology map, reads manufacturer-specific DTCs, and runs bidirectional
   routines (actuator tests, relearns, resets). **The protocol layer is
   open and OpenScan implements it.**
3. A giant, continuously-updated database of OEM-specific security-access
   seed/key algorithms, per-vehicle routine IDs, and licensed reflashing
   data. **This is proprietary, paid, and legally encumbered — no open
   source project can ship it.** OpenScan instead exposes a plugin
   interface so individual users/shops can add their own
   legally-obtained OEM data.

See `docs/HARDWARE.md` for exactly what your Veepeak and TOPDON ONE adapters
can and can't do with this software, and `docs/ROADMAP.md` for what's
implemented today vs. what requires community/plugin contributions.

## Features (current)

- Bluetooth (RFCOMM/SPP) and USB-serial transport to any ELM327-compatible
  adapter (Veepeak, OBDLink, generic ELM327 clones).
- Full generic OBD-II: 80 standard Mode 01 live PIDs (engine, fuel trims,
  8-bank O2 sensor voltage and wideband equivalence ratio, catalyst temps,
  EVAP, EGR, torque, injection timing, hybrid battery, odometer, and more),
  freeze frame (Mode 02), DTCs read/clear (Mode 03/04/07/0A), VIN/
  calibration ID (Mode 09). All values display in US customary units
  (°F, mph, psi, gal/h) rather than metric.
- Automatic per-vehicle PID support detection - the dashboard only shows
  and polls parameters your specific vehicle actually implements, instead
  of guessing from a generic list.
- Readiness monitor / "I/M Readiness" decoding (Mode 01 PID 01): MIL
  status, confirmed DTC count, and per-monitor supported/complete state
  for both spark and compression ignition - the same screen used to
  check if a vehicle will pass an emissions/OBD inspection.
- Freeze frame viewer: the DTC that triggered a freeze frame plus the
  engine conditions captured at that moment.
- Multi-ECU discovery over functional addressing (broadcast 0x7DF, collect
  distinct responders 0x7E8–0x7EF) — gives a basic topology map from a
  plain ELM327 adapter alone, no special hardware required.
- Deeper UDS (ISO 14229) session layer for adapters that support raw CAN
  passthrough, with hooks for per-ECU DTCs, IO control, and routine
  control (actuator tests) — see HARDWARE.md for adapter requirements.
- Live Data tab split down the middle: gauges (any supported parameter,
  not just the defaults) and user-selectable real-time strip charts on
  the left, a full sortable live-data stream table on the right; DTC
  panel with plain-English descriptions (482 generic codes) and a
  one-click Google search for further reading; readiness/freeze-frame
  panel; and a visual network topology map.
- Green/red highlighting on gauges and the live data table for the
  handful of parameters that have a genuinely condition-independent
  "normal" band (coolant/oil temp, fuel trims, control module voltage,
  EGR error) - see `openscan/core/obd2/normal_ranges.py` for why most
  PIDs (RPM, speed, load...) intentionally aren't highlighted this way.
- VIN entry before connecting, with an optional camera barcode scan
  (requires opencv-python + pyzbar, installed by default) - if the
  vehicle doesn't answer a VIN request automatically after connecting,
  you're prompted again before the main window opens.
- Bidirectional Tests tab: a raw custom-command box and an SAE J1979
  Mode 08 (I/O control) wrapper - deliberately does NOT include
  manufacturer-specific actuator tests (fan control, ABS bleed, resets,
  etc.), since those need real routine IDs manufacturers don't publish.
  See the panel's own docstring for why, and openscan/plugins/enhanced/
  for the same issue on the sensor-reading side.
- Live data logging to CSV, and PNG snapshot export for both the
  strip-chart graphs and the live data table.
- Dark mode toggle in the toolbar.
- DTC History tab: every code ever seen on a vehicle (by VIN),
  persisted across app restarts - separate from the Diagnostic Codes
  tab, which only shows what's currently stored on the ECU.
- Enter vehicle make/model/year before connecting (optional) - this
  auto-activates a matching manufacturer enhanced-PID plugin, if one is
  installed. See `openscan/plugins/enhanced/README.md` for what's
  currently there (Toyota/Lexus, Honda/Acura, Nissan/Infiniti, GM, Ford,
  Chrysler/Stellantis, VW/Audi, BMW/Mini, Mercedes-Benz) and its accuracy
  caveats - these ship as a working framework with placeholder
  identifiers, not verified data, since manufacturers don't publish this
  information and OpenScan won't present invented codes as fact.
- Plugin system for OEM-specific PID/DTC databases, security-access
  algorithms, and bidirectional routines.

## Quick start

**Windows:** double-click `scripts\setup_windows.bat` (or run it from a
Command Prompt in the project folder). It creates a virtual environment
and installs everything needed.

**Linux:** `bash scripts/setup_linux.sh`

Either script sets up a `.venv` you can reuse afterward:

```bash
# Windows
.venv\Scripts\activate
python -m openscan

# Linux
source .venv/bin/activate
python -m openscan
```

Or install manually if you'd rather not use a venv:

```bash
pip install -r requirements.txt
python -m openscan
```

On Linux, pair your adapter first with `bluetoothctl` (or your desktop's
Bluetooth settings) and note the RFCOMM device (e.g. `/dev/rfcomm0`) or MAC
address. On Windows, pair it in Settings > Bluetooth & devices, then note
the COM port Windows assigns.

## License

MIT. See `LICENSE`. Any OEM-specific data you add via plugins (seed/key
algorithms, factory routine tables, etc.) is your responsibility to source
legally — OpenScan does not include or endorse using proprietary OEM data
you are not licensed to use.
